'use strict';
// Sauvegarde durable de petits documents JSON.
// - Par défaut : fichier local (effacé à chaque mise à jour sur l'offre gratuite de Render).
// - Si SUPABASE_URL et SUPABASE_KEY sont définis : table « mobilya_kv » de Supabase (données conservées).
const fs = require('fs');
const path = require('path');

const SB_URL = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const SB_KEY = process.env.SUPABASE_KEY || '';
const useSupabase = !!(SB_URL && SB_KEY);

class Persist {
  constructor(name, dir) {
    this.name = name;
    this.file = path.join(dir, `${name}.json`);
    this.timer = null;
    this.backend = useSupabase ? 'supabase' : 'fichier';
  }
  async load() {
    if (useSupabase) {
      try {
        const res = await fetch(`${SB_URL}/rest/v1/mobilya_kv?k=eq.${encodeURIComponent(this.name)}&select=v`, { headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}` }, signal: AbortSignal.timeout(15000) });
        if (!res.ok) throw new Error(`Supabase HTTP ${res.status} : ${(await res.text()).slice(0, 200)}`);
        const rows = await res.json();
        return rows[0] ? rows[0].v : null;
      } catch (e) { console.error(`Chargement ${this.name} depuis Supabase impossible :`, e.message); this.lastError = e.message; return null; }
    }
    try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { return null; }
  }
  save(obj) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.flush(obj), 800);
  }
  async flush(obj) {
    if (useSupabase) {
      try {
        const res = await fetch(`${SB_URL}/rest/v1/mobilya_kv`, {
          method: 'POST',
          headers: { apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}`, 'Content-Type': 'application/json', Prefer: 'resolution=merge-duplicates,return=minimal' },
          body: JSON.stringify({ k: this.name, v: obj, updated_at: new Date().toISOString() }),
          signal: AbortSignal.timeout(15000),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status} : ${(await res.text()).slice(0, 200)}`);
        this.lastError = null;
      } catch (e) { console.error(`Sauvegarde ${this.name} sur Supabase impossible :`, e.message); this.lastError = e.message; }
      return;
    }
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    fs.writeFile(this.file, JSON.stringify(obj), () => {});
  }
}

module.exports = { Persist, useSupabase };
