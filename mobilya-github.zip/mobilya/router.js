'use strict';
// Calcul d'itinéraires sur le GTFS : algorithme "Connection Scan" (CSA), marche à pied au départ,
// à l'arrivée et entre arrêts proches, temps de correspondance minimal.
const T = require('./time');
const { serviceActive, routeView, distM } = require('./gtfs');

const WALK_MS = 1.2;          // vitesse de marche (m/s)
const DETOUR = 1.3;           // les rues ne sont pas en ligne droite
const MAX_ACCESS_M = 1000;    // distance max à pied pour rejoindre / quitter le bus
const MAX_TRANSFER_M = 300;   // distance max entre deux arrêts pour une correspondance à pied
const MIN_CHANGE_S = 60;      // temps minimal pour changer de bus
const HORIZON_H = 4;

const walkSec = (m) => Math.round((m * DETOUR) / WALK_MS);

const cache = { model: null, days: new Map(), foot: null };

// Correspondances à pied entre arrêts proches (calculées une fois par GTFS)
function footpaths(model) {
  if (cache.model === model && cache.foot) return cache.foot;
  const stops = [...model.stops.values()].filter((s) => s.locationType !== 1 && isFinite(s.lat));
  const foot = new Map();
  const cell = 0.004; // ~ 400 m
  const grid = new Map();
  const key = (lat, lon) => `${Math.floor(lat / cell)}:${Math.floor(lon / cell)}`;
  for (const s of stops) { const k = key(s.lat, s.lon); if (!grid.has(k)) grid.set(k, []); grid.get(k).push(s); }
  for (const s of stops) {
    const out = [];
    const gy = Math.floor(s.lat / cell), gx = Math.floor(s.lon / cell);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      for (const o of grid.get(`${gy + dy}:${gx + dx}`) || []) {
        if (o.id === s.id) continue;
        const d = distM(s.lat, s.lon, o.lat, o.lon);
        if (d <= MAX_TRANSFER_M) out.push({ to: o.id, sec: Math.max(MIN_CHANGE_S, walkSec(d)) });
      }
    }
    foot.set(s.id, out);
  }
  cache.foot = foot;
  return foot;
}

// Liste des "connexions" (un bus va d'un arrêt au suivant) d'un jour de service, triée par heure de départ
function connectionsFor(model, ymd) {
  if (cache.model !== model) { cache.model = model; cache.days = new Map(); cache.foot = null; }
  if (cache.days.has(ymd)) return cache.days.get(ymd);
  const base = T.serviceBase(ymd);
  const conns = [];
  for (const [tripId, list] of model.tripStops) {
    const trip = model.trips.get(tripId);
    if (!serviceActive(model, trip.serviceId, ymd)) continue;
    for (let i = 0; i < list.length - 1; i++) {
      const a = list[i], b = list[i + 1];
      if (a.dep == null || b.arr == null) continue;
      conns.push({ trip: tripId, from: a.stopId, to: b.stopId, dep: base + a.dep * 1000, arr: base + b.arr * 1000, i });
    }
  }
  conns.sort((x, y) => x.dep - y.dep || x.arr - y.arr);
  cache.days.set(ymd, conns);
  if (cache.days.size > 3) cache.days.delete(cache.days.keys().next().value);
  return conns;
}

function nearStops(model, lat, lon, maxM) {
  const out = [];
  for (const s of model.stops.values()) {
    if (s.locationType === 1 || !isFinite(s.lat)) continue;
    const d = distM(lat, lon, s.lat, s.lon);
    if (d <= maxM) out.push({ id: s.id, d, sec: walkSec(d) });
  }
  return out;
}

// Un calcul : meilleur trajet partant après t0
function scan(model, from, to, t0) {
  const today = T.parts(t0).ymd;
  // On fusionne la veille (courses après minuit) et le jour même
  const conns = [...connectionsFor(model, T.shiftYmd(today, -1)).filter((c) => c.dep >= t0), ...connectionsFor(model, today).filter((c) => c.dep >= t0)]
    .sort((x, y) => x.dep - y.dep);
  const foot = footpaths(model);
  const S = new Map();      // heure à laquelle on peut monter dans un bus à cet arrêt
  const A = new Map();      // heure d'arrivée réelle à cet arrêt
  const J = new Map();      // comment on est arrivé à cet arrêt
  const T0 = new Map();     // première connexion empruntée de chaque course
  const origin = nearStops(model, from.lat, from.lon, MAX_ACCESS_M);
  for (const o of origin) { const t = t0 + o.sec * 1000; S.set(o.id, t); A.set(o.id, t); J.set(o.id, { type: 'walk-start', sec: o.sec, d: o.d }); }
  const dest = new Map(nearStops(model, to.lat, to.lon, MAX_ACCESS_M).map((x) => [x.id, x]));
  if (!origin.length || !dest.size) return null;
  let best = Infinity, bestStop = null;
  const limit = t0 + HORIZON_H * 3600 * 1000;
  for (const c of conns) {
    if (c.dep > limit || c.dep >= best) break;
    const onTrip = T0.has(c.trip);
    if (!onTrip && !((S.get(c.from) ?? Infinity) <= c.dep)) continue;
    if (!onTrip) T0.set(c.trip, c);
    if (c.arr < (A.get(c.to) ?? Infinity)) {
      A.set(c.to, c.arr);
      J.set(c.to, { type: 'bus', board: T0.get(c.trip), alight: c });
      const ready = c.arr + MIN_CHANGE_S * 1000;
      if (ready < (S.get(c.to) ?? Infinity)) S.set(c.to, ready);
      for (const f of foot.get(c.to) || []) {
        const t = c.arr + f.sec * 1000;
        if (t < (A.get(f.to) ?? Infinity) && !(J.get(f.to) && J.get(f.to).type === 'walk-start')) {
          A.set(f.to, t); S.set(f.to, Math.min(S.get(f.to) ?? Infinity, t));
          J.set(f.to, { type: 'walk', from: c.to, sec: f.sec, at: c.arr });
        }
      }
      const dz = dest.get(c.to);
      if (dz && c.arr + dz.sec * 1000 < best) { best = c.arr + dz.sec * 1000; bestStop = c.to; }
    }
  }
  if (!bestStop) return null;
  // Reconstruction du trajet (à rebours)
  const legs = [];
  const dz = dest.get(bestStop);
  legs.push({ type: 'walk', fromStop: bestStop, toPlace: 'arrivée', sec: dz.sec, meters: Math.round(dz.d * DETOUR), start: A.get(bestStop), end: best });
  let cur = bestStop, guard = 0;
  while (guard++ < 20) {
    const j = J.get(cur);
    if (!j) break;
    if (j.type === 'walk-start') { legs.push({ type: 'walk', toStop: cur, fromPlace: 'départ', sec: j.sec, meters: Math.round(j.d * DETOUR), start: t0, end: t0 + j.sec * 1000 }); break; }
    if (j.type === 'walk') { legs.push({ type: 'walk', fromStop: j.from, toStop: cur, sec: j.sec, meters: Math.round(j.sec * WALK_MS / DETOUR * DETOUR), start: j.at, end: j.at + j.sec * 1000 }); cur = j.from; continue; }
    legs.push({ type: 'bus', trip: j.board.trip, fromStop: j.board.from, toStop: j.alight.to, dep: j.board.dep, arr: j.alight.arr, fromIdx: j.board.i, toIdx: j.alight.i + 1 });
    cur = j.board.from;
  }
  legs.reverse();
  return { legs, arrival: best };
}

function describe(model, it, rt) {
  const stopName = (id) => { const k = model.areaOfStop.get(id); return k ? model.areas.get(k).name : (model.stops.get(id) || {}).name || id; };
  const stopKey = (id) => model.areaOfStop.get(id) || null;
  const legs = [];
  for (const l of it.legs) {
    if (l.type === 'walk') {
      if (l.sec < 45 && legs.length) continue; // simple changement de quai
      legs.push({ type: 'walk', minutes: Math.max(1, Math.round(l.sec / 60)), meters: l.meters,
        from: l.fromStop ? stopName(l.fromStop) : 'Départ', to: l.toStop ? stopName(l.toStop) : 'Arrivée', start: l.start, end: l.end });
    } else {
      const trip = model.trips.get(l.trip);
      const list = model.tripStops.get(l.trip) || [];
      const path = list.slice(l.fromIdx, l.toIdx + 1).map((e) => model.stops.get(e.stopId)).filter(Boolean).map((s) => [s.lat, s.lon]);
      const tu = rt && rt.tripUpdates.get(l.trip);
      let delay = null;
      if (tu) {
        const u = (tu.stopTimeUpdates || []).find((x) => x.departure && x.departure.delay != null) || (tu.stopTimeUpdates || [])[0];
        if (u) { const ev = u.departure || u.arrival; if (ev && ev.delay != null) delay = ev.delay; }
        if (delay == null && tu.delay != null) delay = tu.delay;
      }
      legs.push({ type: 'bus', tripId: l.trip, line: routeView(model, trip.routeId), headsign: trip.headsign,
        from: stopName(l.fromStop), fromKey: stopKey(l.fromStop), to: stopName(l.toStop), toKey: stopKey(l.toStop),
        dep: l.dep, arr: l.arr, stops: l.toIdx - l.fromIdx, delay, path });
    }
  }
  // On part « juste à temps » : la marche d'approche se cale sur le premier bus (1 min de marge)
  const fb = legs.find((x) => x.type === 'bus');
  if (legs[0].type === 'walk' && fb) { legs[0].end = fb.dep - 60 * 1000; legs[0].start = legs[0].end - legs[0].minutes * 60 * 1000; }
  const first = legs[0], last = legs[legs.length - 1];
  const start = first.type === 'walk' ? first.start : first.dep;
  return { start, end: it.arrival, minutes: Math.round((it.arrival - start) / 60000), transfers: Math.max(0, legs.filter((x) => x.type === 'bus').length - 1), legs, endTime: last.end || last.arr };
}

// Jusqu'à 3 propositions différentes ; plus une option "tout à pied" si c'est court
function plan(model, rt, from, to, t0, count = 3) {
  const out = [];
  const seen = new Set();
  let t = t0;
  for (let k = 0; k < 6 && out.length < count; k++) {
    const it = scan(model, from, to, t);
    if (!it) break;
    const d = describe(model, it, rt);
    const firstBus = d.legs.find((x) => x.type === 'bus');
    if (!firstBus) break;
    const sig = d.legs.filter((x) => x.type === 'bus').map((x) => x.tripId).join('>');
    if (!seen.has(sig)) { seen.add(sig); out.push(d); }
    // Recherche suivante : partir juste trop tard pour ce premier bus
    const access = it.legs[0].type === 'walk' ? it.legs[0].sec : 0;
    t = Math.max(t + 60 * 1000, firstBus.dep - access * 1000 + 60 * 1000);
  }
  const direct = distM(from.lat, from.lon, to.lat, to.lon) * DETOUR;
  const walk = direct <= 2500 ? { minutes: Math.max(1, Math.round(direct / WALK_MS / 60)), meters: Math.round(direct) } : null;
  return { itineraries: out, walk };
}

module.exports = { plan };
