'use strict';
// Comptes usagers : inscription, connexion, session, sauvegarde des points / favoris.
const crypto = require('crypto');
const { Persist } = require('./persist');

const EMAIL = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;
const clip = (s, n) => (typeof s === 'string' ? s.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n) : '');

class Accounts {
  constructor(dir) {
    this.persist = new Persist('accounts', dir);
    this.data = { users: {}, sessions: {} };
  }
  async init() { const saved = await this.persist.load(); if (saved) this.data = { users: {}, sessions: {}, ...saved }; }
  save() { this.persist.save(this.data); }
  hash(password, salt) { return crypto.scryptSync(password, salt, 32).toString('base64'); }
  publicUser(u) { return { id: u.id, email: u.email, pseudo: u.pseudo, createdAt: u.createdAt, data: u.data || {} }; }
  newSession(uid) {
    const token = crypto.randomBytes(24).toString('base64url');
    this.data.sessions[token] = { uid, at: Date.now() };
    // Nettoyage : sessions de plus de 180 jours
    const old = Date.now() - 180 * 864e5;
    for (const [t, s] of Object.entries(this.data.sessions)) if (s.at < old) delete this.data.sessions[t];
    this.save();
    return token;
  }
  findByEmail(email) { return Object.values(this.data.users).find((u) => u.email === email); }
  register({ email, pseudo, password, data }) {
    email = clip(email, 254).toLowerCase();
    pseudo = clip(pseudo, 30);
    if (!EMAIL.test(email)) throw new Error('Adresse e-mail invalide.');
    if (typeof password !== 'string' || password.length < 6) throw new Error('Le mot de passe doit faire au moins 6 caractères.');
    if (!pseudo) throw new Error('Choisissez un pseudo.');
    if (this.findByEmail(email)) throw new Error('Un compte existe déjà avec cette adresse.');
    const salt = crypto.randomBytes(16).toString('base64');
    const u = { id: crypto.randomUUID(), email, pseudo, salt, hash: this.hash(password, salt), createdAt: Date.now(), data: this.cleanData(data) };
    this.data.users[u.id] = u;
    return { token: this.newSession(u.id), user: this.publicUser(u) };
  }
  login({ email, password }) {
    const u = this.findByEmail(clip(email, 254).toLowerCase());
    const ok = u && typeof password === 'string' && crypto.timingSafeEqual(Buffer.from(this.hash(password, u.salt)), Buffer.from(u.hash));
    if (!ok) throw new Error('E-mail ou mot de passe incorrect.');
    return { token: this.newSession(u.id), user: this.publicUser(u) };
  }
  userFor(token) {
    const s = token && this.data.sessions[token];
    return s ? this.data.users[s.uid] || null : null;
  }
  logout(token) { if (this.data.sessions[token]) { delete this.data.sessions[token]; this.save(); } }
  cleanData(d) {
    if (!d || typeof d !== 'object') return {};
    const out = {};
    if (d.points && typeof d.points === 'object') out.points = d.points;
    if (Array.isArray(d.favs)) out.favs = d.favs.slice(0, 12);
    if (Array.isArray(d.recent)) out.recent = d.recent.slice(0, 10);
    if (JSON.stringify(out).length > 60000) throw new Error('Données trop volumineuses.');
    return out;
  }
  saveData(token, d) {
    const u = this.userFor(token);
    if (!u) return null;
    u.data = { ...(u.data || {}), ...this.cleanData(d) };
    if (d && typeof d.pseudo === 'string' && clip(d.pseudo, 30)) u.pseudo = clip(d.pseudo, 30);
    this.save();
    return this.publicUser(u);
  }
  count() { return Object.keys(this.data.users).length; }
}

module.exports = { Accounts };
