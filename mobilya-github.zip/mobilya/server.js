'use strict';
// Serveur Mobilya : relais entre les données du réseau (GTFS + GTFS-RT) et la web-app.
const http = require('http');
const fs = require('fs');
const path = require('path');
const G = require('./gtfs');
const { decodeFeed } = require('./gtfsrt');
const { Store } = require('./store');
const { Accounts } = require('./accounts');
const { useSupabase } = require('./persist');
const R = require('./router');

const CFG = {
  port: +(process.env.PORT || 8080),
  gtfsUrl: process.env.GTFS_URL || 'https://data.chateauroux-metropole.fr/api/v2/catalog/datasets/reseau-de-bus-urbain_horizon/alternative_exports/gtfs_20260901_zip',
  gtfsFile: process.env.GTFS_FILE || '',
  tripUpdatesUrl: process.env.RT_TRIP_UPDATES_URL ?? 'https://gtfs.bus-tracker.fr/gtfs-rt/chateauroux/trip-updates',
  vehiclePositionsUrl: process.env.RT_VEHICLE_POSITIONS_URL ?? 'https://gtfs.bus-tracker.fr/gtfs-rt/chateauroux/vehicle-positions',
  alertsUrl: process.env.RT_ALERTS_URL || '',
  pollMs: +(process.env.RT_POLL_SECONDS || 20) * 1000,
  gtfsRefreshHours: +(process.env.GTFS_REFRESH_HOURS || 12),
  adminToken: process.env.ADMIN_TOKEN || '',
  dataDir: process.env.DATA_DIR || path.join(__dirname, 'data'),
  userAgent: process.env.USER_AGENT || 'Mobilya/0.1 (essai reseau Horizon)',
};

const PUBLIC = __dirname;
// Seuls ces fichiers sont servis au navigateur (le code serveur et les données restent privés)
const PUBLIC_FILES = new Set(['index.html', 'app.css', 'app.js', 'mesh.js', 'manifest.webmanifest', 'sw.js', 'icon-64.png', 'icon-180.png', 'icon-192.png', 'icon-512.png', 'maskable-512.png']);
const store = new Store(CFG.dataDir);
const accounts = new Accounts(CFG.dataDir);
const geoCache = new Map();
const state = {
  model: null, gtfsError: null, gtfsLoadedAt: null,
  rt: { tripUpdates: new Map(), vehicles: [], alerts: [], tuAt: null, vpAt: null, alertsAt: null, errors: {} },
};

const log = (...a) => console.log(new Date().toISOString(), ...a);

async function download(url) {
  const res = await fetch(url, { headers: { 'User-Agent': CFG.userAgent }, signal: AbortSignal.timeout(30000) });
  if (!res.ok) throw new Error(`HTTP ${res.status} pour ${url}`);
  return Buffer.from(await res.arrayBuffer());
}

async function refreshGtfs() {
  try {
    const buf = CFG.gtfsFile ? fs.readFileSync(CFG.gtfsFile) : await download(CFG.gtfsUrl);
    const t0 = Date.now();
    state.model = G.loadGtfs(buf);
    state.gtfsLoadedAt = Date.now();
    state.gtfsError = null;
    log(`GTFS chargé en ${Date.now() - t0} ms : ${state.model.routes.size} lignes, ${state.model.areas.size} arrêts, ${state.model.trips.size} courses, valide ${state.model.validFrom} → ${state.model.validTo}`);
  } catch (e) {
    state.gtfsError = e.message;
    log('Erreur GTFS :', e.message);
  }
}

async function pollRealtime() {
  const rt = state.rt;
  const jobs = [];
  if (CFG.tripUpdatesUrl) jobs.push(download(CFG.tripUpdatesUrl).then((b) => {
    const feed = decodeFeed(b);
    const m = new Map();
    for (const e of feed.entities) if (e.tripUpdate && e.tripUpdate.trip && e.tripUpdate.trip.tripId && !e.isDeleted) m.set(e.tripUpdate.trip.tripId, e.tripUpdate);
    rt.tripUpdates = m; rt.tuAt = Date.now(); delete rt.errors.tripUpdates;
  }).catch((e) => { rt.errors.tripUpdates = e.message; }));
  if (CFG.vehiclePositionsUrl) jobs.push(download(CFG.vehiclePositionsUrl).then((b) => {
    const feed = decodeFeed(b);
    rt.vehicles = feed.entities.filter((e) => e.vehicle && e.vehicle.position && !e.isDeleted).map((e) => ({ entityId: e.id, ...e.vehicle }));
    rt.vpHeaderTs = feed.header && feed.header.timestamp ? feed.header.timestamp : null;
    rt.vpAt = Date.now(); delete rt.errors.vehiclePositions;
  }).catch((e) => { rt.errors.vehiclePositions = e.message; }));
  if (CFG.alertsUrl) jobs.push(download(CFG.alertsUrl).then((b) => {
    const feed = decodeFeed(b);
    rt.alerts = feed.entities.filter((e) => e.alert).map((e) => ({ id: e.id, ...e.alert }));
    rt.alertsAt = Date.now(); delete rt.errors.alerts;
  }).catch((e) => { rt.errors.alerts = e.message; }));
  await Promise.all(jobs);
  if (Object.keys(rt.errors).length) log('Temps réel :', JSON.stringify(rt.errors));
}

// ---------- Vues API ----------

// Horodatage GTFS-RT -> ms ; null si absent ou invraisemblable (certains flux mettent 0 ou une petite valeur)
const tsMs = (t) => (!t || t < 1e9 ? null : t > 1e11 ? t : t * 1000);

const vehicleId = (v) => String((v.vehicle && (v.vehicle.id || v.vehicle.label)) || v.entityId);

// Détail d'un bus : trajet, retard, causes possibles (signalements, alertes), déviations
function vehicleDetail(id) {
  const raw = state.rt.vehicles.find((v) => vehicleId(v) === id);
  if (!raw) return null;
  const m = state.model;
  const view = vehiclesView().find((v) => v.id === id) || null;
  const j = m ? G.journey(m, state.rt, raw, Date.now()) : null;
  const routeId = (j && j.routeId) || (view && view.line && view.line.id) || null;
  const stopKeys = new Set(j ? j.stops.map((s) => s.key).filter(Boolean) : []);
  const causes = store.listReports()
    .filter((r) => Date.now() - r.createdAt < 90 * 60 * 1000 && (r.routeId === routeId || (r.stopKey && stopKeys.has(r.stopKey))))
    .sort((a, b) => b.confirmations - a.confirmations)
    .slice(0, 4)
    .map((r) => ({ id: r.id, category: r.category, text: r.text, stopName: r.stopName, confirmations: r.confirmations, official: r.official, createdAt: r.createdAt }));
  const alerts = alertsView().filter((a) => a.lines.some((l) => l.id === routeId));
  // Correspondances : autres lignes au départ des prochains arrêts, entre 1 et 20 min après l'arrivée du bus
  if (j && m) {
    for (const s of j.stops) {
      if (s.state === 'passed' || s.skipped || !s.key) continue;
      const area = m.areas.get(s.key);
      if (!area || area.routeIds.size < 2) continue;
      const at = s.expected ?? s.scheduled;
      const seen = new Set();
      s.connections = G.departures(m, state.rt, s.key, at + 60 * 1000, { limit: 20, horizonMin: 20 })
        .filter((d) => d.line.id !== routeId && d.status !== 'supprime' && d.status !== 'non-desservi')
        .filter((d) => { const k = `${d.line.id}|${d.headsign}`; if (seen.has(k)) return false; seen.add(k); return true; })
        .slice(0, 4)
        .map((d) => ({ line: d.line, headsign: d.headsign, time: d.expected ?? d.scheduled, wait: Math.round(((d.expected ?? d.scheduled) - at) / 60000), realtime: d.realtime }));
    }
  }
  return { vehicle: view, line: m && routeId ? G.routeView(m, routeId) : null, journey: j, causes, alerts };
}

function vehiclesView() {
  const m = state.model;
  // Âge des positions mesuré par rapport à l'heure du flux (et non du serveur), pour tolérer un décalage d'horloge.
  // On garde les positions de moins de 30 min ; l'app affiche leur ancienneté.
  const ref = state.rt.vpHeaderTs ? state.rt.vpHeaderTs * 1000 : Date.now();
  return state.rt.vehicles
    .filter((v) => { const t = tsMs(v.timestamp); return !t || ref - t < 30 * 60 * 1000; })
    .map((v) => {
      const tripId = v.trip && v.trip.tripId;
      const trip = m && tripId ? m.trips.get(tripId) : null;
      const routeId = (v.trip && v.trip.routeId) || (trip && trip.routeId) || null;
      const line = m && routeId ? G.routeView(m, routeId) : null;
      const tu = tripId ? state.rt.tripUpdates.get(tripId) : null;
      let delay = null;
      if (tu) {
        const upd = (tu.stopTimeUpdates || [])[0];
        const ev = upd && (upd.departure || upd.arrival);
        if (ev && ev.delay != null) delay = ev.delay; else if (tu.delay != null) delay = tu.delay;
      }
      let nextStop = null;
      if (m && v.stopId && m.stops.get(v.stopId)) nextStop = m.stops.get(v.stopId).name;
      else if (m && trip && v.currentStopSequence != null) {
        const e = (m.tripStops.get(tripId) || []).find((x) => x.seq === v.currentStopSequence);
        if (e && m.stops.get(e.stopId)) nextStop = m.stops.get(e.stopId).name;
      }
      return {
        id: vehicleId(v),
        label: v.vehicle && v.vehicle.label || null,
        lat: +v.position.latitude.toFixed(6), lon: +v.position.longitude.toFixed(6),
        bearing: v.position.bearing ?? null, speed: v.position.speed ?? null,
        tripId: tripId || null, line, headsign: (trip && trip.headsign) || (v.vehicle && v.vehicle.label) || '',
        nextStop, status: v.currentStatus || null, delay, timestamp: tsMs(v.timestamp),
      };
    });
}

function alertsView() {
  const m = state.model;
  const now = Date.now() / 1000;
  return state.rt.alerts
    .filter((a) => !a.activePeriods || a.activePeriods.some((p) => (!p.start || p.start <= now) && (!p.end || p.end >= now)))
    .map((a) => ({
      id: a.id, header: a.header || '', description: a.description || '', url: a.url || '',
      lines: [...new Set((a.informed || []).map((i) => i.routeId).filter(Boolean))].map((id) => (m ? G.routeView(m, id) : { id })),
      stops: [...new Set((a.informed || []).map((i) => i.stopId).filter(Boolean))].map((id) => (m && m.stops.get(id) ? m.stops.get(id).name : id)),
    }));
}

function statusView() {
  const m = state.model;
  return {
    ok: !!m,
    network: 'Horizon (Châteauroux)',
    version: require('./package.json').version,
    storage: useSupabase ? 'supabase' : 'fichier', accounts: accounts.count(),
    gtfs: m ? { loadedAt: state.gtfsLoadedAt, validFrom: m.validFrom, validTo: m.validTo, lines: m.routes.size, stops: m.areas.size } : null,
    gtfsError: state.gtfsError,
    realtime: {
      tripUpdatesAt: state.rt.tuAt, vehiclePositionsAt: state.rt.vpAt, alertsAt: state.rt.alertsAt,
      trips: state.rt.tripUpdates.size, vehicles: state.rt.vehicles.length, rawVehicleTimestamp: state.rt.vehicles[0] ? state.rt.vehicles[0].timestamp ?? null : null, vehiclesShown: vehiclesView().length, errors: state.rt.errors,
      // Diagnostic : âge (en secondes) des positions par rapport à maintenant et à l'heure du flux
      vehicleAges: (() => {
        const ts = state.rt.vehicles.map((v) => tsMs(v.timestamp)).filter(Boolean);
        if (!ts.length) return null;
        const now = Date.now(), head = state.rt.vpHeaderTs ? state.rt.vpHeaderTs * 1000 : null;
        return { newestVsNow: Math.round((now - Math.max(...ts)) / 1000), oldestVsNow: Math.round((now - Math.min(...ts)) / 1000), feedVsNow: head ? Math.round((now - head) / 1000) : null };
      })(),
      // Diagnostic : part des courses temps réel retrouvées dans le GTFS (doit être proche de 100 %)
      matchedTrips: m ? [...state.rt.tripUpdates.keys()].filter((id) => m.trips.has(id)).length : 0,
    },
    sources: [
      { name: 'Horaires théoriques : Châteauroux Métropole / Keolis (Licence Ouverte)', url: 'https://data.chateauroux-metropole.fr/' },
      ...(CFG.tripUpdatesUrl || CFG.vehiclePositionsUrl ? [{ name: 'Temps réel : Bus Tracker', url: 'https://bus-tracker.fr/' }] : []),
    ],
  };
}

// ---------- HTTP ----------

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function send(res, code, body, headers = {}) {
  res.writeHead(code, { 'Access-Control-Allow-Origin': '*', ...headers });
  res.end(body);
}
const json = (res, code, obj) => send(res, code, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 20000) { reject(new Error('Trop volumineux')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new Error('JSON invalide')); } });
    req.on('error', reject);
  });
}

function visitor(req, body) {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const id = typeof (body && body.clientId) === 'string' ? body.clientId.slice(0, 64) : '';
  return id || ip;
}

function serveStatic(req, res, pathname) {
  const name = decodeURIComponent(pathname).replace(/^\/+/, '');
  const file = path.join(PUBLIC, PUBLIC_FILES.has(name) ? name : 'index.html');
  const ext = path.extname(file);
  const cache = ext === '.png' ? 'public, max-age=86400' : 'no-cache'; // le code est toujours revalidé : les mises à jour arrivent tout de suite
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Introuvable');
    send(res, 200, data, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache });
  });
}

async function handleApi(req, res, url) {
  const m = state.model;
  const p = url.pathname.replace(/\/+$/, '');
  const q = url.searchParams;
  if (req.method === 'OPTIONS') return send(res, 204, '', { 'Access-Control-Allow-Methods': 'GET,POST', 'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token' });

  if (p === '/api/status') return json(res, 200, statusView());
  if (p === '/api/vehicles') return json(res, 200, { updatedAt: state.rt.vpAt, vehicles: vehiclesView() });
  if (p.startsWith('/api/vehicles/')) {
    const d = vehicleDetail(decodeURIComponent(p.slice('/api/vehicles/'.length)));
    return d ? json(res, 200, d) : json(res, 404, { error: 'Ce bus n’est plus localisé.' });
  }
  if (p === '/api/alerts') return json(res, 200, { alerts: alertsView() });

  // Comptes
  const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (p === '/api/auth/register' && req.method === 'POST') {
    const body = await readBody(req);
    if (!store.allow(visitor(req, body), 'register', 10 * 1000)) return json(res, 429, { error: 'Patientez quelques secondes.' });
    try { return json(res, 201, accounts.register(body)); } catch (e) { return json(res, 400, { error: e.message }); }
  }
  if (p === '/api/auth/login' && req.method === 'POST') {
    const body = await readBody(req);
    if (!store.allow(visitor(req, {}), 'login', 3 * 1000)) return json(res, 429, { error: 'Trop d’essais, patientez quelques secondes.' });
    try { return json(res, 200, accounts.login(body)); } catch (e) { return json(res, 401, { error: e.message }); }
  }
  if (p === '/api/auth/logout' && req.method === 'POST') { accounts.logout(bearer); return json(res, 200, { ok: true }); }
  if (p === '/api/me') {
    const u = accounts.userFor(bearer);
    if (!u) return json(res, 401, { error: 'Session expirée, reconnectez-vous.' });
    if (req.method === 'POST') { const body = await readBody(req); try { return json(res, 200, { user: accounts.saveData(bearer, body) }); } catch (e) { return json(res, 400, { error: e.message }); } }
    return json(res, 200, { user: accounts.publicUser(u) });
  }

  // Recherche d'adresses (Géoplateforme IGN), orientée vers Châteauroux
  if (p === '/api/geocode') {
    const qq = (q.get('q') || '').trim().slice(0, 120);
    if (qq.length < 3) return json(res, 200, { places: [] });
    const hit = geoCache.get(qq);
    if (hit && Date.now() - hit.at < 10 * 60 * 1000) return json(res, 200, { places: hit.places });
    try {
      const r = await fetch(`https://data.geopf.fr/geocodage/search?q=${encodeURIComponent(qq)}&limit=6&lat=46.8103&lon=1.6913`, { headers: { 'User-Agent': CFG.userAgent }, signal: AbortSignal.timeout(8000) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      const places = (data.features || []).map((f) => ({
        label: f.properties.label, name: f.properties.name, city: f.properties.city, type: f.properties.type,
        lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0],
      })).filter((x) => G.distM(46.8103, 1.6913, x.lat, x.lon) < 40000);
      geoCache.set(qq, { at: Date.now(), places });
      if (geoCache.size > 500) geoCache.delete(geoCache.keys().next().value);
      return json(res, 200, { places });
    } catch (e) { return json(res, 200, { places: [], error: 'Recherche d’adresse indisponible pour le moment.' }); }
  }

  // Communauté
  if (p === '/api/reports' && req.method === 'GET') return json(res, 200, { reports: store.listReports() });
  if (p === '/api/reports' && req.method === 'POST') {
    const body = await readBody(req);
    const who = visitor(req, body);
    if (!store.allow(who, 'report', 60 * 1000)) return json(res, 429, { error: 'Patientez une minute entre deux signalements.' });
    let stopName = body.stopName;
    if (m && body.stopKey && m.areas.get(body.stopKey)) stopName = m.areas.get(body.stopKey).name;
    return json(res, 201, { report: store.addReport({ ...body, stopName }) });
  }
  let mm;
  if ((mm = p.match(/^\/api\/reports\/([\w-]+)\/(confirm|stale)$/)) && req.method === 'POST') {
    const body = await readBody(req);
    const r = store.vote(mm[1], visitor(req, body), mm[2]);
    return r ? json(res, 200, { report: r }) : json(res, 404, { error: 'Signalement introuvable' });
  }
  if ((mm = p.match(/^\/api\/reports\/([\w-]+)\/answer$/)) && req.method === 'POST') {
    if (!CFG.adminToken || req.headers['x-admin-token'] !== CFG.adminToken) return json(res, 403, { error: 'Réservé à l’équipe réseau' });
    const body = await readBody(req);
    const r = store.answerReport(mm[1], body.text);
    return r ? json(res, 200, { report: r }) : json(res, 404, { error: 'Signalement introuvable' });
  }
  if ((mm = p.match(/^\/api\/chat\/([\w-]{1,40})$/))) {
    const room = mm[1];
    if (req.method === 'GET') return json(res, 200, { room, messages: store.messages(room, +(q.get('since') || 0)) });
    if (req.method === 'POST') {
      const body = await readBody(req);
      const official = !!CFG.adminToken && req.headers['x-admin-token'] === CFG.adminToken;
      if (!official && !store.allow(visitor(req, body), `chat-${room}`, 4000)) return json(res, 429, { error: 'Doucement : un message toutes les 4 secondes.' });
      try { return json(res, 201, { message: store.addMessage(room, { ...body, official }) }); } catch (e) { return json(res, 400, { error: e.message }); }
    }
  }

  // Données réseau
  if (!m) return json(res, 503, { error: 'Données du réseau en cours de chargement', detail: state.gtfsError });
  if (p === '/api/lines') return json(res, 200, { lines: G.lineList(m) });
  // Ponctualité de tous les bus en circulation
  if (p === '/api/punctuality') {
    const now = Date.now();
    const list = [];
    for (const raw of state.rt.vehicles) {
      const id = vehicleId(raw);
      const j = G.journey(m, state.rt, raw, now);
      if (!j) { list.push({ id, line: null, state: 'hlp' }); continue; }
      const ns = j.stops[j.nextIndex];
      const d = j.delay;
      const st = j.canceled ? 'supprime' : d == null ? 'inconnu' : d >= 60 ? 'retard' : d <= -60 ? 'avance' : 'ok';
      list.push({ id, line: G.routeView(m, j.routeId), headsign: j.headsign, delay: d, state: st, nextStop: ns ? ns.name : null, skipped: j.skipped.length });
    }
    const order = { retard: 0, supprime: 1, avance: 2, ok: 3, inconnu: 4, hlp: 5 };
    list.sort((a, b) => order[a.state] - order[b.state] || (b.delay || 0) - (a.delay || 0));
    const count = (k) => list.filter((x) => x.state === k).length;
    return json(res, 200, { updatedAt: state.rt.vpAt, summary: { retard: count('retard'), avance: count('avance'), ok: count('ok'), supprime: count('supprime'), inconnu: count('inconnu'), hlp: count('hlp') }, buses: list });
  }
  // Itinéraire d'un point à un autre
  if (p === '/api/route') {
    const parse = (v) => { const [la, lo] = String(v || '').split(',').map(Number); return isFinite(la) && isFinite(lo) ? { lat: la, lon: lo } : null; };
    const from = parse(q.get('from')), to = parse(q.get('to'));
    if (!from || !to) return json(res, 400, { error: 'Départ et arrivée requis.' });
    const at = +(q.get('at') || Date.now());
    return json(res, 200, R.plan(m, state.rt, from, to, isFinite(at) ? at : Date.now()));
  }
  if ((mm = p.match(/^\/api\/lines\/([^/]+)\/live$/))) {
    // Position des bus de la ligne sur le plan schématique : index (décimal) dans la liste d'arrêts de chaque direction
    const routeId = decodeURIComponent(mm[1]);
    const detail = G.lineDetail(m, routeId);
    if (!detail) return json(res, 404, { error: 'Ligne introuvable' });
    const now = Date.now();
    const buses = [];
    for (const raw of state.rt.vehicles) {
      const tripId = raw.trip && raw.trip.tripId;
      const trip = tripId && m.trips.get(tripId);
      if (!trip || trip.routeId !== routeId) continue;
      const j = G.journey(m, state.rt, raw, now);
      if (!j) continue;
      const dirIdx = Math.max(0, detail.directions.findIndex((d) => d.directionId === trip.directionId));
      const dirStops = detail.directions[dirIdx].stops;
      const nextKey = j.stops[j.nextIndex] && j.stops[j.nextIndex].key;
      let k = nextKey ? dirStops.findIndex((s) => s.key === nextKey) : -1;
      if (k < 0) continue;
      const at = raw.currentStatus === 'STOPPED_AT';
      buses.push({ id: vehicleId(raw), dir: dirIdx, pos: at || k === 0 ? k : k - 0.5, delay: j.delay, headsign: j.headsign });
    }
    return json(res, 200, { routeId, buses });
  }
  if ((mm = p.match(/^\/api\/lines\/([^/]+)$/))) {
    const d = G.lineDetail(m, decodeURIComponent(mm[1]));
    return d ? json(res, 200, d) : json(res, 404, { error: 'Ligne introuvable' });
  }
  if (p === '/api/stops') return json(res, 200, { stops: G.allAreas(m) });
  if (p === '/api/stops/search') return json(res, 200, { stops: G.searchAreas(m, q.get('q') || '') });
  if (p === '/api/stops/nearby') {
    const lat = +q.get('lat'), lon = +q.get('lon');
    if (!isFinite(lat) || !isFinite(lon)) return json(res, 400, { error: 'lat/lon requis' });
    return json(res, 200, { stops: G.nearbyAreas(m, lat, lon, +(q.get('limit') || 6)) });
  }
  if ((mm = p.match(/^\/api\/stops\/([^/]+)$/))) {
    const key = decodeURIComponent(mm[1]);
    const a = m.areas.get(key);
    if (!a) return json(res, 404, { error: 'Arrêt introuvable' });
    const routeId = q.get('line') || null;
    const now = Date.now();
    return json(res, 200, {
      stop: G.areaView(m, a),
      now,
      realtimeAt: state.rt.tuAt,
      departures: G.departures(m, state.rt, key, now, { limit: +(q.get('limit') || 12), routeId }),
      grid: routeId ? G.dayGrid(m, key, routeId, now) : null,
      last: G.lastDepartures(m, state.rt, key, now),
    });
  }
  return json(res, 404, { error: 'Route API inconnue' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url.pathname);
  } catch (e) {
    log('Erreur requête', req.url, e.message);
    if (!res.headersSent) json(res, 400, { error: e.message });
  }
});

async function main() {
  await Promise.all([store.init(), accounts.init()]);
  log(`Stockage : ${useSupabase ? 'Supabase (données conservées)' : 'fichier local (effacé à chaque mise à jour sur Render gratuit)'}`);
  await refreshGtfs();
  await pollRealtime();
  setInterval(pollRealtime, CFG.pollMs);
  setInterval(refreshGtfs, CFG.gtfsRefreshHours * 3600 * 1000);
  setInterval(() => { if (!state.model) refreshGtfs(); }, 5 * 60 * 1000); // nouvel essai si le premier téléchargement a échoué
  setInterval(() => store.clean(), 10 * 60 * 1000);
  server.listen(CFG.port, () => log(`Mobilya prêt sur http://localhost:${CFG.port}`));
}

if (require.main === module) main();
module.exports = { start: main, server, state, CFG, refreshGtfs, pollRealtime };
