'use strict';
// Analyse CSV (RFC 4180) : guillemets, virgules et retours à la ligne dans les champs, BOM.
function parseCsv(text, onRow) {
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  let header = null;
  let field = '';
  let row = [];
  let inQuotes = false;
  const pushRow = () => {
    row.push(field);
    field = '';
    if (!header) {
      header = row.map((h) => h.trim());
    } else if (!(row.length === 1 && row[0] === '')) {
      const obj = {};
      for (let i = 0; i < header.length; i++) obj[header[i]] = row[i] !== undefined ? row[i].trim() : '';
      onRow(obj);
    }
    row = [];
  };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; } else inQuotes = false;
      } else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n') pushRow();
    else if (c === '\r') { /* ignoré */ }
    else field += c;
  }
  if (field !== '' || row.length) pushRow();
}

function readTable(files, name) {
  const buf = files[name];
  const rows = [];
  if (!buf) return rows;
  parseCsv(buf.toString('utf8'), (r) => rows.push(r));
  return rows;
}

module.exports = { parseCsv, readTable };
