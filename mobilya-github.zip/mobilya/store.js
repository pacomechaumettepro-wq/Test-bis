'use strict';
// Stockage simple (fichier JSON) des signalements et des messages du chat.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const REPORT_TTL_MS = 3 * 3600 * 1000;
const CATEGORIES = ['retard', 'complet', 'arret', 'incident', 'proprete', 'autre'];

class Store {
  constructor(file) {
    this.file = file;
    this.data = { reports: [], chat: {} };
    try { this.data = { ...this.data, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* premier lancement */ }
    this.saveTimer = null;
    this.rate = new Map();
  }
  save() {
    clearTimeout(this.saveTimer);
    this.saveTimer = setTimeout(() => {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFile(this.file, JSON.stringify(this.data), () => {});
    }, 500);
  }
  // Limite de fréquence par visiteur (id anonyme ou IP)
  allow(who, action, everyMs) {
    const k = `${who}|${action}`;
    const last = this.rate.get(k) || 0;
    if (Date.now() - last < everyMs) return false;
    this.rate.set(k, Date.now());
    return true;
  }
  clean() {
    const now = Date.now();
    this.data.reports = this.data.reports.filter((r) => now - r.createdAt < REPORT_TTL_MS && r.staleVotes < 3);
    for (const room of Object.keys(this.data.chat)) this.data.chat[room] = this.data.chat[room].slice(-200);
  }
  listReports() {
    this.clean();
    return this.data.reports.slice().sort((a, b) => b.createdAt - a.createdAt).map(({ voters, ...r }) => r);
  }
  addReport({ routeId, stopKey, stopName, category, text, author }) {
    if (!CATEGORIES.includes(category)) throw new Error('Catégorie inconnue');
    const r = {
      id: crypto.randomUUID(), routeId: routeId || null, stopKey: stopKey || null, stopName: clip(stopName, 60),
      category, text: clip(text, 280), author: clip(author, 30) || 'Usager', createdAt: Date.now(),
      confirmations: 1, staleVotes: 0, official: null, voters: [],
    };
    this.data.reports.unshift(r);
    this.save();
    return r;
  }
  vote(id, voter, kind) {
    const r = this.data.reports.find((x) => x.id === id);
    if (!r) return null;
    if (!r.voters.includes(voter)) {
      r.voters.push(voter);
      if (kind === 'confirm') r.confirmations++; else r.staleVotes++;
      this.save();
    }
    const { voters, ...out } = r;
    return out;
  }
  answerReport(id, text) {
    const r = this.data.reports.find((x) => x.id === id);
    if (!r) return null;
    r.official = clip(text, 280);
    this.save();
    return r;
  }
  messages(room, since = 0) {
    return (this.data.chat[room] || []).filter((m) => m.at > since);
  }
  addMessage(room, { author, text, official }) {
    const m = { id: crypto.randomUUID(), author: clip(author, 30) || 'Usager', text: clip(text, 500), at: Date.now(), official: !!official };
    if (!m.text) throw new Error('Message vide');
    (this.data.chat[room] ||= []).push(m);
    this.save();
    return m;
  }
}

function clip(s, n) {
  if (typeof s !== 'string') return '';
  return s.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
}

module.exports = { Store, CATEGORIES };
