'use strict';
/* Mobilya — maillage 3D argenté animé (WebGL).
   Un seul contexte WebGL pour toute l'app : chaque cible (<canvas data-mesh>) reçoit une copie de l'image calculée,
   avec sa propre graine. S'arrête quand la page est masquée ; une seule image fixe si l'usager réduit les animations. */
(() => {
  const VS = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  const FS = `
precision mediump float;
uniform vec2 r; uniform float t; uniform float seed; uniform float glow; uniform float light;
float h(vec2 p){
  float v = sin(p.x*1.35 + t*.32 + seed + sin(p.y*1.1 - t*.22)*1.4)*.55;
  v += sin(p.y*1.9 - t*.27 + seed*1.7 + sin(p.x*.8 + t*.18)*1.6)*.38;
  v += sin((p.x - p.y)*2.6 + t*.45)*.09;
  return v;
}
void main(){
  vec2 uv = (gl_FragCoord.xy - .5*r) / min(r.x, r.y);
  vec2 p = uv*2.3 + vec2(seed*.37, -seed*.21);
  float e = .012;
  float c = h(p);
  float dx = (h(p+vec2(e,0.)) - h(p-vec2(e,0.))) / (2.*e);
  float dy = (h(p+vec2(0.,e)) - h(p-vec2(0.,e))) / (2.*e);
  vec3 n = normalize(vec3(-dx, -dy, 1.25));
  vec3 l = normalize(vec3(-.45, .65, .62));
  float diff = max(dot(n, l), 0.);
  float spec = pow(max(dot(reflect(-l, n), vec3(0.,0.,1.)), 0.), 9.);
  float rim = pow(1. - n.z, 1.6);
  // reflets de soie qui glissent le long des plis
  float band = pow(.5 + .5*sin(c*7. - t*.7 + p.x*.6), 8.);
  vec3 col = vec3(.018,.018,.022);
  col += vec3(.52,.53,.58) * pow(diff, 4.) * .5;
  col += vec3(.92,.93,1.) * spec * .32;
  col += vec3(.78,.8,.88) * band * (.1 + .25*diff);
  col += vec3(.62,.64,.72) * rim * .5;
  // maillage : lignes qui épousent la surface
  vec2 g = (p + n.xy*.35) * 3.2;
  vec2 f = abs(fract(g) - .5);
  float line = 1. - smoothstep(0., .035, min(f.x, f.y));
  col += vec3(.75,.77,.85) * line * (.06 + .3*spec + .12*band + .08*rim);
  col *= glow * (1. - .38*dot(uv, uv));
  // Variante nacre (mode clair) : fond perle, plis gris doux, reflets blancs, maillage graphite léger
  vec3 pearl = vec3(.925,.932,.948);
  pearl -= vec3(.16,.155,.14) * (1. - pow(diff, 1.6)) * .55;
  pearl += vec3(1.) * spec * .22 + vec3(1.,1.,1.02) * band * (.08 + .14*diff);
  pearl -= vec3(.10) * rim * .35;
  pearl -= vec3(.34,.33,.30) * line * (.10 + .10*band);
  pearl = mix(pearl, vec3(.95,.955,.965), .25*dot(uv, uv));
  gl_FragColor = vec4(mix(col, pearl, light), 1.);
}`;
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const SIZE = 384;
  let gl = null, prog = null, src = null, loc = {}, raf = 0, last = 0, ok = null;
  const targets = new Set();

  function init() {
    if (ok !== null) return ok;
    try {
      src = document.createElement('canvas');
      src.width = SIZE; src.height = SIZE;
      gl = src.getContext('webgl', { antialias: false, premultipliedAlpha: false, preserveDrawingBuffer: true }) || src.getContext('experimental-webgl');
      if (!gl) return (ok = false);
      const sh = (type, code) => { const s = gl.createShader(type); gl.shaderSource(s, code); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
      prog = gl.createProgram();
      gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('link');
      gl.useProgram(prog);
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const a = gl.getAttribLocation(prog, 'a');
      gl.enableVertexAttribArray(a);
      gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
      for (const k of ['r', 't', 'seed', 'glow', 'light']) loc[k] = gl.getUniformLocation(prog, k);
      gl.viewport(0, 0, SIZE, SIZE);
      return (ok = true);
    } catch (e) { return (ok = false); }
  }

  function drawTarget(c, time) {
    const w = c.clientWidth, h = c.clientHeight;
    if (!w || !h) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2) * 0.75;
    const W = Math.round(w * dpr), H = Math.round(h * dpr);
    if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
    // Le rendu suit le format de la cible pour ne pas étirer le maillage
    const aspect = W / H;
    gl.uniform2f(loc.r, aspect >= 1 ? SIZE : SIZE * aspect, aspect >= 1 ? SIZE / aspect : SIZE);
    gl.uniform1f(loc.t, time);
    gl.uniform1f(loc.seed, +(c.dataset.seed || 0));
    gl.uniform1f(loc.glow, +(c.dataset.glow || 1));
    gl.uniform1f(loc.light, c.dataset.dark != null || document.documentElement.getAttribute('data-theme') === 'dark' ? 0 : 1);
    const vw = aspect >= 1 ? SIZE : Math.round(SIZE * aspect), vh = aspect >= 1 ? Math.round(SIZE / aspect) : SIZE;
    gl.viewport(0, 0, vw, vh);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    const ctx = c.getContext('2d');
    ctx.drawImage(src, 0, SIZE - vh, vw, vh, 0, 0, W, H);
  }

  function frame(now) {
    raf = 0;
    for (const c of [...targets]) if (!c.isConnected) targets.delete(c);
    if (!targets.size || document.hidden) return;
    if (now - last >= 33) { // ~30 images/s : fluide et économe
      last = now;
      const time = now / 1000;
      for (const c of targets) drawTarget(c, time);
    }
    if (!reduce) raf = requestAnimationFrame(frame);
  }

  function attach(root = document) {
    if (!init()) return;
    root.querySelectorAll('canvas[data-mesh]').forEach((c) => targets.add(c));
    if (!raf) raf = requestAnimationFrame(frame);
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden && targets.size && !raf) raf = requestAnimationFrame(frame); });
  window.addEventListener('resize', () => { if (reduce) requestAnimationFrame(frame); });
  window.Mesh = { attach };
})();
