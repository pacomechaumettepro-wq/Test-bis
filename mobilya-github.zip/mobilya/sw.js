// Service worker : l'interface reste disponible hors connexion ; les données (API) passent toujours par le réseau.
// À chaque nouvelle version, les anciens caches sont supprimés et les pages ouvertes rechargées.
const VERSION = 'mobilya-1.3.0-test';
const DATA = 'mobilya-data'; // horaires et lignes consultés, gardés pour le mode hors connexion
const SHELL = ['/', '/index.html', '/app.css', '/app.js', '/mesh.js', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).catch(() => {}).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    const old = keys.filter((k) => k !== VERSION && k !== DATA);
    await Promise.all(old.map((k) => caches.delete(k)));
    await self.clients.claim();
    if (old.length) for (const c of await self.clients.matchAll({ type: 'window' })) c.navigate(c.url).catch(() => {});
  })());
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  // Horaires, arrêts et lignes : réseau d'abord, copie enregistrée si la connexion manque
  if (url.pathname.startsWith('/api/stops') || url.pathname.startsWith('/api/lines')) {
    e.respondWith(
      fetch(e.request).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(DATA).then((c) => c.put(e.request, copy)); }
        return res;
      }).catch(async () => {
        const r = await caches.match(e.request, { cacheName: DATA });
        if (!r) throw new Error('hors connexion');
        const h = new Headers(r.headers);
        h.set('X-Mobilya-Offline', '1');
        return new Response(await r.blob(), { status: 200, headers: h });
      })
    );
    return;
  }
  if (url.pathname.startsWith('/api/')) return;
  // Réseau d'abord, sans cache HTTP ; copie locale seulement en secours hors connexion
  e.respondWith(
    fetch(e.request, { cache: 'no-store' }).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(e.request, copy)); }
      return res;
    }).catch(() => caches.match(e.request).then((r) => r || caches.match('/index.html')))
  );
});
