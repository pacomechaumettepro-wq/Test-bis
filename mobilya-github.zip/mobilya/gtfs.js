'use strict';
// Chargement et indexation d'un GTFS statique, puis calcul des prochains passages
// en combinant les horaires théoriques et le temps réel (GTFS-RT).
const { unzip } = require('./zip');
const { readTable } = require('./csv');
const T = require('./time');

const slug = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'arret';
const fold = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const titleCase = (s) => {
  if (!s || s !== s.toUpperCase()) return s;
  return s.toLowerCase().replace(/(^|[\s\-'’/(])(\p{L})/gu, (m, a, b) => a + b.toUpperCase());
};
function distM(aLat, aLon, bLat, bLon) {
  const R = 6371000, toR = Math.PI / 180;
  const dLat = (bLat - aLat) * toR, dLon = (bLon - aLon) * toR;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * toR) * Math.cos(bLat * toR) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
const hex = (c, d) => (/^[0-9a-fA-F]{6}$/.test(c || '') ? `#${c.toUpperCase()}` : d);

function naturalCompare(a, b) {
  return a.localeCompare(b, 'fr', { numeric: true, sensitivity: 'base' });
}

function loadGtfs(zipBuffer) {
  const files = unzip(zipBuffer);
  if (!files['stops.txt'] || !files['trips.txt'] || !files['stop_times.txt']) throw new Error('GTFS incomplet : stops/trips/stop_times manquants');

  const routes = new Map();
  for (const r of readTable(files, 'routes.txt')) {
    routes.set(r.route_id, {
      id: r.route_id,
      shortName: r.route_short_name || r.route_id,
      longName: titleCase(r.route_long_name || ''),
      color: hex(r.route_color, '#3A3A40'),
      textColor: hex(r.route_text_color, '#FFFFFF'),
      sortOrder: r.route_sort_order ? +r.route_sort_order : null,
      type: r.route_type ? +r.route_type : 3,
    });
  }

  const stops = new Map();
  for (const s of readTable(files, 'stops.txt')) {
    stops.set(s.stop_id, {
      id: s.stop_id, name: titleCase(s.stop_name || s.stop_id), lat: +s.stop_lat, lon: +s.stop_lon,
      parent: s.parent_station || '', locationType: s.location_type ? +s.location_type : 0,
      wheelchair: s.wheelchair_boarding === '1',
    });
  }

  const trips = new Map();
  for (const t of readTable(files, 'trips.txt')) {
    trips.set(t.trip_id, {
      id: t.trip_id, routeId: t.route_id, serviceId: t.service_id, headsign: titleCase(t.trip_headsign || ''),
      directionId: t.direction_id === '' || t.direction_id === undefined ? 0 : +t.direction_id, shapeId: t.shape_id || '',
    });
  }

  const tripStops = new Map();
  for (const st of readTable(files, 'stop_times.txt')) {
    if (!trips.has(st.trip_id)) continue;
    const arr = T.hmsToSec(st.arrival_time);
    const dep = T.hmsToSec(st.departure_time);
    let list = tripStops.get(st.trip_id);
    if (!list) tripStops.set(st.trip_id, (list = []));
    list.push({ stopId: st.stop_id, seq: +st.stop_sequence, arr: arr ?? dep, dep: dep ?? arr });
  }
  for (const [tripId, list] of tripStops) {
    list.sort((a, b) => a.seq - b.seq);
    // Interpolation simple des horaires manquants
    for (let i = 0; i < list.length; i++) {
      if (list[i].dep == null) {
        let j = i + 1;
        while (j < list.length && list[j].dep == null) j++;
        const a = list[i - 1], b = list[j];
        if (a && b) {
          for (let k = i; k < j; k++) { const v = Math.round(a.dep + ((b.arr - a.dep) * (k - i + 1)) / (j - i + 1)); list[k].arr = list[k].dep = v; }
        }
        i = j - 1;
      }
    }
    if (!trips.get(tripId).headsign && list.length) trips.get(tripId).headsign = stops.get(list[list.length - 1].stopId)?.name || '';
  }

  // Index des départs par arrêt
  const stopDeps = new Map();
  for (const [tripId, list] of tripStops) {
    for (let i = 0; i < list.length - 1; i++) { // le terminus n'a pas de départ
      const e = list[i];
      if (e.dep == null) continue;
      let arr = stopDeps.get(e.stopId);
      if (!arr) stopDeps.set(e.stopId, (arr = []));
      arr.push({ tripId, dep: e.dep, idx: i });
    }
  }
  for (const arr of stopDeps.values()) arr.sort((a, b) => a.dep - b.dep);

  // Calendriers
  const calendar = new Map();
  for (const c of readTable(files, 'calendar.txt')) {
    calendar.set(c.service_id, {
      days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map((d) => c[d] === '1'),
      start: c.start_date, end: c.end_date,
    });
  }
  const exceptions = new Map();
  for (const c of readTable(files, 'calendar_dates.txt')) {
    let m = exceptions.get(c.service_id);
    if (!m) exceptions.set(c.service_id, (m = new Map()));
    m.set(c.date, +c.exception_type);
  }
  let validFrom = null, validTo = null;
  for (const c of calendar.values()) {
    if (!validFrom || c.start < validFrom) validFrom = c.start;
    if (!validTo || c.end > validTo) validTo = c.end;
  }
  for (const m of exceptions.values()) for (const [d, t] of m) if (t === 1) {
    if (!validFrom || d < validFrom) validFrom = d;
    if (!validTo || d > validTo) validTo = d;
  }

  // Formes des lignes (optionnel)
  const shapes = new Map();
  for (const s of readTable(files, 'shapes.txt')) {
    let arr = shapes.get(s.shape_id);
    if (!arr) shapes.set(s.shape_id, (arr = []));
    arr.push([+s.shape_pt_sequence, +s.shape_pt_lat, +s.shape_pt_lon]);
  }
  for (const [id, arr] of shapes) shapes.set(id, arr.sort((a, b) => a[0] - b[0]).map((p) => [+p[1].toFixed(6), +p[2].toFixed(6)]));

  // Pôles d'arrêts : regroupement des quais par nom et proximité (pour l'usager, "Voltaire" = un seul arrêt)
  const servedStops = new Set();
  for (const list of tripStops.values()) for (const e of list) servedStops.add(e.stopId);
  const areas = new Map();
  const areaOfStop = new Map();
  const byName = new Map();
  for (const s of stops.values()) {
    if (s.locationType === 1 || !servedStops.has(s.id)) continue;
    const parent = s.parent && stops.get(s.parent);
    const name = parent ? parent.name : s.name;
    let clusters = byName.get(name);
    if (!clusters) byName.set(name, (clusters = []));
    let cl = clusters.find((c) => distM(c.lat, c.lon, s.lat, s.lon) < 400);
    if (!cl) {
      const base = slug(name);
      cl = { key: clusters.length ? `${base}-${clusters.length + 1}` : base, name, lat: s.lat, lon: s.lon, stopIds: [], routeIds: new Set() };
      clusters.push(cl);
      areas.set(cl.key, cl);
    }
    cl.stopIds.push(s.id);
    cl.lat = (cl.lat * (cl.stopIds.length - 1) + s.lat) / cl.stopIds.length;
    cl.lon = (cl.lon * (cl.stopIds.length - 1) + s.lon) / cl.stopIds.length;
    areaOfStop.set(s.id, cl.key);
  }
  for (const [tripId, list] of tripStops) {
    const routeId = trips.get(tripId).routeId;
    for (const e of list) { const k = areaOfStop.get(e.stopId); if (k) areas.get(k).routeIds.add(routeId); }
  }

  // Description des lignes : directions, terminus, arrêts du trajet le plus long
  const lineInfo = new Map();
  for (const route of routes.values()) lineInfo.set(route.id, { directions: new Map() });
  for (const trip of trips.values()) {
    const info = lineInfo.get(trip.routeId);
    const list = tripStops.get(trip.id);
    if (!info || !list) continue;
    let d = info.directions.get(trip.directionId);
    if (!d) info.directions.set(trip.directionId, (d = { headsigns: new Map(), best: null }));
    d.headsigns.set(trip.headsign, (d.headsigns.get(trip.headsign) || 0) + 1);
    if (!d.best || tripStops.get(d.best).length < list.length) d.best = trip.id;
  }

  return { routes, stops, trips, tripStops, stopDeps, calendar, exceptions, shapes, areas, areaOfStop, lineInfo, validFrom, validTo, loadedAt: Date.now() };
}

function serviceActive(model, serviceId, ymd) {
  const ex = model.exceptions.get(serviceId);
  if (ex && ex.has(ymd)) return ex.get(ymd) === 1;
  const c = model.calendar.get(serviceId);
  if (!c) return false;
  if (ymd < c.start || ymd > c.end) return false;
  return c.days[T.weekdayOf(ymd)];
}

function routeView(model, routeId) {
  const r = model.routes.get(routeId);
  if (!r) return { id: routeId, shortName: routeId, longName: '', color: '#3A3A40', textColor: '#FFFFFF' };
  return { id: r.id, shortName: r.shortName, longName: r.longName, color: r.color, textColor: r.textColor };
}

// Applique le temps réel à un passage. Renvoie { expected, delay, status, realtime }
function applyRealtime(model, rt, tripId, ymd, idx, schedMs, baseMs) {
  const tu = rt && rt.tripUpdates.get(tripId);
  if (!tu) return { expected: null, delay: null, status: 'theorique', realtime: false };
  if (tu.trip && tu.trip.startDate && tu.trip.startDate !== ymd) return { expected: null, delay: null, status: 'theorique', realtime: false };
  if (tu.trip && (tu.trip.scheduleRelationship === 'CANCELED' || tu.trip.scheduleRelationship === 'DELETED')) {
    return { expected: null, delay: null, status: 'supprime', realtime: true };
  }
  const list = model.tripStops.get(tripId);
  let best = null, bestIdx = -1;
  for (const upd of tu.stopTimeUpdates || []) {
    let i = -1;
    if (upd.stopSequence != null) i = list.findIndex((e) => e.seq === upd.stopSequence);
    if (i < 0 && upd.stopId) i = list.findIndex((e) => e.stopId === upd.stopId);
    if (i < 0 || i > idx) continue;
    if (i >= bestIdx) { best = upd; bestIdx = i; }
  }
  let delay = null, expected = null;
  if (best) {
    if (best.scheduleRelationship === 'NO_DATA') return { expected: null, delay: null, status: 'theorique', realtime: false };
    if (bestIdx === idx && best.scheduleRelationship === 'SKIPPED') return { expected: null, delay: null, status: 'non-desservi', realtime: true };
    const ev = (best.departure && (best.departure.time || best.departure.delay != null)) ? best.departure : best.arrival;
    if (ev) {
      if (bestIdx === idx && ev.time) { expected = ev.time * 1000; delay = Math.round((expected - schedMs) / 1000); }
      else if (ev.delay != null) delay = ev.delay;
      else if (ev.time) {
        const ref = list[bestIdx];
        const refSched = baseMs + ((ev === best.departure ? ref.dep : ref.arr) * 1000);
        delay = Math.round((ev.time * 1000 - refSched) / 1000);
      }
    }
  } else if (tu.delay != null) delay = tu.delay;
  if (delay == null) return { expected: null, delay: null, status: 'theorique', realtime: false };
  if (expected == null) expected = schedMs + delay * 1000;
  const status = delay >= 120 ? 'retard' : delay <= -60 ? 'avance' : 'ok';
  return { expected, delay, status, realtime: true };
}

function departures(model, rt, areaKey, nowMs, { limit = 12, horizonMin = 120, routeId = null } = {}) {
  const area = model.areas.get(areaKey);
  if (!area) return null;
  const today = T.parts(nowMs).ymd;
  const out = [];
  for (const [ymd, shift] of [[today, 0], [T.shiftYmd(today, -1), 86400]]) {
    const base = T.serviceBase(ymd);
    const nowSec = Math.floor((nowMs - base) / 1000);
    const from = nowSec - 30 * 60; // on garde les passages récents pour les bus en retard
    const to = nowSec + horizonMin * 60;
    if (shift && to < 86400) continue;
    for (const stopId of area.stopIds) {
      const deps = model.stopDeps.get(stopId);
      if (!deps) continue;
      let lo = 0, hi = deps.length;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (deps[mid].dep < from) lo = mid + 1; else hi = mid; }
      for (let i = lo; i < deps.length && deps[i].dep <= to; i++) {
        const d = deps[i];
        const trip = model.trips.get(d.tripId);
        if (routeId && trip.routeId !== routeId) continue;
        if (!serviceActive(model, trip.serviceId, ymd)) continue;
        const schedMs = base + d.dep * 1000;
        const r = applyRealtime(model, rt, d.tripId, ymd, d.idx, schedMs, base);
        const effective = r.expected ?? schedMs;
        if (effective < nowMs - 30 * 1000) continue; // déjà parti
        if (r.status === 'supprime' && schedMs < nowMs - 60 * 1000) continue;
        if (!r.realtime && schedMs < nowMs - 60 * 1000) continue;
        out.push({
          tripId: d.tripId, line: routeView(model, trip.routeId), headsign: trip.headsign,
          stopId, scheduled: schedMs, expected: r.expected, delay: r.delay, status: r.status, realtime: r.realtime,
        });
      }
    }
  }
  out.sort((a, b) => (a.expected ?? a.scheduled) - (b.expected ?? b.scheduled));
  return out.slice(0, limit);
}

// Grille théorique de la journée pour un arrêt et une ligne (heure -> minutes)
function dayGrid(model, areaKey, routeId, nowMs) {
  const area = model.areas.get(areaKey);
  if (!area) return null;
  const ymd = T.parts(nowMs).ymd;
  const byHeadsign = new Map();
  for (const stopId of area.stopIds) {
    for (const d of model.stopDeps.get(stopId) || []) {
      const trip = model.trips.get(d.tripId);
      if (trip.routeId !== routeId || !serviceActive(model, trip.serviceId, ymd)) continue;
      let m = byHeadsign.get(trip.headsign);
      if (!m) byHeadsign.set(trip.headsign, (m = new Map()));
      const h = Math.floor(d.dep / 3600), min = Math.floor((d.dep % 3600) / 60);
      if (!m.has(h)) m.set(h, new Set());
      m.get(h).add(min);
    }
  }
  return [...byHeadsign].map(([headsign, m]) => ({
    headsign,
    hours: [...m.keys()].sort((a, b) => a - b).map((h) => ({ hour: h % 24, minutes: [...m.get(h)].sort((a, b) => a - b) })),
  }));
}

function lineList(model) {
  return [...model.routes.values()]
    .sort((a, b) => (a.sortOrder ?? 1e9) - (b.sortOrder ?? 1e9) || naturalCompare(a.shortName, b.shortName))
    .map((r) => {
      const info = model.lineInfo.get(r.id);
      const termini = [];
      for (const d of [...info.directions.keys()].sort()) {
        const hs = [...info.directions.get(d).headsigns].sort((a, b) => b[1] - a[1])[0];
        if (hs && hs[0]) termini.push(hs[0]);
      }
      return { ...routeView(model, r.id), termini };
    })
    .filter((r) => model.lineInfo.get(r.id).directions.size > 0);
}

function lineDetail(model, routeId) {
  const r = model.routes.get(routeId);
  if (!r) return null;
  const info = model.lineInfo.get(routeId);
  const directions = [];
  for (const id of [...info.directions.keys()].sort()) {
    const d = info.directions.get(id);
    const list = model.tripStops.get(d.best) || [];
    const trip = model.trips.get(d.best);
    const stopsOut = [];
    for (const e of list) {
      const s = model.stops.get(e.stopId);
      const key = model.areaOfStop.get(e.stopId);
      const name = key ? model.areas.get(key).name : s ? s.name : e.stopId;
      if (stopsOut.length && stopsOut[stopsOut.length - 1].name === name) continue;
      stopsOut.push({ key: key || null, name, lat: s ? s.lat : null, lon: s ? s.lon : null });
    }
    const shape = trip && trip.shapeId && model.shapes.get(trip.shapeId);
    directions.push({
      directionId: id,
      headsign: [...d.headsigns].sort((a, b) => b[1] - a[1])[0]?.[0] || '',
      stops: stopsOut,
      path: shape && shape.length > 1 ? shape : stopsOut.filter((s) => s.lat != null).map((s) => [s.lat, s.lon]),
    });
  }
  return { ...routeView(model, routeId), directions };
}

function areaView(model, a, extra = {}) {
  return {
    key: a.key, name: a.name, lat: +a.lat.toFixed(6), lon: +a.lon.toFixed(6),
    lines: [...a.routeIds].map((id) => routeView(model, id)).sort((x, y) => naturalCompare(x.shortName, y.shortName)),
    ...extra,
  };
}

function searchAreas(model, q, limit = 15) {
  const f = fold(q.trim());
  if (!f) return [];
  const res = [];
  for (const a of model.areas.values()) {
    const n = fold(a.name);
    const i = n.indexOf(f);
    if (i >= 0) res.push([i === 0 ? 0 : 1, a]);
  }
  return res.sort((x, y) => x[0] - y[0] || x[1].name.localeCompare(y[1].name, 'fr')).slice(0, limit).map(([, a]) => areaView(model, a));
}

function nearbyAreas(model, lat, lon, limit = 6) {
  return [...model.areas.values()]
    .map((a) => [distM(lat, lon, a.lat, a.lon), a])
    .sort((x, y) => x[0] - y[0]).slice(0, limit)
    .map(([d, a]) => areaView(model, a, { distance: Math.round(d) }));
}

function allAreas(model) {
  return [...model.areas.values()].map((a) => ({ key: a.key, name: a.name, lat: +a.lat.toFixed(5), lon: +a.lon.toFixed(5) }));
}

module.exports = {
  loadGtfs, serviceActive, departures, dayGrid, lineList, lineDetail,
  areaView, searchAreas, nearbyAreas, allAreas, routeView, distM, applyRealtime,
};
