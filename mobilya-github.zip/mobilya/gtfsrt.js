'use strict';
// Décodeur GTFS-Realtime (protobuf) minimal, sans dépendance.
// Couvre FeedMessage, TripUpdate, VehiclePosition et Alert.

class Reader {
  constructor(buf) { this.buf = buf; this.pos = 0; }
  eof() { return this.pos >= this.buf.length; }
  varint() {
    let result = 0n;
    let shift = 0n;
    for (;;) {
      if (this.pos >= this.buf.length) throw new Error('Protobuf tronqué');
      const b = this.buf[this.pos++];
      result |= BigInt(b & 0x7f) << shift;
      if (!(b & 0x80)) return result;
      shift += 7n;
      if (shift > 70n) throw new Error('Varint invalide');
    }
  }
  tag() { const t = Number(this.varint()); return { field: t >>> 3, wire: t & 7 }; }
  bytes() { const len = Number(this.varint()); const b = this.buf.subarray(this.pos, this.pos + len); this.pos += len; return b; }
  float() { const v = this.buf.readFloatLE(this.pos); this.pos += 4; return v; }
  double() { const v = this.buf.readDoubleLE(this.pos); this.pos += 8; return v; }
  skip(wire) {
    if (wire === 0) this.varint();
    else if (wire === 1) this.pos += 8;
    else if (wire === 2) this.bytes();
    else if (wire === 5) this.pos += 4;
    else throw new Error(`Type de champ protobuf non géré (${wire})`);
  }
}

const u = (v) => Number(BigInt.asUintN(64, v));
const i32 = (v) => Number(BigInt.asIntN(32, v));
const i64 = (v) => Number(BigInt.asIntN(64, v));
const str = (b) => b.toString('utf8');

// Lit un message : handlers[field] = (reader, wire, out) => void
function msg(buf, handlers, out = {}) {
  const r = new Reader(buf);
  while (!r.eof()) {
    const { field, wire } = r.tag();
    const h = handlers[field];
    if (h) h(r, wire, out); else r.skip(wire);
  }
  return out;
}

const TRIP_REL = { 0: 'SCHEDULED', 1: 'ADDED', 2: 'UNSCHEDULED', 3: 'CANCELED', 5: 'REPLACEMENT', 6: 'DUPLICATED', 7: 'DELETED' };
const STOP_REL = { 0: 'SCHEDULED', 1: 'SKIPPED', 2: 'NO_DATA', 3: 'UNSCHEDULED' };
const VEH_STATUS = { 0: 'INCOMING_AT', 1: 'STOPPED_AT', 2: 'IN_TRANSIT_TO' };

const tripDescriptor = (b) => msg(b, {
  1: (r, w, o) => { o.tripId = str(r.bytes()); },
  2: (r, w, o) => { o.startTime = str(r.bytes()); },
  3: (r, w, o) => { o.startDate = str(r.bytes()); },
  4: (r, w, o) => { o.scheduleRelationship = TRIP_REL[Number(r.varint())] || 'SCHEDULED'; },
  5: (r, w, o) => { o.routeId = str(r.bytes()); },
  6: (r, w, o) => { o.directionId = u(r.varint()); },
});
const vehicleDescriptor = (b) => msg(b, {
  1: (r, w, o) => { o.id = str(r.bytes()); },
  2: (r, w, o) => { o.label = str(r.bytes()); },
  3: (r, w, o) => { o.licensePlate = str(r.bytes()); },
});
const stopTimeEvent = (b) => msg(b, {
  1: (r, w, o) => { o.delay = i32(r.varint()); },
  2: (r, w, o) => { o.time = i64(r.varint()); },
  3: (r, w, o) => { o.uncertainty = i32(r.varint()); },
});
const stopTimeUpdate = (b) => msg(b, {
  1: (r, w, o) => { o.stopSequence = u(r.varint()); },
  2: (r, w, o) => { o.arrival = stopTimeEvent(r.bytes()); },
  3: (r, w, o) => { o.departure = stopTimeEvent(r.bytes()); },
  4: (r, w, o) => { o.stopId = str(r.bytes()); },
  5: (r, w, o) => { o.scheduleRelationship = STOP_REL[Number(r.varint())] || 'SCHEDULED'; },
});
const tripUpdate = (b) => msg(b, {
  1: (r, w, o) => { o.trip = tripDescriptor(r.bytes()); },
  2: (r, w, o) => { (o.stopTimeUpdates ||= []).push(stopTimeUpdate(r.bytes())); },
  3: (r, w, o) => { o.vehicle = vehicleDescriptor(r.bytes()); },
  4: (r, w, o) => { o.timestamp = u(r.varint()); },
  5: (r, w, o) => { o.delay = i32(r.varint()); },
});
const position = (b) => msg(b, {
  1: (r, w, o) => { o.latitude = r.float(); },
  2: (r, w, o) => { o.longitude = r.float(); },
  3: (r, w, o) => { o.bearing = r.float(); },
  4: (r, w, o) => { o.odometer = r.double(); },
  5: (r, w, o) => { o.speed = r.float(); },
});
const vehiclePosition = (b) => msg(b, {
  1: (r, w, o) => { o.trip = tripDescriptor(r.bytes()); },
  2: (r, w, o) => { o.position = position(r.bytes()); },
  3: (r, w, o) => { o.currentStopSequence = u(r.varint()); },
  4: (r, w, o) => { o.timestamp = u(r.varint()); },
  5: (r, w, o) => { o.currentStatus = VEH_STATUS[Number(r.varint())]; },
  7: (r, w, o) => { o.stopId = str(r.bytes()); },
  8: (r, w, o) => { o.vehicle = vehicleDescriptor(r.bytes()); },
  9: (r, w, o) => { o.occupancyStatus = Number(r.varint()); },
});
const translated = (b) => {
  const t = msg(b, { 1: (r, w, o) => { (o.list ||= []).push(msg(r.bytes(), { 1: (rr, ww, oo) => { oo.text = str(rr.bytes()); }, 2: (rr, ww, oo) => { oo.lang = str(rr.bytes()); } })); } });
  const list = t.list || [];
  const fr = list.find((x) => (x.lang || '').startsWith('fr')) || list[0];
  return fr ? fr.text : '';
};
const alert = (b) => msg(b, {
  1: (r, w, o) => { (o.activePeriods ||= []).push(msg(r.bytes(), { 1: (rr, ww, oo) => { oo.start = u(rr.varint()); }, 2: (rr, ww, oo) => { oo.end = u(rr.varint()); } })); },
  5: (r, w, o) => { (o.informed ||= []).push(msg(r.bytes(), {
    1: (rr, ww, oo) => { oo.agencyId = str(rr.bytes()); },
    2: (rr, ww, oo) => { oo.routeId = str(rr.bytes()); },
    3: (rr, ww, oo) => { oo.routeType = i32(rr.varint()); },
    4: (rr, ww, oo) => { oo.trip = tripDescriptor(rr.bytes()); },
    5: (rr, ww, oo) => { oo.stopId = str(rr.bytes()); },
  })); },
  6: (r, w, o) => { o.cause = Number(r.varint()); },
  7: (r, w, o) => { o.effect = Number(r.varint()); },
  8: (r, w, o) => { o.url = translated(r.bytes()); },
  10: (r, w, o) => { o.header = translated(r.bytes()); },
  11: (r, w, o) => { o.description = translated(r.bytes()); },
});

function decodeFeed(buf) {
  return msg(buf, {
    1: (r, w, o) => { o.header = msg(r.bytes(), {
      1: (rr, ww, oo) => { oo.version = str(rr.bytes()); },
      2: (rr, ww, oo) => { oo.incrementality = Number(rr.varint()); },
      3: (rr, ww, oo) => { oo.timestamp = u(rr.varint()); },
    }); },
    2: (r, w, o) => { (o.entities ||= []).push(msg(r.bytes(), {
      1: (rr, ww, oo) => { oo.id = str(rr.bytes()); },
      2: (rr, ww, oo) => { oo.isDeleted = rr.varint() !== 0n; },
      3: (rr, ww, oo) => { oo.tripUpdate = tripUpdate(rr.bytes()); },
      4: (rr, ww, oo) => { oo.vehicle = vehiclePosition(rr.bytes()); },
      5: (rr, ww, oo) => { oo.alert = alert(rr.bytes()); },
    })); },
  }, { header: {}, entities: [] });
}

module.exports = { decodeFeed };
