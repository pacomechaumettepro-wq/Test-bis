'use strict';
/* Mobilya — web-app (essai réseau Horizon, Châteauroux). Vanilla JS, sans build. */
(() => {
  // ---------- Outils ----------
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const view = $('#view');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const color = (c, d = '#3A3A40') => (/^#[0-9A-Fa-f]{6}$/.test(c || '') ? c : d);
  const titleCase = (s) => (!s || s !== s.toUpperCase() ? s || '' : s.toLowerCase().replace(/(^|[\s\-'’/(])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()));
  const TZ = 'Europe/Paris';
  const hm = (ms) => new Date(ms).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', timeZone: TZ });
  const todayYmd = () => new Date().toLocaleDateString('en-CA', { timeZone: TZ }).replace(/-/g, '');
  const ago = (ms) => { const s = Math.max(0, Math.round((Date.now() - ms) / 1000)); return s < 60 ? `il y a ${s} s` : s < 3600 ? `il y a ${Math.round(s / 60)} min` : `à ${hm(ms)}`; };
  const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  function distM(aLat, aLon, bLat, bLon) {
    const R = 6371000, r = Math.PI / 180, dLat = (bLat - aLat) * r, dLon = (bLon - aLon) * r;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * r) * Math.cos(bLat * r) * Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(x));
  }

  const local = {
    get(k, d) { try { const v = localStorage.getItem('mobilya-' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('mobilya-' + k, JSON.stringify(v)); } catch (e) { /* stockage indisponible */ } if (['points', 'favs', 'recent', 'pseudo'].includes(k) && window.__mobSync) window.__mobSync(); },
  };
  let clientId = local.get('id', null);
  if (!clientId) { clientId = (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2)); local.set('id', clientId); }

  async function api(path, opts = {}) {
    const tok = (local.get('auth', null) || {}).token;
    const headers = {};
    if (opts.body) headers['Content-Type'] = 'application/json';
    if (tok) headers.Authorization = `Bearer ${tok}`;
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers,
      body: opts.body ? JSON.stringify({ ...opts.body, clientId }) : undefined,
    });
    if (!opts.method) setOffline(res.headers.get('X-Mobilya-Offline') === '1');
    let data = null;
    try { data = await res.json(); } catch (e) { /* réponse vide */ }
    if (!res.ok) throw new Error((data && data.error) || `Erreur ${res.status}`);
    return data;
  }

  let toastTimer;
  function toast(msg) {
    let t = $('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
  }

  // ---------- Icônes ----------
  const svg = (d, w = 22) => `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const I = {
    moon: svg('<path d="M20 14a8 8 0 1 1-10-10 6.5 6.5 0 0 0 10 10z"/>'),
    sun: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
    search: svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>', 20),
    alert: svg('<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.01"/>'),
    bus: svg('<rect x="4" y="3" width="16" height="15" rx="3"/><path d="M4 11h16M8 21v-3M16 21v-3"/>', 24),
    flag: svg('<path d="M5 21V4h11l-1.5 4L16 12H5"/>', 24),
    chat: svg('<path d="M4 5h16v11H9l-5 4z"/>', 24),
    map: svg('<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/>', 24),
    pin: svg('<path d="M12 21s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>', 20),
    locate: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>'),
    back: svg('<path d="M15 6l-6 6 6 6"/>'),
    star: svg('<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>'),
    starFill: `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/></svg>`,
    send: svg('<path d="M4 12l16-8-6 16-2-7z"/>', 20),
    shield: svg('<path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M9 12l2 2 4-4"/>', 14),
    check: svg('<path d="M5 12l4 4 10-10"/>', 20),
    chevron: svg('<path d="M9 6l6 6-6 6"/>', 18),
    x: svg('<path d="M6 6l12 12M18 6L6 18"/>', 18),
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 20),
    bell: svg('<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>', 18),
    share: svg('<path d="M12 3v13M7 8l5-5 5 5M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/>', 18),
  };

  const badge = (line, sm) => line
    ? `<span class="badge${sm ? ' sm' : ''}" style="background:${color(line.color)};color:${color(line.textColor, '#FFFFFF')}">${esc(line.shortName)}</span>`
    : `<span class="badge${sm ? ' sm' : ''}" style="background:var(--chip);color:#fff">?</span>`;

  // ---------- Préférences ----------
  function themePref() { try { return localStorage.getItem('mobilya-theme') || 'auto'; } catch (e) { return 'auto'; } }
  function applyTheme(pref) {
    try { localStorage.setItem('mobilya-theme', pref); } catch (e) { /* */ }
    const dark = pref === 'dark' || (pref === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    const tc = document.querySelector('meta[name="theme-color"]'); if (tc) tc.setAttribute('content', dark ? '#0C0D10' : '#F4F5F8');
    $$('[data-theme-icon]').forEach((b) => { b.innerHTML = dark ? I.sun : I.moon; });
    if (window.Mesh) Mesh.attach(document);
  }
  const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if (themePref() === 'auto') applyTheme('auto'); });

  const favs = () => local.get('favs', []);
  const isFav = (key) => favs().some((f) => f.key === key);
  function toggleFav(stop) {
    const list = favs();
    const i = list.findIndex((f) => f.key === stop.key);
    if (i >= 0) list.splice(i, 1); else list.unshift({ key: stop.key, name: stop.name });
    local.set('favs', list.slice(0, 8));
    return i < 0;
  }
  const rememberStop = (stop) => { local.set('lastStop', { key: stop.key, name: stop.name }); local.set('recent', [{ key: stop.key, name: stop.name }, ...local.get('recent', []).filter((r) => r.key !== stop.key)].slice(0, 6)); };

  // ---------- Points ----------
  const LEVELS = [[0, 'Découverte'], [500, 'Habitué'], [1500, 'Ambassadeur'], [4000, 'Légende']];
  function points() { return local.get('points', { balance: 0, history: [], days: [], trips: [], credited: [] }); }
  function award(pts, label) {
    const p = points();
    p.balance += pts;
    p.history.unshift({ at: Date.now(), label, pts });
    p.history = p.history.slice(0, 50);
    local.set('points', p);
    toast(`+${pts} pts · ${label}`);
    burst();
    return p;
  }
  function streak(p = points()) {
    const days = new Set(p.days);
    let n = 0; let d = todayYmd();
    const prev = (ymd) => { const t = new Date(Date.UTC(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6, 8) - 1)); return t.toISOString().slice(0, 10).replace(/-/g, ''); };
    if (!days.has(d)) d = prev(d);
    while (days.has(d)) { n++; d = prev(d); }
    return n;
  }
  function level(balance) {
    let cur = LEVELS[0], next = null;
    for (let i = 0; i < LEVELS.length; i++) if (balance >= LEVELS[i][0]) { cur = LEVELS[i]; next = LEVELS[i + 1] || null; }
    return { name: cur[1], next: next && { name: next[1], at: next[0] }, from: cur[0] };
  }
  function creditTrip(veh) {
    const p = points();
    if (veh.tripId && p.trips.includes(veh.tripId)) return;
    p.trips = [veh.tripId || `v${veh.id}-${Date.now()}`, ...p.trips].slice(0, 100);
    const t = todayYmd();
    if (!p.days.includes(t)) p.days = [t, ...p.days].slice(0, 60);
    local.set('points', p);
    award(20, `Trajet ligne ${veh.line ? veh.line.shortName : ''}`.trim());
    const s = streak();
    if (s > 0 && s % 5 === 0 && !points().history.some((h) => h.label === `Série de ${s} jours` && todayYmd() === new Date(h.at).toLocaleDateString('en-CA', { timeZone: TZ }).replace(/-/g, ''))) award(50, `Série de ${s} jours`);
  }

  // Détection d'un trajet : la position du téléphone suit celle du bus pendant quelques minutes.
  const onboard = {
    veh: null, watch: null, timer: null, hits: 0, first: null, me: null, startedAt: 0,
    start(veh) {
      if (!navigator.geolocation) return toast('Localisation indisponible sur cet appareil.');
      this.stop(true);
      this.veh = veh; this.hits = 0; this.first = null; this.startedAt = Date.now();
      this.watch = navigator.geolocation.watchPosition((pos) => { this.me = pos.coords; }, () => { toast('Autorisez la localisation pour gagner des points.'); this.stop(true); }, { enableHighAccuracy: true, maximumAge: 10000 });
      this.timer = setInterval(() => this.check(), 15000);
      toast('Bon trajet ! Vos points arrivent dès que le trajet est confirmé.');
    },
    async check() {
      if (!this.veh) return;
      if (Date.now() - this.startedAt > 25 * 60 * 1000) { this.stop(true); return toast('Trajet non confirmé : le bus n’a pas été suivi assez longtemps.'); }
      if (!this.me) return;
      try {
        const { vehicles } = await api('/api/vehicles');
        const v = vehicles.find((x) => x.id === this.veh.id);
        if (!v) return;
        const d = distM(this.me.latitude, this.me.longitude, v.lat, v.lon);
        if (d < 200) { this.hits++; if (!this.first) this.first = [v.lat, v.lon]; }
        const moved = this.first ? distM(this.first[0], this.first[1], v.lat, v.lon) : 0;
        if (this.hits >= 3 && moved > 300) { creditTrip(v); this.stop(true); }
      } catch (e) { /* réseau : on réessaiera */ }
    },
    stop(silent) {
      if (this.watch != null) navigator.geolocation.clearWatch(this.watch);
      clearInterval(this.timer);
      this.watch = null; this.timer = null; this.veh = null;
      if (!silent) toast('Détection arrêtée.');
    },
  };

  // ---------- Données partagées ----------
  let linesCache = null;
  async function lines() { if (!linesCache) linesCache = (await api('/api/lines')).lines; return linesCache; }
  let stopsCache = null;
  async function allStops() { if (!stopsCache) stopsCache = (await api('/api/stops')).stops; return stopsCache; }
  const CATS = { retard: 'Retard', complet: 'Bus complet', arret: 'Arrêt inaccessible', incident: 'Incident', proprete: 'Propreté', autre: 'Autre' };

  function locate() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('Localisation indisponible'));
      navigator.geolocation.getCurrentPosition((p) => { local.set('geoOk', true); resolve(p.coords); }, () => reject(new Error('Localisation refusée')), { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
    });
  }

  // ---------- Rendu des passages ----------
  function depRow(d, now, busId, opts = {}) {
    const t = d.expected ?? d.scheduled;
    const min = Math.round((t - now) / 60000);
    let big = min <= 0 ? 'À l’approche' : min < 60 ? `${min} min` : hm(t);
    let sub;
    if (d.status === 'supprime') { big = hm(d.scheduled); sub = '<span class="pill supprime">Supprimé</span>'; }
    else if (d.status === 'non-desservi') { big = hm(d.scheduled); sub = '<span class="pill non-desservi">Arrêt non desservi</span>'; }
    else if (d.status === 'retard') sub = `<span class="pill retard">+${Math.round(d.delay / 60)} min</span>`;
    else if (d.status === 'avance') sub = `<span class="pill avance">${Math.round(d.delay / 60)} min</span>`;
    else if (d.realtime) sub = '<span class="live"><span class="dot"></span>Temps réel</span>';
    else sub = `<span class="pill theorique">Prévu ${hm(d.scheduled)}</span>`;
    const gone = d.status === 'supprime' || d.status === 'non-desservi';
    const crowd = opts.crowd && opts.crowd.has(d.line.id) ? '<span class="pill crowd">Chargé</span>' : '';
    const w = local.get('watch', null);
    const watching = w && w.tripId === d.tripId;
    const bell = opts.key && !gone && t - now > 2 * 60000 ? `<button class="bellbtn${watching ? ' on' : ''}" data-watch="${esc(d.tripId)}" aria-label="${watching ? 'Alerte activée' : 'Me prévenir quand le bus approche'}" aria-pressed="${!!watching}">${I.bell}</button>` : '';
    return `<div class="dep">${badge(d.line)}<div class="grow col"><span style="font-weight:600">${esc(d.headsign || d.line.longName)}</span><span class="row" style="gap:6px">${d.realtime && !gone ? `<span class="xs muted">prévu ${hm(d.scheduled)}</span>` : ''}${crowd}</span></div><div class="when">${gone ? `<span class="min ${d.status}">${esc(big)}</span>` : `<span class="min ${d.status}" data-at="${t}">${esc(big)}</span>`}${sub}</div>${bell}${busId ? `<a class="seebus" href="#/plan?bus=${encodeURIComponent(busId)}" aria-label="Voir ce bus sur le plan">${I.map.replace('width="24" height="24"', 'width="18" height="18"')}</a>` : ''}</div>`;
  }

  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function greeting() { const h = +new Date().toLocaleString('fr-FR', { hour: 'numeric', hour12: false, timeZone: TZ }); return h >= 18 || h < 5 ? 'Bonsoir' : 'Bonjour'; }
  function countUp(root) {
    $$('[data-count]', root).forEach((el) => {
      const to = +el.dataset.count;
      if (reduceMotion || !to) return;
      const t0 = performance.now(), d = 1100;
      const step = (t) => { const k = Math.min(1, (t - t0) / d); el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))).toLocaleString('fr-FR'); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }
  function decorate() { if (window.Mesh) Mesh.attach(document); countUp(view); }

  // ---------- Routeur ----------
  let cleanup = [];
  const every = (fn, ms) => { const id = setInterval(fn, ms); cleanup.push(() => clearInterval(id)); };
  function parseHash() {
    const h = location.hash.replace(/^#/, '') || '/';
    const [path, qs] = h.split('?');
    const parts = path.split('/').filter(Boolean).map(decodeURIComponent);
    return { parts, q: new URLSearchParams(qs || '') };
  }
  function setTab(tab) {
    $$('nav.tabs a').forEach((a) => { if (a.dataset.tab === tab) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  }

  const TAB_OF = { '': 'home', plan: 'plan', horaires: 'horaires', trafic: 'home', ligne: 'home', communaute: 'communaute', chat: 'communaute', points: 'points', ponctualite: 'home', itineraire: 'home' };
  const TAB_ORDER = ['home', 'plan', 'horaires', 'communaute', 'points'];
  let prevTab = null;
  async function route() {
    cleanup.forEach((f) => f()); cleanup = [];
    view.classList.remove('full');
    const { parts, q } = parseHash();
    const [page, arg] = parts;
    const tab = TAB_OF[page || ''] || 'home';
    view.removeAttribute('data-dir'); void view.offsetWidth;
    if (prevTab && prevTab !== tab && !reduceMotion) view.setAttribute('data-dir', TAB_ORDER.indexOf(tab) > TAB_ORDER.indexOf(prevTab) ? 'left' : 'right');
    prevTab = tab;
    $('nav.tabs').classList.remove('hide');
    window.scrollTo(0, 0);
    try {
      if (!page) { setTab('home'); await pageHome(); }
      else if (page === 'plan') { setTab('plan'); await pagePlan(q); }
      else if (page === 'horaires') { setTab('horaires'); await (arg ? pageStop(arg, q) : pageStopPicker()); }
      else if (page === 'trafic') { setTab('home'); await pageTraffic(); }
      else if (page === 'ligne') { setTab('home'); await pageLine(arg); }
      else if (page === 'communaute') { setTab('communaute'); await pageReports(q); }
      else if (page === 'chat') { setTab('communaute'); await pageChat(arg || 'general'); }
      else if (page === 'points') { setTab('points'); await pagePoints(); }
      else if (page === 'ponctualite') { setTab('home'); await pagePunctuality(q); }
      else if (page === 'itineraire') { setTab('home'); await pagePlanner(q); }
      else { location.hash = '#/'; }
      decorate();
      updatePill();
    } catch (e) {
      view.innerHTML = `<div class="card empty"><p><strong>Impossible de charger les données.</strong></p><p class="small">${esc(e.message)}</p><button class="btn secondary" id="retry">Réessayer</button></div>`;
      $('#retry').onclick = route;
    }
  }
  window.addEventListener('hashchange', route);

  // ---------- Accueil ----------
  async function pageHome() {
    const p = points();
    const lv = level(p.balance);
    const pct = lv.next ? Math.min(100, Math.round(((p.balance - lv.from) / (lv.next.at - lv.from)) * 100)) : 100;
    view.innerHTML = `
      <section class="hero mesh-host sheen">
        <canvas data-mesh data-seed="1.3" data-glow="1.05" aria-hidden="true"></canvas>
        <div class="row between">
          <div class="row brand"><img src="/icon-192.png" alt="Logo Mobilya"><div class="col" style="gap:1px"><span class="row" style="gap:6px"><span class="name shine">Mobilya</span><span class="testpill">TEST</span></span><span class="small sub">Réseau Horizon · Châteauroux</span></div></div>
          <button class="icon-btn" data-theme-icon aria-label="Basculer le mode sombre"></button>
        </div>
        <div class="row between" style="align-items:flex-end"><span style="font-family:Sora,sans-serif;font-size:20px;font-weight:600;letter-spacing:-.02em">${greeting()}</span><a href="#/plan" class="stat" id="livecount"><span class="dot"></span>Bus en direct</a></div>
      </section>
      <div style="position:relative;z-index:30">
        <label class="field">${I.search}<span class="sr">Rechercher un arrêt ou une ligne</span><input id="q" type="search" placeholder="Arrêt ou ligne" autocomplete="off"></label>
        <div id="results" class="card tight list" hidden style="position:absolute;left:0;right:0;top:58px;z-index:50;box-shadow:var(--shadow);max-height:320px;overflow:auto"></div>
      </div>
      <a href="#/itineraire" class="card gocard">${I.pin}<span class="grow col" style="gap:0"><strong>Où allez-vous ?</strong><span class="xs muted">Itinéraire en bus depuis une adresse ou un arrêt</span></span>${I.chevron}</a>
      <div id="banner"></div>
      <section class="card" id="next"><div class="skeleton"></div></section>
      <a href="#/points" class="ribbon mesh-host sheen">
        <canvas data-mesh data-seed="4.2" data-glow=".6" aria-hidden="true"></canvas>
        <span class="row between" style="align-items:baseline"><span class="display silver-ink" style="font-size:26px;font-weight:700"><span data-count="${p.balance}">${p.balance.toLocaleString('fr-FR')}</span> pts</span><span class="small muted">Niveau ${esc(lv.name)}</span></span>
        <span class="bar"><span style="width:${pct}%"></span></span>
        <span class="small muted">${lv.next ? `Encore ${(lv.next.at - p.balance).toLocaleString('fr-FR')} pts avant le niveau ${esc(lv.next.name)}` : 'Niveau maximum atteint'}</span>
      </a>
      <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
        ${[['#/ponctualite', I.clock.replace('width="20" height="20"', 'width="24" height="24"'), 'Ponctualité'], ['#/trafic', I.bus, 'Info trafic'], ['#/communaute', I.flag, 'Signaler'], ['#/chat/general', I.chat, 'Discuter']]
          .map(([h, ic, t]) => `<a href="${h}" class="card col" style="align-items:center;gap:6px;padding:12px 4px;font-size:12px;font-weight:600;color:var(--ink);text-align:center">${ic}${t}</a>`).join('')}
      </div>
      <div id="favs"></div>`;
    applyTheme(themePref());
    $('[data-theme-icon]').onclick = (e) => switchTheme(isDark() ? 'light' : 'dark', e.currentTarget);

    // Recherche : récents, lignes, arrêts, autour de moi
    smartSearch($('#q'), $('#results'));
    prefetchFavorites();

    api('/api/vehicles').then(({ vehicles }) => {
      const el = $('#livecount');
      const n = vehicles.filter((v) => v.line).length;
      if (el) el.innerHTML = `<span class="dot"></span>${n ? `${n} bus en direct` : 'Voir le plan'}`;
    }).catch(() => {});

    // Bandeau : perturbation la plus récente
    Promise.all([api('/api/alerts').catch(() => ({ alerts: [] })), api('/api/reports').catch(() => ({ reports: [] }))]).then(([a, r]) => {
      const al = a.alerts[0];
      const rep = r.reports.find((x) => x.confirmations >= 2 || x.official);
      const el = $('#banner');
      if (!el) return;
      if (al) el.innerHTML = `<a href="#/trafic" class="banner amber">${I.alert}<span class="col" style="gap:2px"><strong>${al.lines.map((l) => `Ligne ${esc(l.shortName)}`).join(', ') || 'Info trafic'}</strong><span>${esc(al.header || al.description)}</span></span></a>`;
      else if (rep) el.innerHTML = `<a href="#/communaute" class="banner amber">${I.alert}<span class="col" style="gap:2px"><strong>${esc(CATS[rep.category])}${rep.stopName ? ` · ${esc(rep.stopName)}` : ''}</strong><span>${esc(rep.text || 'Signalé par des usagers')} · ${rep.confirmations} confirmation${rep.confirmations > 1 ? 's' : ''}</span></span></a>`;
    });

    // Prochains passages
    const target = favs()[0] || local.get('lastStop', null);
    const next = $('#next');
    async function loadNext(stop) {
      const data = await api(`/api/stops/${encodeURIComponent(stop.key)}?limit=4`);
      if (!$('#next')) return;
      next.innerHTML = `<div class="row between" style="margin-bottom:4px"><h2>Prochains passages · ${esc(data.stop.name)}</h2><a class="small" style="font-weight:600" href="#/horaires/${encodeURIComponent(stop.key)}">Tout voir</a></div>
        <div class="list">${data.departures.length ? data.departures.map((d) => depRow(d, data.now)).join('') : '<div class="empty">Plus de passage dans les 2 prochaines heures.</div>'}</div>`;
    }
    if (target) { await loadNext(target).catch(() => { next.innerHTML = '<div class="empty">Passages indisponibles pour le moment.</div>'; }); every(() => loadNext(target).catch(() => {}), 20000); pullToRefresh(() => loadNext(target)); }
    else {
      next.innerHTML = `<h2>Vos prochains passages</h2><p class="small muted" style="margin:6px 0 12px">Trouvez l’arrêt le plus proche ou cherchez-en un ci-dessus.</p><button class="btn block" id="near">${I.pin} Arrêt le plus proche</button>`;
      $('#near').onclick = async () => {
        try {
          const c = await locate();
          const { stops } = await api(`/api/stops/nearby?lat=${c.latitude}&lon=${c.longitude}&limit=1`);
          if (stops[0]) { rememberStop(stops[0]); route(); }
        } catch (e) { toast(e.message); }
      };
    }
    const f = favs();
    if (f.length > 1) $('#favs').innerHTML = `<p class="section-title">Arrêts favoris</p><div class="card tight list">${f.slice(1).map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.starFill}<span class="grow">${esc(s.name)}</span>${I.chevron}</a>`).join('')}</div>`;
  }

  // ---------- Horaires ----------
  async function pageStopPicker() {
    view.innerHTML = `<h1>Horaires</h1>
      <div style="position:relative;z-index:30"><label class="field">${I.search}<span class="sr">Rechercher un arrêt ou une ligne</span><input id="q" type="search" placeholder="Arrêt ou ligne" autocomplete="off"></label>
      <div id="results" class="card tight list" hidden style="position:absolute;left:0;right:0;top:58px;z-index:50;box-shadow:var(--shadow);max-height:360px;overflow:auto"></div></div>
      <button class="btn secondary" id="near">${I.pin} Arrêts autour de moi</button>
      <div id="list"></div>`;
    const list = $('#list');
    const renderStops = (stops, title) => {
      list.innerHTML = stops.length ? `<p class="section-title">${title}</p><div class="card tight list">${stops.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}"><span class="grow col" style="gap:2px"><span style="font-weight:600">${esc(s.name)}</span>${s.distance != null ? `<span class="xs muted">à ${s.distance} m</span>` : ''}</span><span class="row" style="gap:4px">${(s.lines || []).slice(0, 4).map((l) => badge(l, true)).join('')}</span></a>`).join('')}</div>` : '<div class="empty">Aucun arrêt trouvé</div>';
    };
    const f = favs();
    if (f.length) list.innerHTML = `<p class="section-title">Favoris</p><div class="card tight list">${f.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.starFill}<span class="grow">${esc(s.name)}</span>${I.chevron}</a>`).join('')}</div>`;
    smartSearch($('#q'), $('#results'));
    const rc = recents().filter((r) => !f.some((x) => x.key === r.key));
    if (rc.length) list.insertAdjacentHTML('beforeend', `<p class="section-title">Récents</p><div class="card tight list">${rc.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.clock}<span class="grow">${esc(s.name)}</span>${I.chevron}</a>`).join('')}</div>`);
    $('#near').onclick = async () => {
      try { const c = await locate(); renderStops((await api(`/api/stops/nearby?lat=${c.latitude}&lon=${c.longitude}&limit=8`)).stops, 'Autour de vous'); } catch (e) { toast(e.message); }
    };
  }

  async function pageStop(key, q) {
    const line = q.get('line') || '';
    view.innerHTML = '<div class="skeleton" style="height:64px"></div><div class="skeleton" style="height:240px"></div>';
    async function load() {
      const data = await api(`/api/stops/${encodeURIComponent(key)}?limit=10${line ? `&line=${encodeURIComponent(line)}` : ''}`);
      rememberStop(data.stop);
      return data;
    }
    let data = await load();
    const s = data.stop;
    view.innerHTML = `
      <h1>Horaires</h1>
      <div class="card row" style="padding:6px 6px 6px 14px">
        ${I.pin}<span class="grow col" style="gap:0"><span class="xs muted">Arrêt</span><span style="font-size:17px;font-weight:700">${esc(s.name)}</span></span>
        <button class="icon-btn" style="border:0;color:var(--amber)" id="fav" aria-label="Favori" aria-pressed="${isFav(s.key)}">${isFav(s.key) ? I.starFill : I.star}</button>
        <a class="btn secondary sm" href="#/horaires">Changer</a>
      </div>
      <div class="chips" role="group" aria-label="Filtrer par ligne">
        <a class="chip" aria-pressed="${!line}" href="#/horaires/${encodeURIComponent(key)}">Toutes</a>
        ${s.lines.map((l) => `<a class="chip line" aria-pressed="${line === l.id}" style="background:${color(l.color)};color:${color(l.textColor, '#FFFFFF')}" href="#/horaires/${encodeURIComponent(key)}?line=${encodeURIComponent(l.id)}">${esc(l.shortName)}</a>`).join('')}
      </div>
      <div id="lastbus"></div>
      <div id="lastmin"></div>
      <section class="card tight"><div class="list" id="deps"></div></section>
      <p class="xs muted" id="rtinfo" style="margin:-4px 2px 0"></p>
      <div id="grid"></div>
      <section class="card col" style="gap:4px"><h2 style="font-size:15px">${I.moon.replace('width="22" height="22"', 'width="16" height="16"')} Derniers départs de la journée</h2><div class="list" id="lastlist"></div></section>`;
    $('#fav').onclick = (e) => { const on = toggleFav(s); e.currentTarget.innerHTML = on ? I.starFill : I.star; e.currentTarget.setAttribute('aria-pressed', on); toast(on ? 'Ajouté aux favoris' : 'Retiré des favoris'); };
    let busByTrip = new Map();
    const loadBuses = () => api('/api/vehicles').then(({ vehicles }) => { busByTrip = new Map(vehicles.filter((v) => v.tripId).map((v) => [v.tripId, v.id])); }).catch(() => {});
    // Affluence : lignes signalées « bus complet » depuis moins de 40 min
    let crowd = new Set();
    const loadCrowd = () => api('/api/reports').then(({ reports }) => { crowd = new Set(reports.filter((r) => r.category === 'complet' && Date.now() - r.createdAt < 40 * 60000).map((r) => r.routeId)); }).catch(() => {});
    await Promise.all([loadBuses(), loadCrowd()]);
    const render = (d) => {
      const deps = $('#deps');
      if (!deps) return;
      // Hors connexion : on n'affiche que les horaires prévus encore à venir
      if (offline) d = { ...d, departures: d.departures.filter((x) => x.scheduled > Date.now()).map((x) => ({ ...x, expected: null, realtime: false, status: 'theorique' })) };
      deps.innerHTML = d.departures.length ? d.departures.map((x) => depRow(x, Date.now(), busByTrip.get(x.tripId), { key, stopName: s.name, crowd })).join('') : '<div class="empty">Aucun passage dans les 2 prochaines heures.</div>';
      deps._deps = d.departures;
      // Dernier bus : bandeau quand il part dans moins d'une heure, liste complète en bas
      const lb = $('#lastbus');
      if (lb && d.last) {
        const soon = d.last.filter((x) => !x.passed && x.status !== 'supprime' && (x.expected ?? x.scheduled) - Date.now() < 60 * 60000 && (!line || x.line.id === line));
        const wl = local.get('watch', null);
        lb.innerHTML = soon.map((x) => { const t = x.expected ?? x.scheduled; const on = wl && wl.tripId === x.tripId; return `<div class="banner amber lastbus">${I.moon.replace('width="22" height="22"', 'width="20" height="20"')}<span class="col grow" style="gap:2px"><strong>Dernier bus · ${badge(x.line, true)} → ${esc(x.headsign)}</strong><span>Départ à ${hm(t)}, <b data-at="${t}" data-fmt="in">${fmtCountdown(t, 'in')}</b>. Après, ${esc(x.line.shortName)} ne passe plus aujourd’hui.</span></span><button class="bellbtn${on ? ' on' : ''}" data-lastwatch="${esc(x.tripId)}" aria-label="Me prévenir 15 min avant">${I.bell}</button></div>`; }).join('');
        lb._last = d.last;
        const lc = $('#lastlist');
        if (lc) lc.innerHTML = d.last.filter((x) => !line || x.line.id === line).map((x) => `<div class="item" style="min-height:48px">${badge(x.line, true)}<span class="grow">→ ${esc(x.headsign)}</span>${x.passed ? `<span class="xs muted"><s>${hm(x.scheduled)}</s> parti</span>` : `<strong>${hm(x.expected ?? x.scheduled)}</strong>`}</div>`).join('');
      }
      const lm = d.departures.filter((x) => x.status === 'supprime' || x.status === 'non-desservi');
      $('#lastmin').innerHTML = lm.length ? `<div class="banner red" role="alert">${I.alert}<span class="col" style="gap:2px"><strong>Dernière minute</strong>${lm.map((x) => `<span>Ligne ${esc(x.line.shortName)} de ${hm(x.scheduled)} vers ${esc(x.headsign)} : ${x.status === 'supprime' ? 'course supprimée' : 'arrêt non desservi'}.</span>`).join('')}</span></div>` : '';
      $('#rtinfo').textContent = d.realtimeAt ? `Temps réel mis à jour ${ago(d.realtimeAt)}.` : 'Temps réel indisponible : horaires prévus affichés.';
    };
    render(data);
    if (data.grid && data.grid.length) {
      $('#grid').innerHTML = data.grid.map((g) => `<section class="card col" style="gap:8px"><h2 style="font-size:15px">Grille du jour · vers ${esc(g.headsign)}</h2><div class="grid-hours">${g.hours.map((h) => `<strong>${h.hour}h</strong><span>${h.minutes.map((m) => String(m).padStart(2, '0')).join(' · ')}</span>`).join('')}</div></section>`).join('');
    }
    const refresh = async () => { try { await Promise.all([loadBuses(), loadCrowd()]); data = await load(); render(data); } catch (e) { /* */ } };
    every(refresh, 20000);
    pullToRefresh(refresh);
    // Dernier bus : alerte 15 min avant
    $('#lastbus').addEventListener('click', (e) => {
      const b = e.target.closest('[data-lastwatch]');
      if (!b) return;
      const x = ($('#lastbus')._last || []).find((y) => y.tripId === b.dataset.lastwatch);
      if (!x) return;
      const w = local.get('watch', null);
      if (w && w.tripId === x.tripId) watch.stop('Alerte désactivée.');
      else watch.start({ key, stopName: s.name, tripId: x.tripId, line: x.line, headsign: x.headsign, lead: 15, last: true });
      render(data);
    });
    // Cloche : me prévenir quand ce bus est à 2 arrêts
    $('#deps').addEventListener('click', (e) => {
      const b = e.target.closest('[data-watch]');
      if (!b) return;
      const dep = ($('#deps')._deps || []).find((x) => x.tripId === b.dataset.watch);
      if (!dep) return;
      const w = local.get('watch', null);
      if (w && w.tripId === dep.tripId) watch.stop('Alerte désactivée.');
      else watch.start({ key, stopName: s.name, tripId: dep.tripId, line: dep.line, headsign: dep.headsign });
      render(data);
    });
  }

  // ---------- Plan ----------
  async function pagePlan(q) {
    view.classList.add('full');
    const all = await lines();
    const selected = new Set(q.get('line') ? [q.get('line')] : []);
    let mode = 'map';
    view.innerHTML = `
      <div id="map" role="application" aria-label="Carte du réseau avec les bus en temps réel"></div>
      <div class="map-top">
        <div class="seg" role="group" aria-label="Type de plan"><button aria-pressed="true" data-mode="map">Interactif</button><button aria-pressed="false" data-mode="classic">Classique</button></div>
        <div class="chips" id="lchips">${all.map((l) => `<button class="chip line" aria-pressed="${selected.has(l.id)}" data-line="${esc(l.id)}" style="background:${color(l.color)};color:${color(l.textColor, '#FFFFFF')}">${esc(l.shortName)}</button>`).join('')}</div>
      </div>
      <button class="icon-btn map-fab" id="me" aria-label="Me localiser">${I.locate}</button>
      <div id="sheet"></div>
      <div class="classic" id="classic" hidden></div>`;
    if (!window.L) { $('#map').innerHTML = '<div class="empty" style="padding-top:140px">Carte indisponible hors connexion.</div>'; return; }
    const map = L.map('map', { zoomControl: false, attributionControl: true }).setView([46.8103, 1.6913], 13);
    cleanup.push(() => { map.remove(); document.body.classList.remove('bus-focus'); });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
    map.attributionControl.setPrefix('');
    const mapEl = $('#map');
    const zoomCls = () => mapEl.classList.toggle('map-far', map.getZoom() < 15);
    map.on('zoomend', zoomCls); zoomCls();

    // Arrêts (visibles en zoomant)
    const stopLayer = L.layerGroup();
    allStops().then((stops) => {
      for (const s of stops) {
        L.circleMarker([s.lat, s.lon], { radius: 4.5, color: isDark() ? '#F2F2F4' : '#0B0B0C', weight: 2, fillColor: isDark() ? '#151517' : '#FFFFFF', fillOpacity: 1, bubblingMouseEvents: false })
          .bindPopup(`<strong>${esc(s.name)}</strong><br><a href="#/horaires/${encodeURIComponent(s.key)}">Prochains passages</a>`).addTo(stopLayer);
      }
      const upd = () => { if (map.getZoom() >= 15 && !openId) stopLayer.addTo(map); else stopLayer.remove(); };
      map.on('zoomend', upd); upd();
      stopLayer._upd = upd;
    }).catch(() => {});

    // Tracé des lignes choisies dans les filtres
    const pathLayer = L.layerGroup().addTo(map);
    async function drawPaths() {
      pathLayer.clearLayers();
      for (const id of selected) {
        try {
          const d = await api(`/api/lines/${encodeURIComponent(id)}`);
          for (const dir of d.directions) if (dir.path.length > 1) L.polyline(dir.path, { color: color(d.color), weight: 4, opacity: .7, interactive: false }).addTo(pathLayer);
        } catch (e) { /* */ }
      }
    }

    // ----- Bus en temps réel -----
    const markers = new Map();
    const journeyLayer = L.layerGroup().addTo(map);
    let vehicles = [];
    let openId = q.get('bus') || null;
    let openData = null;

    const busIcon = (v) => {
      const hlp = !v.line;
      const c = hlp ? '#8E8E96' : color(v.line.color), tc = hlp ? '#3A3D45' : color(v.line.textColor, '#FFFFFF');
      const dir = v.bearing != null ? `<i class="bus-dir" style="--b:${Math.round(v.bearing)}deg"></i>` : '';
      const stale = v.timestamp && Date.now() - v.timestamp > 5 * 60 * 1000;
      const dl = v.id === openId && openData && openData.journey ? openData.journey.delay : v.delay;
      const late = !hlp && dl != null && Math.abs(dl) >= 120 ? `<span class="bus-delay ${dl > 0 ? 'late' : 'early'}">${dl > 0 ? '+' : '−'}${Math.round(Math.abs(dl) / 60)} min</span>` : '';
      return L.divIcon({ className: '', iconSize: [30, 34], iconAnchor: [15, 9],
        html: `<div class="bus${v.id === openId ? ' sel' : ''}${stale ? ' stale' : ''}${hlp ? ' hlp' : ''}" style="--c:${c};--t:${tc}"><span class="bus-dot">${dir}</span><span class="bus-tag">${hlp ? 'HLP' : esc(v.line.shortName)}</span>${late}</div>` });
    };
    // Déplacement fluide d'un marqueur vers sa nouvelle position
    function glide(m, to) {
      const from = m.getLatLng();
      cancelAnimationFrame(m._anim);
      if (reduceMotion || from.distanceTo(to) > 3000) return m.setLatLng(to);
      const t0 = performance.now(), d = 1600;
      const step = (t) => {
        const k = Math.min(1, (t - t0) / d), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        m.setLatLng([from.lat + (to[0] - from.lat) * e, from.lng + (to[1] - from.lng) * e]);
        if (k < 1) m._anim = requestAnimationFrame(step);
      };
      m._anim = requestAnimationFrame(step);
    }
    async function loadVehicles() {
      try { vehicles = (await api('/api/vehicles')).vehicles; } catch (e) { return; }
      const seen = new Set();
      for (const v of vehicles) {
        if (selected.size && !(v.line && selected.has(v.line.id)) && v.id !== openId) continue;
        seen.add(v.id);
        let m = markers.get(v.id);
        if (!m) {
          m = L.marker([v.lat, v.lon], { icon: busIcon(v), keyboard: true, title: v.line ? `Ligne ${v.line.shortName} vers ${titleCase(v.headsign)}` : 'Bus HLP, en pause', zIndexOffset: 500 }).addTo(map);
          m.on('click', () => openBus(v.id, true));
          markers.set(v.id, m);
        } else { glide(m, [v.lat, v.lon]); m.setIcon(busIcon(v)); }
        m.setZIndexOffset(v.id === openId ? 2000 : 500);
      }
      for (const [id, m] of markers) if (!seen.has(id)) { m.remove(); markers.delete(id); }
    }
    const refreshIcons = () => { for (const v of vehicles) { const m = markers.get(v.id); if (m) { m.setIcon(busIcon(v)); m.setZIndexOffset(v.id === openId ? 2000 : 500); } } };

    // ----- Trajet du bus sélectionné -----
    function drawJourney(d, fit) {
      journeyLayer.clearLayers();
      const j = d.journey;
      const line = d.line || (d.vehicle && d.vehicle.line);
      const c = color(line && line.color), tc = color(line && line.textColor, '#FFFFFF');
      if (!j) { if (fit && d.vehicle) map.setView([d.vehicle.lat, d.vehicle.lon], 16); return; }
      // Partie déjà parcourue : discrète
      if (j.pathPassed.length > 1) L.polyline(j.pathPassed, { color: c, weight: 4, opacity: .22, interactive: false }).addTo(journeyLayer);
      // Partie restante : liseré blanc + couleur de la ligne
      L.polyline(j.pathAhead, { color: '#FFFFFF', weight: 9, opacity: .95, interactive: false }).addTo(journeyLayer);
      L.polyline(j.pathAhead, { color: c, weight: 5, interactive: false, className: fit ? 'route-draw' : '' }).addTo(journeyLayer);
      if (!reduceMotion) L.polyline(j.pathAhead, { color: '#FFFFFF', weight: 2.2, opacity: .9, dashArray: '2 14', lineCap: 'round', interactive: false, className: 'flow' }).addTo(journeyLayer);
      // Arrêts restants (les arrêts passés sont effacés)
      const ahead = j.stops.filter((s) => s.state !== 'passed' && s.lat != null);
      ahead.forEach((s, i) => {
        const isNext = s.state === 'next', last = i === ahead.length - 1;
        const mk = L.circleMarker([s.lat, s.lon], { radius: isNext ? 6 : 4.5, color: s.skipped ? '#B91C1C' : c, weight: 2.5, fillColor: s.skipped ? '#FEE2E2' : '#FFFFFF', fillOpacity: 1, bubblingMouseEvents: false }).addTo(journeyLayer);
        const minor = !(isNext || last || s.skipped);
        const tagTime = isNext && !s.skipped ? ` · ${hm(s.expected ?? s.scheduled)}` : '';
        mk.bindTooltip(`<span class="stop-tag${isNext ? ' next' : ''}${s.skipped ? ' skip' : ''}" style="--c:${c};--t:${tc}">${esc(s.name)}${tagTime}</span>`, { permanent: true, direction: 'right', offset: [5, 0], className: `tag-tt${minor ? ' minor' : ''}` });
        if (s.key) mk.on('click', () => { location.hash = `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(j.routeId)}`; });
      });
      if (fit && j.pathAhead.length) {
        const sh = $('.bsheet');
        const bottom = sh ? window.innerHeight - sh.getBoundingClientRect().top + 16 : Math.round(window.innerHeight * .5);
        map.fitBounds(L.latLngBounds(j.pathAhead), { paddingTopLeft: [24, 124], paddingBottomRight: [110, bottom], maxZoom: 16 });
      }
    }

    const mins = (sec) => Math.max(1, Math.round(Math.abs(sec) / 60));
    let sheetExpanded = false;
    function renderSheet(d) {
      const el = $('#sheet');
      if (!el) return;
      const prevScroll = $('.bsheet .scroll') ? $('.bsheet .scroll').scrollTop : 0;
      const v = d.vehicle, j = d.journey;
      const line = d.line || (v && v.line);
      const hlp = !line && !j;
      const c = hlp ? '#8E8E96' : color(line && line.color), tc = hlp ? '#FFFFFF' : color(line && line.textColor, '#FFFFFF');
      const delay = j ? j.delay : v && v.delay;
      const now = Date.now();

      const ns0 = j && j.stops[j.nextIndex];
      const at = ns0 && !ns0.skipped ? ` à ${esc(ns0.name)}` : '';
      const cmp = ns0 && ns0.expected && !ns0.skipped ? `Prévu ${hm(ns0.scheduled)} → estimé <b>${hm(ns0.expected)}</b>${at}` : '';
      const band = (cls, icon, title, sub) => `<button class="band ${cls} peek-end" id="bandbtn" aria-label="Afficher le trajet"><span class="ic">${icon}</span><span class="col" style="gap:2px;min-width:0;text-align:left"><strong>${title}</strong>${sub ? `<span class="sub">${sub}</span>` : ''}</span></button>`;
      let chip = '', status = '';
      if (hlp) chip = '<span class="schip neutral">HLP · Pause</span>';
      else if (j && j.canceled) status = band('cancel', I.alert, 'Course supprimée', 'Ce bus ne termine pas son trajet.');
      else if (delay == null) status = band('neutral', I.clock, 'Horaire prévu', 'Pas de donnée temps réel pour ce bus.');
      else if (delay >= 60) status = band('late', I.clock, `En retard de ${mins(delay)} min`, cmp);
      else if (delay <= -60) status = band('early', I.clock, `En avance de ${mins(delay)} min`, cmp);
      else status = band('ok', I.check, 'À l’heure', ns0 && !ns0.skipped ? `Passage prévu à ${hm(ns0.expected ?? ns0.scheduled)}${at}` : '');
      const live = j && j.realtime ? '<span class="schip neutral"><span class="dot"></span>Temps réel</span>' : '';
      const crowded = d.causes.some((r) => r.category === 'complet' && now - r.createdAt < 40 * 60000);
      const crowdChip = hlp ? '' : crowded ? '<span class="schip retard">Bus chargé</span>' : '<button class="schip neutral" id="crowd" style="border:0">Bus chargé ?</button>';
      const toggle = j ? `<button class="schip neutral" id="expand" style="border:0;margin-left:auto" aria-expanded="${sheetExpanded}">Trajet <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="transform:rotate(${sheetExpanded ? 180 : 0}deg);transition:transform .2s"><path d="M6 15l6-6 6 6"/></svg></button>` : '';

      // Prochain arrêt, en grand
      const ns = j && j.stops[j.nextIndex];
      const nsT = ns ? (ns.expected ?? ns.scheduled) : null;
      const nsMin = nsT ? Math.round((nsT - now) / 60000) : null;
      const stopLink = (s) => (s.key ? `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(j.routeId)}` : '#');
      let next = '';
      const lateCls = delay != null && delay >= 60 ? 'late' : delay != null && delay <= -60 ? 'early' : '';
      if (ns) next = `<a class="nextbox" style="color:inherit" href="${stopLink(ns)}"><span class="col" style="gap:2px;min-width:0"><span class="k">Prochain arrêt</span><span class="v">${esc(ns.name)}</span>${ns.skipped ? '<span class="xs muted">non desservi</span>' : `<span class="xs muted" data-at="${nsT}" data-fmt="in">${nsMin <= 0 ? 'à l’approche' : `dans ${nsMin} min`}</span>`}</span><span class="when">${ns.skipped ? '<span class="big">—</span>' : `<span class="big ${lateCls}">${hm(nsT)}</span>${ns.expected && Math.abs(ns.expected - ns.scheduled) >= 60000 ? `<br><s class="xs muted">${hm(ns.scheduled)}</s>` : ''}`}</span></a>`;
      else if (hlp) next = `<div class="why2"><span class="ic" style="background:var(--seg);color:var(--ink2)">${I.bus}</span><span><strong>Haut-le-pied ou pause</strong><br><span class="muted">Ce bus ne prend pas de voyageurs pour l’instant : il est en pause au terminus ou rejoint le départ de sa prochaine course.</span></span></div>`;
      else next = '<span class="small muted">Le détail du trajet n’est pas disponible pour ce bus.</span>';

      // Pourquoi ? Déviation ?
      let why = '';
      if (delay != null && delay >= 60) {
        const items = [
          ...d.alerts.map((a) => `<span><strong>Réseau :</strong> ${esc(a.header || a.description)}</span>`),
          ...d.causes.map((r) => `<span><strong>${esc(CATS[r.category])}</strong>${r.stopName ? ` à ${esc(r.stopName)}` : ''}${r.text ? ` : « ${esc(r.text)} »` : ''} <span class="muted">· ${r.confirmations} usager${r.confirmations > 1 ? 's' : ''}, ${ago(r.createdAt)}</span>${r.official ? `<br><strong>Réseau :</strong> ${esc(r.official)}` : ''}</span>`),
        ];
        why = `<div class="why2"><span class="ic">${I.alert}</span><span class="col" style="gap:4px"><strong>Pourquoi ce retard ?</strong>${items.length ? items.join('') : `<span class="muted">Aucune cause signalée pour l’instant.</span><a href="#/communaute${line ? `?line=${encodeURIComponent(line.id)}` : ''}">Vous savez pourquoi ? Signalez-le</a>`}</span></div>`;
      } else if (delay != null && delay <= -60) {
        why = `<div class="why2 adv"><span class="ic">${I.check}</span><span class="col" style="gap:2px"><strong>En avance sur l’horaire</strong><span class="muted">Le bus peut attendre à un arrêt pour reprendre son horaire.</span></span></div>`;
      }
      const dev = j && j.skipped.length
        ? `<div class="why2 dev"><span class="ic">${I.alert}</span><span class="col" style="gap:2px"><strong>Déviation</strong><span>Non desservi${j.skipped.length > 1 ? 's' : ''} : ${j.skipped.map(esc).join(', ')}.</span><span class="muted">Ces arrêts sont barrés sur la carte.</span></span></div>` : '';

      // Arrêts à venir
      const upcoming = j ? j.stops.filter((s) => s.state !== 'passed') : [];
      const tl = upcoming.length ? `<div class="scroll"><div class="timeline2">${upcoming.map((s) => {
        const t = s.expected ?? s.scheduled;
        const moved = s.expected && Math.abs(s.expected - s.scheduled) >= 60 * 1000;
        const m = Math.round((t - now) / 60000);
        const right = s.skipped ? '<span class="pill non-desservi">Non desservi</span>'
          : `<b>${hm(t)}</b>${moved ? `<s>${hm(s.scheduled)}</s>` : `<span class="in" data-at="${t}" data-fmt="in">${m <= 0 ? 'à l’approche' : `dans ${m} min`}</span>`}`;
        const conn = s.connections && s.connections.length ? `<span class="conns">${s.connections.map((c) => `<span class="conn">${badge(c.line, true)}<span>${c.wait <= 1 ? '1 min' : `${c.wait} min`}</span></span>`).join('')}</span>` : '';
        const isDest = q.get('dest') && s.key === q.get('dest');
        return `<a class="tl2 ${s.state}${s.skipped ? ' skip' : ''}${isDest ? ' dest' : ''}" href="${stopLink(s)}"><span class="rail"><i></i></span><span class="nm col" style="gap:3px">${esc(s.name)}${isDest ? '<span class="xs" style="font-weight:700;color:var(--green)">Arrivée du trajet partagé</span>' : ''}${conn}</span><span class="tm">${right}</span></a>`;
      }).join('')}</div></div>` : '';

      const riding = onboard.veh && v && onboard.veh.id === v.id;
      let shared = '';
      if (q.get('trip') || q.get('dest')) {
        const over = q.get('trip') && (!j || j.tripId !== q.get('trip'));
        const ds = j && q.get('dest') ? j.stops.find((x) => x.key === q.get('dest')) : null;
        shared = over ? '<div class="sharedbar">Ce trajet partagé est terminé.</div>'
          : ds ? `<div class="sharedbar">${ds.state === 'passed' ? `Arrivé à <b>${esc(ds.name)}</b>` : `Trajet partagé · arrivée à <b>${esc(ds.name)}</b> vers <b>${hm(ds.expected ?? ds.scheduled)}</b> (<span data-at="${ds.expected ?? ds.scheduled}" data-fmt="in">${fmtCountdown(ds.expected ?? ds.scheduled, 'in')}</span>)`}</div>`
          : '<div class="sharedbar">Trajet partagé en direct</div>';
      }
      el.innerHTML = `<div class="bsheet${sheetExpanded ? '' : ' collapsed'}" role="dialog" aria-label="Bus sélectionné" style="--c:${c}">${shared}
        <button class="grab" id="grab" aria-label="${sheetExpanded ? 'Réduire la fiche' : 'Afficher tout le trajet'}"></button>
        <div class="head">
          <span class="lbadge" style="background:${c};color:${tc};font-size:${hlp ? '13px' : '19px'}">${hlp ? 'HLP' : esc(line.shortName)}</span>
          <div class="grow col" style="gap:2px;min-width:0"><span class="dest">${hlp ? 'En pause' : `→ ${esc(titleCase((j && j.headsign) || (v && v.headsign)) || 'Bus en service')}`}</span><span class="meta">Véhicule ${esc(v ? v.id : '')}${v && v.timestamp ? ` · position ${ago(v.timestamp)}` : ''}</span></div>
          <button class="x" id="close" aria-label="Fermer">${I.x}</button>
        </div>
        ${status || (hlp ? `<div class="peek-end">${next}</div>` : '')}
        <div class="more">
          <div class="chiprow">${chip}${live}${crowdChip}${toggle}</div>
          ${hlp ? '' : next}
          ${hlp ? '' : `<div class="actions three"><button class="btn" id="ride">${riding ? 'Détection…' : 'Je suis à bord'}</button><button class="btn outline" id="share">${I.share} Partager</button><a class="btn outline" href="#/communaute${line ? `?line=${encodeURIComponent(line.id)}` : ''}">${I.flag.replace('width="24" height="24"', 'width="18" height="18"')}<span class="sr">Signaler</span></a></div>`}
          ${dev}${why}${tl}
        </div>
      </div>`;
      const sc = $('.bsheet .scroll'); if (sc) sc.scrollTop = prevScroll;
      $('#close').onclick = closeBus;
      $('#grab').onclick = () => setExpanded(!sheetExpanded);
      if ($('#expand')) $('#expand').onclick = () => setExpanded(!sheetExpanded);
      if ($('#bandbtn')) $('#bandbtn').onclick = () => setExpanded(!sheetExpanded);
      if ($('#share')) $('#share').onclick = () => shareTrip(v, j, line);
      if ($('#ride')) $('#ride').onclick = () => { if (!v) return; if (onboard.veh && onboard.veh.id === v.id) onboard.stop(); else onboard.start(v); renderSheet(d); };
      if ($('#crowd')) $('#crowd').onclick = async () => {
        try {
          await api('/api/reports', { method: 'POST', body: { routeId: line.id, stopKey: (j && j.stops[j.nextIndex] && j.stops[j.nextIndex].key) || '', category: 'complet', text: '', author: local.get('pseudo', '') } });
          toast('Merci ! Les autres usagers sont prévenus.');
          openBus(v.id, false);
        } catch (err) { toast(err.message); }
      };
      placeSheet(false);
    }

    // Fiche qui suit le doigt : repliée (aperçu) ou dépliée, relâchée avec un effet ressort
    function sheetOffset(box) {
      const act = $('.peek-end', box) || $('.head', box);
      const peek = act ? act.offsetTop + act.offsetHeight + 12 : box.offsetHeight;
      return Math.max(0, box.offsetHeight - peek);
    }
    function placeSheet(animate) {
      const box = $('.bsheet');
      if (!box) return;
      const off = sheetExpanded ? 0 : sheetOffset(box);
      box.style.transition = animate && !reduceMotion ? 'transform .55s cubic-bezier(.18,1.25,.4,1)' : 'none';
      box.style.transform = `translateY(${off}px)`;
      box.classList.toggle('collapsed', !sheetExpanded);
      const g = $('#grab', box); if (g) g.setAttribute('aria-label', sheetExpanded ? 'Réduire la fiche' : 'Afficher tout le trajet');
      const ex = $('#expand', box); if (ex) { ex.setAttribute('aria-expanded', sheetExpanded); const ic = $('svg', ex); if (ic) ic.style.transform = `rotate(${sheetExpanded ? 180 : 0}deg)`; }
    }
    function setExpanded(x) { sheetExpanded = x; placeSheet(true); }
    let drag = null;
    $('#sheet').addEventListener('pointerdown', (e) => {
      const box = e.target.closest('.bsheet');
      if (!box || e.target.closest('button, a') || (sheetExpanded && e.target.closest('.more'))) return;
      drag = { y0: e.clientY, t0: performance.now(), base: sheetExpanded ? 0 : sheetOffset(box), box, id: e.pointerId };
      box.style.transition = 'none';
      box.setPointerCapture(e.pointerId);
    });
    $('#sheet').addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      let y = drag.base + (e.clientY - drag.y0);
      if (y < 0) y = y / 3; // résistance au-delà du haut
      drag.box.style.transform = `translateY(${y}px)`;
    });
    const endDrag = (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dy = e.clientY - drag.y0, v = dy / Math.max(1, performance.now() - drag.t0);
      const wasCollapsed = !sheetExpanded;
      drag = null;
      if (Math.abs(dy) < 6) return placeSheet(true);
      if (wasCollapsed && (dy < -50 || v < -.5)) return setExpanded(true);
      if (!wasCollapsed && (dy > 60 || v > .5)) return setExpanded(false);
      if (wasCollapsed && dy > 90) return closeBus();
      placeSheet(true);
    };
    $('#sheet').addEventListener('pointerup', endDrag);
    $('#sheet').addEventListener('pointercancel', endDrag);

    async function openBus(id, fit) {
      if (openId !== id) sheetExpanded = false;
      openId = id;
      document.body.classList.add('bus-focus');
      mapEl.classList.add('map-focus');
      pathLayer.remove();
      if (stopLayer._upd) stopLayer._upd();
      refreshIcons();
      let d;
      try { d = await api(`/api/vehicles/${encodeURIComponent(id)}`); } catch (e) { toast(q.get('trip') ? 'Ce trajet partagé est terminé : le bus n’est plus en service.' : e.message); return closeBus(); }
      if (openId !== id) return;
      openData = d;
      renderSheet(d);
      drawJourney(d, fit);
      refreshIcons();
    }
    function closeBus() {
      openId = null; openData = null;
      document.body.classList.remove('bus-focus');
      journeyLayer.clearLayers();
      mapEl.classList.remove('map-focus');
      pathLayer.addTo(map);
      if (stopLayer._upd) stopLayer._upd();
      const el = $('#sheet'); if (el) el.innerHTML = '';
      refreshIcons();
    }
    map.on('click', () => { if (openId) closeBus(); });

    await loadVehicles();
    if (openId) openBus(openId, true);
    every(async () => { await loadVehicles(); if (openId) { try { const d = await api(`/api/vehicles/${encodeURIComponent(openId)}`); if (openId && d) { openData = d; drawJourney(d, false); renderSheet(d); } } catch (e) { /* bus perdu : on garde l'affichage */ } } }, 15000);
    drawPaths();

    // Position de l'usager
    let meMarker = null;
    $('#me').onclick = async () => {
      try {
        const c = await locate();
        const ll = [c.latitude, c.longitude];
        if (!meMarker) meMarker = L.marker(ll, { icon: L.divIcon({ className: '', iconSize: [18, 18], html: '<div class="me-dot"></div>' }) }).addTo(map); else meMarker.setLatLng(ll);
        map.setView(ll, 16);
      } catch (e) { toast(e.message); }
    };

    $('#lchips').onclick = (e) => {
      const b = e.target.closest('[data-line]');
      if (!b) return;
      const id = b.dataset.line;
      if (selected.has(id)) selected.delete(id); else selected.add(id);
      b.setAttribute('aria-pressed', selected.has(id));
      drawPaths(); loadVehicles();
      if (mode === 'classic') renderClassic();
    };
    $$('[data-mode]').forEach((b) => { b.onclick = () => { mode = b.dataset.mode; $$('[data-mode]').forEach((x) => x.setAttribute('aria-pressed', x === b)); $('#classic').hidden = mode !== 'classic'; $('#me').hidden = mode === 'classic'; $('#sheet').hidden = mode === 'classic'; if (mode === 'classic') renderClassic(); else map.invalidateSize(); }; });

    async function renderClassic() {
      const box = $('#classic');
      const ids = selected.size ? [...selected] : all.map((l) => l.id);
      box.innerHTML = '<div class="skeleton" style="height:200px"></div>';
      const details = await Promise.all(ids.map((id) => api(`/api/lines/${encodeURIComponent(id)}`).catch(() => null)));
      box.innerHTML = details.filter(Boolean).map((d) => {
        const dir = d.directions[0];
        if (!dir) return '';
        return `<section class="card col" style="gap:10px;margin-bottom:12px">
          <div class="row">${badge(d)}<a class="grow" style="font-weight:600;color:var(--ink)" href="#/ligne/${encodeURIComponent(d.id)}">${esc(d.longName || dir.headsign)}</a>${I.chevron}</div>
          <div class="schema" data-route="${esc(d.id)}" style="--c:${color(d.color)}">${dir.stops.map((s, i) => `<a class="${i === 0 || i === dir.stops.length - 1 ? 'term' : ''}" href="${s.key ? `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(d.id)}` : '#'}">${esc(s.name)}</a>`).join('')}</div>
          <span class="schema-note" data-note="${esc(d.id)}"></span>
        </section>`;
      }).join('') + '<p class="xs muted">Plan schématique : les bus avancent en direct. Touchez un arrêt pour ses horaires.</p>';
      classicLive();
    }
    async function classicLive() {
      for (const sc of $$('#classic .schema[data-route]')) {
        const r = await liveOnSchema(sc, sc.dataset.route, 0);
        const note = $(`#classic [data-note="${CSS.escape(sc.dataset.route)}"]`);
        if (note && r) note.textContent = `${r.here} bus dans ce sens${r.other ? ` · ${r.other} dans l’autre sens` : ''}`;
      }
    }
    every(() => { if (mode === 'classic') classicLive(); }, 15000);
  }

  // ---------- Info trafic & lignes ----------
  async function pageTraffic() {
    view.innerHTML = '<div class="skeleton" style="height:180px"></div>';
    const [a, r, all, v] = await Promise.all([api('/api/alerts').catch(() => ({ alerts: [] })), api('/api/reports').catch(() => ({ reports: [] })), lines(), api('/api/vehicles').catch(() => ({ vehicles: [] }))]);
    const byLine = new Map();
    for (const x of v.vehicles) if (x.line) byLine.set(x.line.id, (byLine.get(x.line.id) || 0) + 1);
    const reps = r.reports.filter((x) => x.confirmations >= 2 || x.official);
    view.innerHTML = `
      <div class="row" style="margin-left:-10px"><a href="#/" class="icon-btn" style="border:0;background:transparent" aria-label="Retour">${I.back}</a><h1>Info trafic</h1></div>
      <p class="section-title">En cours</p>
      ${a.alerts.map((x) => `<article class="card col" style="gap:6px;border-left:0"><div class="row">${x.lines.map((l) => badge(l, true)).join('')}<strong>${esc(x.header || 'Perturbation')}</strong></div>${x.description ? `<p class="small" style="margin:0;color:var(--ink2)">${esc(x.description)}</p>` : ''}<span class="xs muted">Source : réseau Horizon</span></article>`).join('')}
      ${reps.map((x) => { const l = all.find((y) => y.id === x.routeId); return `<article class="card col" style="gap:6px"><div class="row">${l ? badge(l, true) : ''}<strong>${esc(CATS[x.category])}${x.stopName ? ` · ${esc(x.stopName)}` : ''}</strong></div>${x.text ? `<p class="small" style="margin:0;color:var(--ink2)">${esc(x.text)}</p>` : ''}<span class="xs muted">Signalé par les usagers · ${x.confirmations} confirmation${x.confirmations > 1 ? 's' : ''} · ${ago(x.createdAt)}</span>${x.official ? `<div class="banner info small">${I.shield}<span><strong>Réseau :</strong> ${esc(x.official)}</span></div>` : ''}</article>`; }).join('')}
      ${!a.alerts.length && !reps.length ? `<div class="banner green">${I.check}<span>Aucune perturbation signalée pour le moment.</span></div>` : ''}
      <p class="section-title">Infos lignes</p>
      <div class="card tight list">${all.map((l) => `<a class="item" href="#/ligne/${encodeURIComponent(l.id)}">${badge(l)}<span class="grow col" style="gap:2px"><span style="font-weight:500">${esc(l.termini.join(' ↔ ') || l.longName)}</span><span class="xs muted">${byLine.get(l.id) ? `${byLine.get(l.id)} bus en circulation` : 'Aucun bus localisé'}</span></span>${I.chevron}</a>`).join('')}</div>
      <div class="banner green small">${I.check}<span>Réseau gratuit : montez sans titre de transport.</span></div>`;
    pullToRefresh(() => route());
  }

  async function pageLine(id) {
    const d = await api(`/api/lines/${encodeURIComponent(id)}`);
    let dirIdx = 0;
    const render = () => {
      const dir = d.directions[dirIdx];
      view.innerHTML = `
        <div class="row" style="margin-left:-10px"><a href="#/trafic" class="icon-btn" style="border:0;background:transparent" aria-label="Retour">${I.back}</a>${badge(d)}<h1 style="font-size:19px">${esc(d.longName || `Ligne ${d.shortName}`)}</h1></div>
        ${d.directions.length > 1 ? `<div class="seg" role="group" aria-label="Direction">${d.directions.map((x, i) => `<button data-dir="${i}" aria-pressed="${i === dirIdx}">→ ${esc(x.headsign)}</button>`).join('')}</div>` : ''}
        <span class="xs muted" id="lnote" style="margin:-4px 2px"></span>
        <section class="card"><div class="schema" style="--c:${color(d.color)}">${dir.stops.map((s, i) => `<a class="${i === 0 || i === dir.stops.length - 1 ? 'term' : ''}" href="${s.key ? `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(d.id)}` : '#'}">${esc(s.name)}</a>`).join('')}</div></section>
        <div class="row"><a class="btn grow" href="#/plan?line=${encodeURIComponent(d.id)}">${I.map} Voir les bus</a><a class="btn secondary grow" href="#/chat/ligne-${encodeURIComponent(d.id.replace(/[^\w-]/g, '-'))}">${I.chat} Discussion</a></div>`;
      $$('[data-dir]').forEach((b) => { b.onclick = () => { dirIdx = +b.dataset.dir; render(); }; });
      live();
    };
    const live = async () => {
      const r = await liveOnSchema($('.schema'), d.id, dirIdx);
      const n = $('#lnote'); if (n && r) n.textContent = r.here ? `${r.here} bus en circulation dans ce sens` : 'Aucun bus localisé dans ce sens';
    };
    render();
    every(live, 15000);
  }

  // ---------- Communauté : signalements ----------
  async function pageReports(q) {
    const all = await lines();
    let lineId = q.get('line') || '';
    let cat = 'retard';
    view.innerHTML = `
      <h1>Communauté</h1>
      <div class="seg"><a href="#/communaute" aria-current="page">Signalements</a><a href="#/chat/general">Discussions</a></div>
      <section class="card col" style="gap:12px">
        <div class="row between"><h2>Signaler un problème</h2><span class="xs" style="font-weight:700;color:var(--pri)">+10 pts si confirmé</span></div>
        <div class="chips" id="rlines" role="group" aria-label="Ligne concernée">${all.map((l) => `<button class="chip line" data-line="${esc(l.id)}" aria-pressed="${l.id === lineId}" style="background:${color(l.color)};color:${color(l.textColor, '#FFFFFF')}">${esc(l.shortName)}</button>`).join('')}</div>
        <label class="field" style="height:48px"><span class="sr">Arrêt concerné</span><select id="rstop"><option value="">Arrêt (facultatif)</option></select></label>
        <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px" id="rcats">${Object.entries(CATS).map(([k, v]) => `<button class="chip" style="justify-content:center;height:44px;border-radius:10px;padding:0 6px" data-cat="${k}" aria-pressed="${k === cat}">${v}</button>`).join('')}</div>
        <label><span class="sr">Précisions</span><textarea class="input" id="rtext" maxlength="280" placeholder="Précisions (facultatif)"></textarea></label>
        <button class="btn block" id="rsend">${I.flag.replace('width="24" height="24"', 'width="18" height="18"')} Envoyer le signalement</button>
      </section>
      <p class="section-title">Derniers signalements</p>
      <div id="feed" class="col" style="gap:10px"><div class="skeleton"></div></div>`;

    async function fillStops() {
      const sel = $('#rstop');
      sel.innerHTML = '<option value="">Arrêt (facultatif)</option>';
      if (!lineId) return;
      try {
        const d = await api(`/api/lines/${encodeURIComponent(lineId)}`);
        const seen = new Set();
        for (const dir of d.directions) for (const s of dir.stops) if (s.key && !seen.has(s.key)) { seen.add(s.key); sel.insertAdjacentHTML('beforeend', `<option value="${esc(s.key)}">${esc(s.name)}</option>`); }
        const last = local.get('lastStop', null);
        if (last && seen.has(last.key)) sel.value = last.key;
      } catch (e) { /* */ }
    }
    fillStops();
    $('#rlines').onclick = (e) => { const b = e.target.closest('[data-line]'); if (!b) return; lineId = lineId === b.dataset.line ? '' : b.dataset.line; $$('#rlines [data-line]').forEach((x) => x.setAttribute('aria-pressed', x.dataset.line === lineId)); fillStops(); };
    $('#rcats').onclick = (e) => { const b = e.target.closest('[data-cat]'); if (!b) return; cat = b.dataset.cat; $$('#rcats [data-cat]').forEach((x) => x.setAttribute('aria-pressed', x === b)); };
    $('#rsend').onclick = async () => {
      if (!lineId) return toast('Choisissez la ligne concernée.');
      const btn = $('#rsend'); btn.disabled = true;
      try {
        const { report } = await api('/api/reports', { method: 'POST', body: { routeId: lineId, stopKey: $('#rstop').value, category: cat, text: $('#rtext').value, author: local.get('pseudo', '') } });
        local.set('myReports', [report.id, ...local.get('myReports', [])].slice(0, 50));
        local.set('voted', [report.id, ...local.get('voted', [])].slice(0, 300));
        $('#rtext').value = '';
        toast('Merci ! Vos 10 points arrivent quand d’autres usagers confirment.');
        loadFeed();
      } catch (e) { toast(e.message); }
      btn.disabled = false;
    };

    async function loadFeed() {
      const { reports } = await api('/api/reports');
      // Points pour mes signalements confirmés par au moins 2 autres usagers
      const mine = new Set(local.get('myReports', []));
      const p = points();
      for (const r of reports) if (mine.has(r.id) && r.confirmations >= 3 && !p.credited.includes(r.id)) { p.credited.push(r.id); local.set('points', p); award(10, 'Signalement confirmé'); }
      const voted = new Set(local.get('voted', []));
      const feed = $('#feed');
      if (!feed) return;
      feed.innerHTML = reports.length ? reports.map((r) => {
        const l = all.find((x) => x.id === r.routeId);
        return `<article class="card col" style="gap:8px">
          <div class="row" style="gap:8px;flex-wrap:wrap">${l ? badge(l, true) : ''}<strong>${esc(CATS[r.category])}</strong><span class="xs muted">${r.stopName ? `${esc(r.stopName)} · ` : ''}${ago(r.createdAt)}</span></div>
          ${r.text ? `<p style="margin:0;font-size:14px">${esc(r.text)}</p>` : ''}
          ${r.official ? `<div class="banner info small">${I.shield}<span><strong>Réseau :</strong> ${esc(r.official)}</span></div>` : ''}
          <div class="row">${voted.has(r.id) ? `<span class="small muted">${r.confirmations} confirmation${r.confirmations > 1 ? 's' : ''} · merci !</span>` : `<button class="btn secondary sm" data-vote="confirm" data-id="${esc(r.id)}">Je confirme · ${r.confirmations}</button><button class="btn ghost sm" data-vote="stale" data-id="${esc(r.id)}">Plus d’actualité</button>`}</div>
        </article>`;
      }).join('') : '<div class="card empty">Aucun signalement en cours. Tout roule !</div>';
    }
    $('#feed').onclick = async (e) => {
      const b = e.target.closest('[data-vote]');
      if (!b) return;
      try {
        await api(`/api/reports/${encodeURIComponent(b.dataset.id)}/${b.dataset.vote}`, { method: 'POST', body: {} });
        local.set('voted', [b.dataset.id, ...local.get('voted', [])].slice(0, 300));
        loadFeed();
      } catch (err) { toast(err.message); }
    };
    await loadFeed();
    every(() => loadFeed().catch(() => {}), 30000);
    pullToRefresh(loadFeed);
  }

  // ---------- Communauté : discussions ----------
  async function pageChat(room) {
    if (!/^[\w-]{1,40}$/.test(room)) room = 'general';
    const all = await lines().catch(() => []);
    const rooms = [['general', 'Général'], ...all.map((l) => [`ligne-${l.id.replace(/[^\w-]/g, '-')}`, `Ligne ${l.shortName}`]), ['equipe', 'Équipe réseau']];
    const mine = new Set(local.get('myMsgs', []));
    let since = 0;
    view.innerHTML = `
      <h1>Communauté</h1>
      <div class="seg"><a href="#/communaute">Signalements</a><a href="#/chat/general" aria-current="page">Discussions</a></div>
      <div class="chips">${rooms.map(([id, name]) => `<a class="chip" aria-pressed="${id === room}" href="#/chat/${id}">${esc(name)}</a>`).join('')}</div>
      ${room === 'equipe' ? `<div class="banner info small">${I.shield}<span>Écrivez ici à l’équipe du réseau. Ses réponses portent le badge « Équipe réseau ».</span></div>` : ''}
      <div class="msgs" id="msgs"><div class="skeleton"></div></div>
      <div style="height:70px"></div>
      <form class="composer" id="composer">
        <label class="field"><span class="sr">Votre message</span><input id="text" maxlength="500" autocomplete="off" placeholder="Votre message…"></label>
        <button class="btn" aria-label="Envoyer">${I.send}</button>
      </form>`;
    const box = $('#msgs');
    let first = true;
    async function load() {
      const { messages } = await api(`/api/chat/${room}?since=${since}`);
      if (first) { box.innerHTML = messages.length ? '' : '<div class="empty">Aucun message pour l’instant. Lancez la discussion !</div>'; first = false; }
      if (messages.length && box.querySelector('.empty')) box.innerHTML = '';
      for (const m of messages) {
        since = Math.max(since, m.at);
        const cls = m.official ? 'team' : mine.has(m.id) ? 'me' : '';
        box.insertAdjacentHTML('beforeend', `<div class="msg ${cls}"><span class="who">${m.official ? `${I.shield} Équipe réseau` : esc(mine.has(m.id) ? 'Vous' : m.author)} · ${hm(m.at)}</span><span class="bubble">${esc(m.text)}</span></div>`);
      }
      if (messages.length) window.scrollTo(0, document.body.scrollHeight);
    }
    await load();
    every(() => load().catch(() => {}), 5000);
    $('#composer').onsubmit = async (e) => {
      e.preventDefault();
      const input = $('#text');
      const text = input.value.trim();
      if (!text) return;
      if (!local.get('pseudo', '')) {
        const p = (window.prompt('Choisissez un pseudo pour la communauté') || '').trim().slice(0, 30);
        if (!p) return;
        local.set('pseudo', p);
      }
      try {
        const { message } = await api(`/api/chat/${room}`, { method: 'POST', body: { text, author: local.get('pseudo', '') } });
        mine.add(message.id); local.set('myMsgs', [message.id, ...mine].slice(0, 300));
        input.value = '';
        await load();
      } catch (err) { toast(err.message); }
    };
  }

  // ---------- Points & réglages ----------
  async function pagePoints() {
    const p = points();
    const lv = level(p.balance);
    const pct = lv.next ? Math.min(100, Math.round(((p.balance - lv.from) / (lv.next.at - lv.from)) * 100)) : 100;
    const pref = themePref();
    view.innerHTML = `
      <h1>Mes points</h1>
      <section class="ribbon mesh-host sheen">
        <canvas data-mesh data-seed="2.6" data-glow=".6" aria-hidden="true"></canvas>
        <div class="row between" style="align-items:flex-start">
          <div class="col" style="gap:2px"><span class="display silver-ink" style="font-size:34px;font-weight:700;line-height:1.05" data-count="${p.balance}">${p.balance.toLocaleString('fr-FR')}</span><span class="small muted">points · niveau ${esc(lv.name)}</span></div>
          <span class="small streak" style="border-radius:10px;padding:6px 10px;font-weight:600">Série : ${streak(p)} jour${streak(p) > 1 ? 's' : ''}</span>
        </div>
        <span class="bar"><span style="width:${pct}%"></span></span>
        <span class="small muted">${lv.next ? `${(lv.next.at - p.balance).toLocaleString('fr-FR')} pts avant le niveau ${esc(lv.next.name)}` : 'Niveau maximum atteint'}</span>
      </section>
      ${onboard.veh ? `<div class="banner info">${I.bus}<span class="grow">Détection du trajet en cours (ligne ${esc(onboard.veh.line ? onboard.veh.line.shortName : '')}).</span><button class="btn sm secondary" id="stopride">Arrêter</button></div>` : ''}
      <section class="card col" style="gap:12px">
        <h2>Gagner des points</h2>
        ${[[I.bus, 'Trajet confirmé', 'Sur le plan, touchez votre bus puis « Je suis à bord »', '+20'], [I.flag, 'Signalement confirmé', 'Validé par d’autres usagers', '+10'], [I.star, '5 jours de suite en bus', 'Bonus de série', '+50']]
          .map(([ic, t, s, v]) => `<div class="row"><span style="width:38px;height:38px;border-radius:10px;background:var(--priBg);color:var(--pri);display:flex;align-items:center;justify-content:center;flex-shrink:0">${ic}</span><span class="grow col" style="gap:0"><span style="font-weight:600">${t}</span><span class="xs muted">${s}</span></span><strong>${v}</strong></div>`).join('')}
      </section>
      <section class="card col" style="gap:6px"><h2>Récompenses</h2><p class="small muted" style="margin:0">Les récompenses des commerces partenaires arrivent bientôt. Vos points sont conservés sur ce téléphone.</p></section>
      <p class="section-title">Historique</p>
      <div class="card tight list">${p.history.length ? p.history.slice(0, 10).map((h) => `<div class="item"><span class="grow col" style="gap:0"><span>${esc(h.label)}</span><span class="xs muted">${new Date(h.at).toLocaleString('fr-FR', { timeZone: TZ, day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span></span><strong style="color:var(--green)">+${h.pts}</strong></div>`).join('') : '<div class="empty">Pas encore de points : prenez le bus !</div>'}</div>
      <p class="section-title">Mon compte</p>
      ${auth() ? `<section class="card row" style="gap:12px"><span class="avatar">${esc((auth().user.pseudo || '?').slice(0, 1).toUpperCase())}</span><span class="grow col" style="gap:0"><strong>${esc(auth().user.pseudo)}</strong><span class="xs muted">${esc(auth().user.email)} · points et favoris sauvegardés</span></span><button class="btn outline sm" id="logout">Déconnexion</button></section>`
        : `<section class="card col" style="gap:10px"><span class="small muted">Sans compte, vos points et vos favoris restent sur ce téléphone.</span><button class="btn" id="login">Créer un compte ou se connecter</button></section>`}
      <p class="section-title">Réglages</p>
      <section class="card col" style="gap:14px">
        <div class="col"><span style="font-weight:600">Apparence</span><div class="seg" role="group" aria-label="Apparence">${[['auto', 'Auto'], ['light', 'Clair'], ['dark', 'Sombre']].map(([k, v]) => `<button data-theme-pref="${k}" aria-pressed="${pref === k}">${v}</button>`).join('')}</div></div>
        <div class="row between"><span class="col" style="gap:0"><span style="font-weight:600">Effet 3D à l’inclinaison</span><span class="xs muted">Le maillage argenté suit les mouvements du téléphone</span></span><button class="switch" role="switch" id="tilt" aria-checked="${tiltOn}" aria-label="Effet 3D à l’inclinaison"></button></div>
        <label class="col"><span style="font-weight:600">Pseudo dans la communauté</span><span class="field" style="height:48px"><input id="pseudo" maxlength="30" value="${esc(local.get('pseudo', ''))}" placeholder="Votre pseudo"></span></label>
      </section>
      <p class="section-title">Données</p>
      <section class="card col small" id="sources" style="gap:6px"><div class="skeleton" style="height:40px"></div></section>`;
    $$('[data-theme-pref]').forEach((b) => { b.onclick = () => { switchTheme(b.dataset.themePref, b); $$('[data-theme-pref]').forEach((x) => x.setAttribute('aria-pressed', x === b)); }; });
    $('#tilt').onclick = async (e) => {
      const btn = e.currentTarget;
      if (tiltOn) { window.removeEventListener('deviceorientation', onTilt); tiltOn = false; local.set('tilt', false); if (window.Mesh) Mesh.setTilt(0, 0); }
      else if (!(await enableTilt(true))) toast('Effet indisponible : autorisez l’accès aux mouvements.');
      btn.setAttribute('aria-checked', tiltOn);
    };
    if ($('#login')) $('#login').onclick = () => accountSheet({ closable: true });
    if ($('#logout')) $('#logout').onclick = async () => { try { await api('/api/auth/logout', { method: 'POST', body: {} }); } catch (e) { /* */ } local.set('auth', null); toast('Vous êtes déconnecté.'); route(); };
    $('#pseudo').onchange = (e) => { local.set('pseudo', e.target.value.trim().slice(0, 30)); toast('Pseudo enregistré'); };
    if ($('#stopride')) $('#stopride').onclick = () => { onboard.stop(); route(); };
    try {
      const s = await api('/api/status');
      $('#sources').innerHTML = `
        <span>Temps réel : ${s.realtime.vehiclePositionsAt ? `${s.realtime.vehicles} bus localisés, mis à jour ${ago(s.realtime.vehiclePositionsAt)}` : 'indisponible'}</span>
        <span>Horaires : ${s.gtfs ? `${s.gtfs.lines} lignes, ${s.gtfs.stops} arrêts (valables jusqu’au ${s.gtfs.validTo.slice(6, 8)}/${s.gtfs.validTo.slice(4, 6)}/${s.gtfs.validTo.slice(0, 4)})` : 'en cours de chargement'}</span>
        ${s.sources.map((x) => `<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.name)}</a>`).join('')}
        <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">Fond de carte © contributeurs OpenStreetMap</a>
        <span class="xs muted">Mobilya ${esc(s.version || '')} · application indépendante, en version d’essai.</span>`;
    } catch (e) { $('#sources').textContent = 'Statut indisponible.'; }
  }

  // =====================================================================
  // Version test 0.5 : animations et fonctions supplémentaires
  // =====================================================================

  // ----- Comptes à rebours vivants (tout élément [data-at]) -----
  function fmtCountdown(at, mode) {
    const m = Math.round((at - Date.now()) / 60000);
    if (mode === 'in') return m <= 0 ? 'à l’approche' : `dans ${m} min`;
    return m <= 0 ? 'À l’approche' : m < 60 ? `${m} min` : hm(at);
  }
  setInterval(() => {
    $$('[data-at]').forEach((el) => {
      const t = fmtCountdown(+el.dataset.at, el.dataset.fmt);
      if (el.textContent !== t) {
        el.textContent = t;
        if (!reduceMotion) { el.classList.remove('flip'); void el.offsetWidth; el.classList.add('flip'); }
      }
    });
  }, 1000);

  // ----- Barre d'onglets qui se cache au défilement -----
  let lastY = 0;
  window.addEventListener('scroll', () => {
    const nav = $('nav.tabs');
    const y = window.scrollY;
    if (view.classList.contains('full') || location.hash.startsWith('#/chat')) { nav.classList.remove('hide'); lastY = y; return; }
    if (y > lastY + 6 && y > 70) nav.classList.add('hide');
    else if (y < lastY - 6 || y < 30) nav.classList.remove('hide');
    lastY = y;
  }, { passive: true });

  // ----- Changement de thème en cercle depuis le bouton -----
  function switchTheme(pref, originEl) {
    if (!document.startViewTransition || reduceMotion) return applyTheme(pref);
    const r = originEl ? originEl.getBoundingClientRect() : { left: innerWidth / 2, top: 0, width: 0, height: 0 };
    const x = r.left + r.width / 2, y = r.top + r.height / 2;
    const rad = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
    const t = document.startViewTransition(() => applyTheme(pref));
    t.ready.then(() => {
      document.documentElement.animate({ clipPath: [`circle(0px at ${x}px ${y}px)`, `circle(${rad}px at ${x}px ${y}px)`] },
        { duration: 600, easing: 'cubic-bezier(.4,0,.2,1)', pseudoElement: '::view-transition-new(root)' });
    }).catch(() => {});
  }

  // ----- Éclat argenté (gain de points) -----
  function burst(x = innerWidth / 2, y = innerHeight - 150) {
    if (reduceMotion) return;
    for (let i = 0; i < 26; i++) {
      const p = document.createElement('i');
      p.className = 'spark';
      const a = Math.random() * Math.PI * 2, d = 40 + Math.random() * 90;
      p.style.left = `${x}px`; p.style.top = `${y}px`;
      p.style.setProperty('--dx', `${Math.cos(a) * d}px`);
      p.style.setProperty('--dy', `${Math.sin(a) * d - 40}px`);
      p.style.animationDelay = `${Math.random() * 90}ms`;
      const s = 4 + Math.random() * 6; p.style.width = p.style.height = `${s}px`;
      document.body.appendChild(p);
      setTimeout(() => p.remove(), 1200);
    }
  }

  // ----- Tirer pour actualiser -----
  function pullToRefresh(fn) {
    let y0 = null, pulled = 0;
    const ind = document.createElement('div');
    ind.className = 'ptr'; ind.setAttribute('aria-hidden', 'true');
    document.body.appendChild(ind);
    const start = (e) => { y0 = window.scrollY <= 0 && !e.target.closest('.chips') ? e.touches[0].clientY : null; pulled = 0; };
    const move = (e) => {
      if (y0 == null) return;
      pulled = Math.max(0, e.touches[0].clientY - y0);
      ind.style.opacity = Math.min(1, pulled / 80);
      ind.style.transform = `translate(-50%, ${Math.min(pulled, 110) * .55}px) rotate(${pulled * 3}deg)`;
    };
    const end = async () => {
      if (y0 == null) return;
      y0 = null;
      if (pulled > 80) { ind.classList.add('spin'); try { await fn(); } catch (e) { /* */ } ind.classList.remove('spin'); }
      ind.style.opacity = 0; ind.style.transform = '';
    };
    window.addEventListener('touchstart', start, { passive: true });
    window.addEventListener('touchmove', move, { passive: true });
    window.addEventListener('touchend', end);
    cleanup.push(() => { window.removeEventListener('touchstart', start); window.removeEventListener('touchmove', move); window.removeEventListener('touchend', end); ind.remove(); });
  }

  // ----- Maillage 3D qui suit l'inclinaison du téléphone -----
  let tiltOn = false;
  function onTilt(e) {
    if (e.gamma == null) return;
    const x = Math.max(-1, Math.min(1, e.gamma / 35)), y = Math.max(-1, Math.min(1, (e.beta - 45) / 35));
    if (window.Mesh && Mesh.setTilt) Mesh.setTilt(x, y);
    document.documentElement.style.setProperty('--tx', x.toFixed(3));
    document.documentElement.style.setProperty('--ty', y.toFixed(3));
  }
  async function enableTilt(ask) {
    if (tiltOn || reduceMotion || !('DeviceOrientationEvent' in window)) return tiltOn;
    try {
      if (typeof DeviceOrientationEvent.requestPermission === 'function') {
        if (!ask) return false;
        if ((await DeviceOrientationEvent.requestPermission()) !== 'granted') return false;
      }
      window.addEventListener('deviceorientation', onTilt);
      tiltOn = true; local.set('tilt', true);
    } catch (e) { /* refusé */ }
    return tiltOn;
  }

  // ----- Bus en direct sur le plan schématique -----
  async function liveOnSchema(schema, routeId, dirIdx) {
    if (!schema) return null;
    try {
      const { buses } = await api(`/api/lines/${encodeURIComponent(routeId)}/live`);
      const rows = $$('a', schema);
      const mine = buses.filter((b) => b.dir === dirIdx);
      const seen = new Set();
      for (const b of mine) {
        const i0 = Math.floor(b.pos), i1 = Math.ceil(b.pos), f = b.pos - i0;
        const r0 = rows[i0], r1 = rows[i1] || r0;
        if (!r0) continue;
        const y0 = r0.offsetTop + r0.offsetHeight / 2, y1 = r1.offsetTop + r1.offsetHeight / 2;
        const y = y0 + (y1 - y0) * f;
        let el = [...schema.querySelectorAll('.sbus')].find((x) => x.dataset.id === String(b.id));
        if (!el) { el = document.createElement('span'); el.className = 'sbus'; el.dataset.id = b.id; el.style.top = `${y}px`; schema.appendChild(el); }
        const late = b.delay != null && Math.abs(b.delay) >= 120;
        el.innerHTML = `<i>${I.bus.replace('width="24" height="24"', 'width="14" height="14"')}</i>${late ? `<b class="${b.delay > 0 ? '' : 'ok'}">${b.delay > 0 ? '+' : '−'}${Math.round(Math.abs(b.delay) / 60)} min</b>` : ''}`;
        el.setAttribute('aria-label', `Bus ${b.id}${late ? `, ${b.delay > 0 ? 'retard' : 'avance'} de ${Math.round(Math.abs(b.delay) / 60)} minutes` : ''}`);
        requestAnimationFrame(() => { el.style.top = `${y}px`; });
        seen.add(String(b.id));
      }
      $$('.sbus', schema).forEach((x) => { if (!seen.has(x.dataset.id)) x.remove(); });
      return { here: mine.length, other: buses.length - mine.length };
    } catch (e) { return null; }
  }

  // ----- Arrêts récents (pour la recherche) -----
  const recents = () => local.get('recent', []);
  function pushRecent(stop) { local.set('recent', [{ key: stop.key, name: stop.name }, ...recents().filter((r) => r.key !== stop.key)].slice(0, 6)); }

  // ----- Recherche intelligente : récents, lignes, arrêts, autour de moi -----
  function smartSearch(input, box) {
    const show = (html) => { box.innerHTML = html; box.hidden = !html; };
    const renderEmpty = () => {
      const r = recents();
      show(`<button class="item" data-near style="width:100%;border:0;background:transparent;text-align:left">${I.pin}<span class="grow" style="font-weight:600">Arrêts autour de moi</span>${I.chevron}</button>`
        + (r.length ? `<div class="xs muted" style="padding:8px 0 2px;font-weight:700;text-transform:uppercase;letter-spacing:.06em">Récents</div>${r.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.clock}<span class="grow">${esc(s.name)}</span></a>`).join('')}` : ''));
    };
    input.addEventListener('focus', () => { if (!input.value.trim()) renderEmpty(); });
    input.addEventListener('input', debounce(async () => {
      const v = input.value.trim();
      if (!v) return renderEmpty();
      const f = v.toLowerCase();
      const ls = (await lines().catch(() => [])).filter((l) => l.shortName.toLowerCase() === f || l.shortName.toLowerCase().startsWith(f) || (l.longName || '').toLowerCase().includes(f) || l.termini.some((t) => t.toLowerCase().includes(f))).slice(0, 4);
      const st = v.length >= 2 ? (await api(`/api/stops/search?q=${encodeURIComponent(v)}`)).stops : [];
      show((ls.length ? ls.map((l) => `<a class="item" href="#/ligne/${encodeURIComponent(l.id)}">${badge(l)}<span class="grow col" style="gap:0"><span style="font-weight:600">Ligne ${esc(l.shortName)}</span><span class="xs muted">${esc(l.termini.join(' ↔ '))}</span></span>${I.chevron}</a>`).join('') : '')
        + (st.length ? st.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.pin}<span class="grow">${esc(s.name)}</span><span class="row" style="gap:4px">${s.lines.slice(0, 4).map((l) => badge(l, true)).join('')}</span></a>`).join('') : '')
        || '<div class="empty">Aucun résultat</div>');
    }, 180));
    box.addEventListener('click', async (e) => {
      if (!e.target.closest('[data-near]')) return;
      try {
        const c = await locate();
        const { stops } = await api(`/api/stops/nearby?lat=${c.latitude}&lon=${c.longitude}&limit=6`);
        show(stops.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.pin}<span class="grow col" style="gap:0"><span style="font-weight:600">${esc(s.name)}</span><span class="xs muted">à ${s.distance} m</span></span><span class="row" style="gap:4px">${s.lines.slice(0, 4).map((l) => badge(l, true)).join('')}</span></a>`).join(''));
      } catch (err) { toast(err.message); }
    });
    document.addEventListener('click', (e) => { if (!box.contains(e.target) && e.target !== input) box.hidden = true; });
  }

  // ----- « Prévenez-moi » : alerte quand le bus est à 2 arrêts (ou 3 min) -----
  const watch = {
    get cur() { return local.get('watch', null); },
    async start(w) {
      local.set('watch', { ...w, until: Date.now() + 90 * 60 * 1000 });
      if ('Notification' in window && Notification.permission === 'default') { try { await Notification.requestPermission(); } catch (e) { /* */ } }
      toast(w.lead ? `Je vous préviens ${w.lead} min avant le dernier ${w.line.shortName} à ${w.stopName}.` : `Je vous préviens quand le ${w.line.shortName} sera à 2 arrêts de ${w.stopName}.`);
      updatePill();
      this.check();
    },
    stop(msg) { local.set('watch', null); if (msg) toast(msg); updatePill(); },
    async check() {
      const w = this.cur;
      if (!w) return;
      if (Date.now() > w.until) return this.stop();
      try {
        const d = await api(`/api/stops/${encodeURIComponent(w.key)}?limit=20`);
        const dep = d.departures.find((x) => x.tripId === w.tripId);
        if (!dep) return this.stop();
        if (dep.status === 'supprime') { notify({ line: w.line, kind: 'supprime', headsign: w.headsign, stopName: w.stopName, scheduled: dep.scheduled }); return this.stop(); }
        const t = dep.expected ?? dep.scheduled;
        const left = (t - Date.now()) / 60000;
        let away = null;
        const { vehicles } = await api('/api/vehicles');
        const bus = vehicles.find((v) => v.tripId === w.tripId);
        if (bus) {
          const det = await api(`/api/vehicles/${encodeURIComponent(bus.id)}`);
          const j = det.journey;
          if (j) { const i = j.stops.findIndex((s) => s.key === w.key && s.state !== 'passed'); if (i >= 0) away = i - j.nextIndex; }
        }
        if (w.lead ? left <= w.lead : ((away != null && away <= 2) || left <= 3)) {
          notify({ line: w.line, kind: dep.status, delay: dep.delay, realtime: dep.realtime, headsign: w.headsign, stopName: w.stopName, scheduled: dep.scheduled, expected: dep.expected, away: w.lead ? null : away, last: w.last, left: Math.round(left) });
          this.stop();
        }
      } catch (e) { /* on réessaiera */ }
    },
  };
  setInterval(() => watch.check(), 15000);
  // Rond de couleur le plus proche de la couleur de la ligne (affiché dans le titre, y compris sur iPhone)
  function colorDot(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
    if (!m) return '⚫';
    const n = parseInt(m[1], 16), r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, d = mx - mn;
    if (d < .12) return l > .6 ? '⚪' : '⚫';
    let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = (h * 60 + 360) % 360;
    if (h < 15 || h >= 335) return '🔴';
    if (h < 42) return l < .35 ? '🟤' : '🟠';
    if (h < 70) return '🟡';
    if (h < 170) return '🟢';
    if (h < 265) return '🔵';
    return '🟣';
  }
  // Icône de la ligne dessinée à la volée (prise en compte sur Android ; iPhone affiche l'icône de l'app)
  function lineIcon(line) {
    try {
      const c = document.createElement('canvas'); c.width = c.height = 192;
      const x = c.getContext('2d');
      x.fillStyle = color(line.color);
      const r = 44; x.beginPath(); x.moveTo(r, 0); x.arcTo(192, 0, 192, 192, r); x.arcTo(192, 192, 0, 192, r); x.arcTo(0, 192, 0, 0, r); x.arcTo(0, 0, 192, 0, r); x.fill();
      x.fillStyle = color(line.textColor, '#FFFFFF');
      x.font = `800 ${line.shortName.length > 2 ? 64 : 96}px Inter, system-ui, sans-serif`;
      x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillText(line.shortName, 96, 102);
      return c.toDataURL('image/png');
    } catch (e) { return '/icon-192.png'; }
  }
  // n : { line, kind, delay, realtime, headsign, stopName, scheduled, expected, away }
  async function notify(n) {
    const mn = (sec) => Math.max(1, Math.round(Math.abs(sec) / 60));
    const dot = colorDot(n.line.color);
    let status, statusShort;
    if (n.kind === 'supprime') { status = '❌ Course supprimée'; statusShort = 'Supprimé'; }
    else if (n.delay != null && n.delay >= 60) { status = `🟠 Retard ${mn(n.delay)} min`; statusShort = `Retard ${mn(n.delay)} min`; }
    else if (n.delay != null && n.delay <= -60) { status = `⚡ Avance ${mn(n.delay)} min`; statusShort = `Avance ${mn(n.delay)} min`; }
    else if (n.realtime) { status = '✅ À l’heure'; statusShort = 'À l’heure'; }
    else { status = '🕒 Horaire prévu'; statusShort = 'Horaire prévu'; }
    const t = n.expected ?? n.scheduled;
    const title = n.last ? `🌙 Dernier bus · ${dot} Ligne ${n.line.shortName} → ${n.headsign}` : `${dot} Ligne ${n.line.shortName} → ${n.headsign}  ·  ${status}`;
    const where = n.kind === 'supprime' ? `Le bus de ${hm(n.scheduled)} ne passera pas à ${n.stopName}.`
      : n.last ? `Part de ${n.stopName} dans ${Math.max(1, n.left)} min, c’est le dernier de la journée.`
      : `${n.away != null ? (n.away <= 0 ? 'Arrive à' : `À ${n.away} arrêt${n.away > 1 ? 's' : ''} de`) : 'Bientôt à'} ${n.stopName}`;
    const times = n.kind === 'supprime' ? '' : n.expected && Math.abs(n.expected - n.scheduled) >= 60000 ? `Prévu ${hm(n.scheduled)} → estimé ${hm(n.expected)}` : `Passage ${hm(t)}`;
    const body = [where, times].filter(Boolean).join('\n');

    if (navigator.vibrate) navigator.vibrate(n.kind === 'supprime' ? [300, 100, 300, 100, 300] : [200, 100, 200]);
    // Bandeau dans l'app : même mise en forme, avec la vraie pastille de ligne
    const cls = n.kind === 'supprime' ? 'cancel' : n.delay != null && n.delay >= 60 ? 'late' : n.delay != null && n.delay <= -60 ? 'early' : n.realtime ? 'ok' : 'neutral';
    const el = document.createElement('div');
    el.className = 'alertbar'; el.setAttribute('role', 'alert');
    el.innerHTML = `<span class="lbadge2" style="background:${color(n.line.color)};color:${color(n.line.textColor, '#FFFFFF')}">${esc(n.line.shortName)}</span>
      <span class="col" style="gap:3px;min-width:0"><strong>→ ${esc(n.headsign)}</strong><span class="small">${esc(where)}</span>
      <span class="row" style="gap:6px;flex-wrap:wrap"><span class="schip ${cls === 'cancel' ? 'supprime' : cls === 'late' ? 'retard' : cls === 'early' ? 'avance' : cls === 'ok' ? 'ok' : 'neutral'}" style="height:26px;font-size:12px">${esc(statusShort)}</span>${times ? `<span class="xs muted">${esc(times)}</span>` : ''}</span></span>
      <button aria-label="Fermer">${I.x}</button>`;
    el.querySelector('button').onclick = () => el.remove();
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 15000);
    // Notification du téléphone
    try {
      if ('Notification' in window && Notification.permission === 'granted') {
        const reg = await navigator.serviceWorker.getRegistration();
        const icon = lineIcon(n.line);
        if (reg) reg.showNotification(title, { body, icon, badge: '/icon-64.png', tag: 'mobilya-watch', renotify: true, timestamp: Date.now(), data: { url: '/#/horaires' } });
      }
    } catch (e) { /* */ }
  }

  // ----- Pastille « mon prochain bus », visible sur les autres écrans -----
  async function updatePill() {
    let pill = $('#nbpill');
    if (!pill) { pill = document.createElement('a'); pill.id = 'nbpill'; pill.className = 'nbpill'; pill.hidden = true; document.body.appendChild(pill); }
    const target = favs()[0] || local.get('lastStop', null);
    const { parts } = parseHash();
    const hideHere = !parts[0] || parts[0] === 'plan' || (parts[0] === 'horaires' && parts[1] === (target && target.key));
    if (!target || hideHere) { pill.hidden = true; return; }
    try {
      const d = await api(`/api/stops/${encodeURIComponent(target.key)}?limit=3`);
      const w = watch.cur;
      const dep = (w && d.departures.find((x) => x.tripId === w.tripId)) || d.departures.find((x) => x.status !== 'supprime');
      if (!dep) { pill.hidden = true; return; }
      const t = dep.expected ?? dep.scheduled;
      pill.href = `#/horaires/${encodeURIComponent(target.key)}`;
      pill.innerHTML = `${badge(dep.line, true)}<span class="grow" style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(d.stop.name)} → ${esc(dep.headsign)}</span><strong data-at="${t}">${fmtCountdown(t)}</strong>${w && w.tripId === dep.tripId ? `<span style="color:var(--amber)">${I.bell}</span>` : ''}`;
      const { parts: p2 } = parseHash();
      pill.hidden = !p2[0] || p2[0] === 'plan';
    } catch (e) { pill.hidden = true; }
  }
  setInterval(updatePill, 30000);

  // ----- Hors connexion : bandeau -----
  let offline = false;
  function setOffline(v) {
    if (v === offline) return;
    offline = v;
    let b = $('#offbar');
    if (!b) { b = document.createElement('div'); b.id = 'offbar'; b.className = 'offbar'; b.textContent = 'Hors connexion · horaires enregistrés'; document.body.appendChild(b); }
    b.hidden = !v;
  }
  window.addEventListener('online', () => setOffline(false));
  window.addEventListener('offline', () => setOffline(true));
  // Pré-enregistre les horaires des arrêts favoris une fois par jour
  function prefetchFavorites() {
    if (local.get('prefetchDay', '') === todayYmd() || !navigator.onLine) return;
    local.set('prefetchDay', todayYmd());
    favs().forEach(async (f) => {
      try {
        const d = await api(`/api/stops/${encodeURIComponent(f.key)}?limit=12`);
        for (const l of d.stop.lines) await api(`/api/stops/${encodeURIComponent(f.key)}?line=${encodeURIComponent(l.id)}`).catch(() => {});
      } catch (e) { /* */ }
    });
  }

  // ----- Accueil au premier lancement -----
  function onboarding() {
    if (local.get('onboarded', false)) return;
    const el = document.createElement('div');
    el.id = 'onb'; el.className = 'onb';
    el.innerHTML = `<canvas data-mesh data-dark data-seed="3.1" data-glow=".9" aria-hidden="true"></canvas>
      <div class="slides" id="slides">
        <section><div class="art art-map"><i class="r1"></i><i class="r2"></i><b class="b1">4</b><b class="b2">1</b><b class="b3">5</b></div><h2>Vos bus en direct</h2><p>Suivez chaque bus sur la carte, son retard et les arrêts qu’il lui reste.</p></section>
        <section><div class="art art-pts"><span class="silver">+20</span></div><h2>Signalez, gagnez des points</h2><p>Bus chargé, retard, arrêt fermé : prévenez les autres usagers. Chaque trajet confirmé vous rapporte des points.</p></section>
        <section><div class="art art-pin">${I.pin}</div><h2>Votre arrêt</h2><p>Autorisez la localisation pour trouver l’arrêt le plus proche et l’ajouter à vos favoris.</p>
          <button class="go" id="onb-loc">Activer la localisation</button><button class="later" id="onb-skip">Plus tard</button></section>
      </div>
      <div class="dots"><i class="on"></i><i></i><i></i></div>
      <button class="next" id="onb-next">Suivant</button>`;
    document.body.appendChild(el);
    if (window.Mesh) Mesh.attach(el);
    const slides = $('#slides', el);
    const dots = $$('.dots i', el);
    const idx = () => Math.round(slides.scrollLeft / slides.clientWidth);
    slides.addEventListener('scroll', () => { const i = idx(); dots.forEach((d, k) => d.classList.toggle('on', k === i)); $('#onb-next', el).hidden = i === 2; }, { passive: true });
    $('#onb-next', el).onclick = () => slides.scrollTo({ left: (idx() + 1) * slides.clientWidth, behavior: 'smooth' });
    const done = () => { local.set('onboarded', true); el.classList.add('out'); setTimeout(() => { el.remove(); route(); if (!auth()) accountSheet(); }, 450); };
    $('#onb-skip', el).onclick = done;
    $('#onb-loc', el).onclick = async () => {
      enableTilt(true);
      try {
        const c = await locate();
        const { stops } = await api(`/api/stops/nearby?lat=${c.latitude}&lon=${c.longitude}&limit=1`);
        if (stops[0]) { if (!isFav(stops[0].key)) toggleFav(stops[0]); rememberStop(stops[0]); toast(`${stops[0].name} ajouté à vos favoris`); }
      } catch (e) { toast(e.message); }
      done();
    };
  }

  // =====================================================================
  // 0.6 : comptes, ponctualité, itinéraires, dernier bus, partage de trajet
  // =====================================================================

  // ----- Compte usager -----
  window.__mobSync = () => scheduleSync();
  const auth = () => local.get('auth', null); // { token, user }
  let syncTimer = null;
  function scheduleSync() {
    if (!auth()) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(async () => {
      try { await api('/api/me', { method: 'POST', body: { points: local.get('points', null), favs: local.get('favs', []), recent: local.get('recent', []), pseudo: local.get('pseudo', '') } }); } catch (e) { if (/Session/.test(e.message)) local.set('auth', null); }
    }, 1500);
  }
  function mergeFromServer(user) {
    const d = user.data || {};
    const p = points();
    if (d.points && (d.points.balance || 0) > (p.balance || 0)) localStorage.setItem('mobilya-points', JSON.stringify(d.points));
    const byKey = (a) => { const m = new Map(); for (const x of a) if (x && x.key && !m.has(x.key)) m.set(x.key, x); return [...m.values()]; };
    if (Array.isArray(d.favs)) localStorage.setItem('mobilya-favs', JSON.stringify(byKey([...favs(), ...d.favs]).slice(0, 8)));
    if (Array.isArray(d.recent)) localStorage.setItem('mobilya-recent', JSON.stringify(byKey([...recents(), ...d.recent]).slice(0, 6)));
    if (user.pseudo) localStorage.setItem('mobilya-pseudo', JSON.stringify(user.pseudo));
    scheduleSync();
  }
  function accountSheet(opts = {}) {
    if ($('#acct')) return;
    const el = document.createElement('div');
    el.id = 'acct'; el.className = 'onb acct';
    let mode = opts.mode || 'register';
    const render = () => {
      el.innerHTML = `<canvas data-mesh data-dark data-seed="5.2" data-glow=".85" aria-hidden="true"></canvas>
        <div class="acct-box">
          <img src="/icon-192.png" alt="" style="width:64px;height:64px;border-radius:16px">
          <h2>${mode === 'register' ? 'Créez votre compte' : 'Bon retour !'}</h2>
          <p>${mode === 'register' ? 'Retrouvez vos points, vos arrêts favoris et votre pseudo sur tous vos appareils.' : 'Connectez-vous pour retrouver vos points et vos favoris.'}</p>
          <div class="seg dark" role="group"><button data-m="register" aria-pressed="${mode === 'register'}">Créer un compte</button><button data-m="login" aria-pressed="${mode === 'login'}">Se connecter</button></div>
          <form id="acct-form" class="col" style="gap:10px;width:100%">
            ${mode === 'register' ? '<label class="dfield"><span>Pseudo</span><input name="pseudo" maxlength="30" autocomplete="nickname" required></label>' : ''}
            <label class="dfield"><span>E-mail</span><input name="email" type="email" autocomplete="email" required></label>
            <label class="dfield"><span>Mot de passe</span><input name="password" type="password" minlength="6" autocomplete="${mode === 'register' ? 'new-password' : 'current-password'}" required></label>
            <p class="err" id="acct-err" role="alert"></p>
            <button class="go" type="submit">${mode === 'register' ? 'Créer mon compte' : 'Se connecter'}</button>
          </form>
          <button class="later" id="acct-skip">${opts.closable ? 'Fermer' : 'Continuer sans compte'}</button>
        </div>`;
      if (window.Mesh) Mesh.attach(el);
      $$('[data-m]', el).forEach((b) => { b.onclick = () => { mode = b.dataset.m; render(); }; });
      $('#acct-skip', el).onclick = () => { if (!opts.closable) local.set('acctSkipAt', Date.now()); close(); };
      $('#acct-form', el).onsubmit = async (e) => {
        e.preventDefault();
        const f = new FormData(e.target);
        const body = { email: f.get('email'), password: f.get('password') };
        if (mode === 'register') { body.pseudo = f.get('pseudo'); body.data = { points: points(), favs: favs(), recent: recents() }; }
        const btn = $('button[type=submit]', el); btn.disabled = true;
        try {
          const r = await api(`/api/auth/${mode}`, { method: 'POST', body });
          local.set('auth', { token: r.token, user: { id: r.user.id, email: r.user.email, pseudo: r.user.pseudo } });
          mergeFromServer(r.user);
          close();
          toast(`Bienvenue ${r.user.pseudo} !`);
          if (mode === 'register') burst(innerWidth / 2, innerHeight / 2);
          route();
        } catch (err) { $('#acct-err', el).textContent = err.message; btn.disabled = false; }
      };
    };
    const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 400); };
    render();
    document.body.appendChild(el);
  }
  // Au lancement : proposer le compte (pas plus d'une fois par semaine si on a passé)
  function maybeAskAccount() {
    if (auth() || !local.get('onboarded', false) || $('#onb')) return;
    if (Date.now() - local.get('acctSkipAt', 0) < 7 * 864e5) return;
    setTimeout(() => accountSheet(), 600);
  }

  // ----- Ponctualité de tous les bus -----
  async function pagePunctuality(q) {
    let filter = q.get('f') || 'tous';
    view.innerHTML = '<h1>Ponctualité</h1><div class="skeleton" style="height:120px"></div><div class="skeleton" style="height:300px"></div>';
    const draw = async () => {
      const d = await api('/api/punctuality');
      const s = d.summary;
      const active = d.buses.filter((b) => b.state !== 'hlp').length;
      const pct = (n) => (active ? Math.round((n / active) * 100) : 0);
      const list = d.buses.filter((b) => filter === 'tous' || b.state === filter || (filter === 'ok' && b.state === 'inconnu'));
      const label = { retard: 'Retard', avance: 'Avance', ok: 'À l’heure', inconnu: 'Sans temps réel', supprime: 'Supprimé', hlp: 'HLP · Pause' };
      if (!$('#pq')) return;
      $('#pq').innerHTML = `
        <section class="card col" style="gap:12px">
          <div class="row between"><h2>${active} bus en service</h2><span class="live"><span class="dot"></span>En direct</span></div>
          <div class="pbar" role="img" aria-label="${s.ok} à l’heure, ${s.retard} en retard, ${s.avance} en avance">
            <span class="ok" style="width:${pct(s.ok + s.inconnu)}%"></span><span class="late" style="width:${pct(s.retard)}%"></span><span class="early" style="width:${pct(s.avance)}%"></span><span class="cancel" style="width:${pct(s.supprime)}%"></span>
          </div>
          <div class="pstats">
            <button data-f="ok" aria-pressed="${filter === 'ok'}"><b class="ok">${s.ok + s.inconnu}</b><span>à l’heure</span></button>
            <button data-f="retard" aria-pressed="${filter === 'retard'}"><b class="late">${s.retard}</b><span>en retard</span></button>
            <button data-f="avance" aria-pressed="${filter === 'avance'}"><b class="early">${s.avance}</b><span>en avance</span></button>
            <button data-f="hlp" aria-pressed="${filter === 'hlp'}"><b>${s.hlp}</b><span>en pause</span></button>
          </div>
        </section>
        <div class="chips"><button class="chip" data-f="tous" aria-pressed="${filter === 'tous'}">Tous</button>${['retard', 'ok', 'avance', 'hlp'].map((k) => `<button class="chip" data-f="${k}" aria-pressed="${filter === k}">${label[k]}</button>`).join('')}</div>
        <div class="card tight list">${list.length ? list.map((b) => {
          const pill = b.state === 'retard' ? `<span class="pill retard">+${Math.round(b.delay / 60)} min</span>` : b.state === 'avance' ? `<span class="pill avance">${Math.round(b.delay / 60)} min</span>` : b.state === 'supprime' ? '<span class="pill supprime">Supprimé</span>' : b.state === 'hlp' ? '<span class="pill theorique">Pause</span>' : b.state === 'ok' ? '<span class="pill ok">À l’heure</span>' : '<span class="pill theorique">Prévu</span>';
          return `<a class="item" href="#/plan?bus=${encodeURIComponent(b.id)}">${b.line ? badge(b.line) : '<span class="badge" style="background:#8E8E96;color:#fff;font-size:11px">HLP</span>'}<span class="grow col" style="gap:1px;min-width:0"><span style="font-weight:600">${b.line ? `→ ${esc(titleCase(b.headsign))}` : 'Hors service commercial'}</span><span class="xs muted">${b.nextStop ? `Prochain arrêt : ${esc(b.nextStop)}` : `Véhicule ${esc(b.id)}`}${b.skipped ? ` · ${b.skipped} arrêt${b.skipped > 1 ? 's' : ''} non desservi${b.skipped > 1 ? 's' : ''}` : ''}</span></span>${pill}</a>`;
        }).join('') : '<div class="empty">Aucun bus dans cette catégorie.</div>'}</div>
        <p class="xs muted" style="margin:0 2px">Mis à jour ${d.updatedAt ? ago(d.updatedAt) : '—'}. Touchez un bus pour le voir sur le plan.</p>`;
      $$('#pq [data-f]').forEach((b) => { b.onclick = () => { filter = filter === b.dataset.f && b.dataset.f !== 'tous' ? 'tous' : b.dataset.f; draw(); }; });
    };
    view.innerHTML = `<div class="row" style="margin-left:-10px"><a href="#/" class="icon-btn" style="border:0;background:transparent" aria-label="Retour">${I.back}</a><h1>Ponctualité</h1></div><div id="pq" class="col" style="gap:14px"><div class="skeleton" style="height:140px"></div></div>`;
    await draw();
    every(() => draw().catch(() => {}), 15000);
    pullToRefresh(draw);
  }

  // ----- Itinéraire -----
  async function pagePlanner(q) {
    const st = { from: local.get('itFrom', { label: 'Ma position', me: true }), to: local.get('itTo', null) };
    view.innerHTML = `
      <div class="row" style="margin-left:-10px"><a href="#/" class="icon-btn" style="border:0;background:transparent" aria-label="Retour">${I.back}</a><h1>Itinéraire</h1></div>
      <section class="card col planner" style="gap:8px;position:relative;z-index:30">
        <div class="pf"><span class="pdot from"></span><input id="pfrom" placeholder="Départ : adresse ou arrêt" autocomplete="off" aria-label="Départ"></div>
        <div class="pf"><span class="pdot to"></span><input id="pto" placeholder="Où allez-vous ?" autocomplete="off" aria-label="Arrivée"></div>
        <button class="icon-btn swap" id="pswap" aria-label="Inverser départ et arrivée">${svg('<path d="M7 4v16M3 8l4-4 4 4M17 20V4M13 16l4 4 4-4"/>', 18)}</button>
        <div id="psug" class="card tight list" hidden style="position:absolute;left:0;right:0;top:100%;margin-top:6px;z-index:60;box-shadow:var(--shadow);max-height:340px;overflow:auto"></div>
        <div class="row" style="gap:8px;margin-top:4px"><label class="chip" style="gap:8px">${I.clock}<span class="sr">Heure de départ</span><input id="pwhen" type="time" style="border:0;background:transparent;font:inherit;width:84px"></label><button class="btn grow" id="pgo">Rechercher</button></div>
      </section>
      <div id="pres" class="col" style="gap:12px"></div>`;
    const fromI = $('#pfrom'), toI = $('#pto'), sug = $('#psug');
    const setVal = () => { fromI.value = st.from ? st.from.label : ''; toI.value = st.to ? st.to.label : ''; };
    setVal();
    let active = null;
    const suggest = debounce(async (input) => {
      const v = input.value.trim();
      const items = [];
      if (!v || 'ma position'.startsWith(v.toLowerCase())) items.push({ label: 'Ma position', me: true, icon: I.locate });
      if (v.length >= 2) {
        const [stops, places] = await Promise.all([api(`/api/stops/search?q=${encodeURIComponent(v)}`).then((r) => r.stops).catch(() => []), v.length >= 3 ? api(`/api/geocode?q=${encodeURIComponent(v)}`).then((r) => r.places).catch(() => []) : []]);
        stops.slice(0, 4).forEach((s) => items.push({ label: s.name, sub: 'Arrêt', lat: s.lat, lon: s.lon, icon: I.bus }));
        places.forEach((p) => items.push({ label: p.label, sub: p.type === 'municipality' ? 'Commune' : 'Adresse', lat: p.lat, lon: p.lon, icon: I.pin }));
      } else recents().forEach((r) => items.push({ label: r.name, sub: 'Arrêt récent', key: r.key, icon: I.clock }));
      sug.innerHTML = items.map((x, i) => `<button class="item" data-i="${i}" style="width:100%;border:0;background:transparent;text-align:left">${x.icon}<span class="grow col" style="gap:0"><span style="font-weight:600">${esc(x.label)}</span>${x.sub ? `<span class="xs muted">${x.sub}</span>` : ''}</span></button>`).join('') || '<div class="empty">Aucun résultat</div>';
      sug.hidden = false;
      sug._items = items;
    }, 220);
    [fromI, toI].forEach((input) => {
      input.addEventListener('focus', () => { active = input; input.select(); suggest(input); });
      input.addEventListener('input', () => { active = input; suggest(input); });
    });
    sug.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-i]'); if (!b) return;
      let x = sug._items[+b.dataset.i];
      if (x.key && x.lat == null) { const s = (await allStops()).find((y) => y.key === x.key); if (s) x = { ...x, lat: s.lat, lon: s.lon }; }
      const val = x.me ? { label: 'Ma position', me: true } : { label: x.label, lat: x.lat, lon: x.lon };
      if (active === fromI) st.from = val; else st.to = val;
      setVal(); sug.hidden = true;
      if (active === fromI && !st.to) toI.focus(); else search();
    });
    document.addEventListener('click', (e) => { if (!e.target.closest('.planner')) sug.hidden = true; });
    $('#pswap').onclick = () => { [st.from, st.to] = [st.to, st.from]; setVal(); if (st.from && st.to) search(); };
    $('#pgo').onclick = () => search();

    async function search() {
      if (!st.from || !st.to) return toast('Indiquez le départ et l’arrivée.');
      local.set('itFrom', st.from); local.set('itTo', st.to);
      const res = $('#pres');
      res.innerHTML = '<div class="skeleton" style="height:110px"></div><div class="skeleton" style="height:110px"></div>';
      try {
        const pt = async (p) => { if (!p.me) return p; const c = await locate(); return { lat: c.latitude, lon: c.longitude }; };
        const [a, b] = await Promise.all([pt(st.from), pt(st.to)]);
        let at = Date.now();
        const w = $('#pwhen').value;
        if (w) { const [h, m] = w.split(':').map(Number); const [nh, nm] = new Date().toLocaleTimeString('en-GB', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).split(':').map(Number); let diff = (h * 60 + m) - (nh * 60 + nm); if (diff < -60) diff += 1440; at = Date.now() + diff * 60000; }
        const r = await api(`/api/route?from=${a.lat},${a.lon}&to=${b.lat},${b.lon}&at=${Math.round(at)}`);
        if (!$('#pres')) return;
        const walkCard = r.walk ? `<div class="card row" style="gap:12px">${svg('<circle cx="13" cy="4" r="2"/><path d="M9 21l3-7 3 3v5M8 12l2-5 4 1 3 4"/>', 22)}<span class="grow">À pied</span><strong>${r.walk.minutes} min</strong></div>` : '';
        if (!r.itineraries.length) { res.innerHTML = `<div class="card empty">Aucun trajet en bus trouvé dans les prochaines heures.</div>${walkCard}`; return; }
        res.innerHTML = r.itineraries.map((it, i) => itineraryCard(it, i)).join('') + walkCard;
        $$('#pres [data-open]').forEach((h) => { h.onclick = () => { const c = h.closest('.itin'); c.classList.toggle('open'); if (c.classList.contains('open')) drawItinMap(c, r.itineraries[+c.dataset.i]); }; });
        $$('#pres [data-watchleg]').forEach((btn) => { btn.onclick = () => { const it = r.itineraries[+btn.dataset.watchleg]; const leg = it.legs.find((x) => x.type === 'bus'); if (leg && leg.fromKey) watch.start({ key: leg.fromKey, stopName: leg.from, tripId: leg.tripId, line: leg.line, headsign: leg.headsign }); }; });
        const first = $('#pres .itin'); if (first) { first.classList.add('open'); drawItinMap(first, r.itineraries[0]); }
      } catch (e) { res.innerHTML = `<div class="card empty">${esc(e.message)}</div>`; }
    }
    function itineraryCard(it, i) {
      const chain = it.legs.map((l) => (l.type === 'bus' ? badge(l.line, true) : `<span class="walkchip">${svg('<circle cx="13" cy="4" r="2"/><path d="M9 21l3-7 3 3v5M8 12l2-5 4 1 3 4"/>', 14)}${l.minutes}</span>`)).join('<span class="sep">›</span>');
      const firstBus = it.legs.find((l) => l.type === 'bus');
      const leave = Math.round((it.start - Date.now()) / 60000);
      const detail = it.legs.map((l) => (l.type === 'walk'
        ? `<div class="leg walk"><span class="lt">${hm(l.start)}</span><span class="lr"></span><span class="lc"><strong>Marcher ${l.minutes} min</strong><span class="xs muted">${l.meters ? `${l.meters} m · ` : ''}${esc(l.from)} → ${esc(l.to)}</span></span></div>`
        : `<div class="leg bus" style="--c:${color(l.line.color)}"><span class="lt"><b>${hm(l.dep)}</b><br><span class="xs muted">${hm(l.arr)}</span></span><span class="lr"></span><span class="lc"><span class="row" style="gap:8px">${badge(l.line, true)}<strong>→ ${esc(titleCase(l.headsign))}</strong>${l.delay != null && Math.abs(l.delay) >= 60 ? `<span class="pill ${l.delay > 0 ? 'retard' : 'avance'}">${l.delay > 0 ? '+' : ''}${Math.round(l.delay / 60)} min</span>` : ''}</span><span class="small">Montez à <b>${esc(l.from)}</b>, descendez à <b>${esc(l.to)}</b></span><span class="xs muted">${l.stops} arrêt${l.stops > 1 ? 's' : ''} · ${Math.round((l.arr - l.dep) / 60000)} min</span></span></div>`)).join('');
      return `<article class="card itin" data-i="${i}">
        <button class="ihead" data-open style="width:100%;border:0;background:transparent;text-align:left;padding:0;color:inherit">
          <div class="row between"><span class="itime"><b>${hm(it.start)}</b> → <b>${hm(it.end)}</b></span><span class="idur">${it.minutes} min</span></div>
          <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px">${chain}</div>
          <div class="xs muted" style="margin-top:6px">${leave <= 0 ? 'Partez maintenant' : `Départ dans ${leave} min`} · ${it.transfers ? `${it.transfers} correspondance${it.transfers > 1 ? 's' : ''}` : 'Direct'}${firstBus ? ` · bus à ${hm(firstBus.dep)} à ${esc(firstBus.from)}` : ''}</div>
        </button>
        <div class="idetail"><div class="itmap"></div>${detail}<button class="btn secondary block" data-watchleg="${i}" style="margin-top:6px">${I.bell} Me prévenir de l’arrivée du bus</button></div>
      </article>`;
    }
    function drawItinMap(card, it) {
      const box = $('.itmap', card);
      if (!window.L || !box || box._map) return;
      const m = L.map(box, { zoomControl: false, attributionControl: false, dragging: true, scrollWheelZoom: false });
      box._map = m;
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(m);
      const pts = [];
      for (const l of it.legs) if (l.type === 'bus' && l.path.length > 1) {
        L.polyline(l.path, { color: '#FFFFFF', weight: 8, opacity: .9 }).addTo(m);
        L.polyline(l.path, { color: color(l.line.color), weight: 5 }).addTo(m);
        L.circleMarker(l.path[0], { radius: 5, color: color(l.line.color), weight: 3, fillColor: '#fff', fillOpacity: 1 }).addTo(m);
        L.circleMarker(l.path[l.path.length - 1], { radius: 5, color: color(l.line.color), weight: 3, fillColor: '#fff', fillOpacity: 1 }).addTo(m);
        pts.push(...l.path);
      }
      if (pts.length) m.fitBounds(L.latLngBounds(pts), { padding: [20, 20] });
      cleanup.push(() => m.remove());
    }
    if (st.from && st.to) search(); else toI.focus();
  }

  // ----- Partage de trajet en direct -----
  async function shareTrip(v, j, line) {
    const ahead = j ? j.stops.filter((s) => s.state !== 'passed' && !s.skipped && s.key) : [];
    const choose = () => new Promise((resolve) => {
      const el = document.createElement('div');
      el.className = 'chooser';
      el.innerHTML = `<div class="chooser-box" role="dialog" aria-label="Où descendez-vous ?"><h2>Où descendez-vous ?</h2><p class="small muted" style="margin:0">Vos proches verront le bus en direct et votre heure d’arrivée.</p>
        <div class="col" style="gap:6px;max-height:46vh;overflow:auto">${ahead.map((s, i) => `<button class="item" data-k="${i}" style="width:100%;border:0;background:var(--seg);border-radius:12px;padding:0 12px;text-align:left"><span class="grow" style="font-weight:600">${esc(s.name)}</span><span class="small muted">${hm(s.expected ?? s.scheduled)}</span></button>`).join('')}</div>
        <button class="btn ghost" data-k="-1">Partager sans arrêt de descente</button></div>`;
      el.onclick = (e) => { const b = e.target.closest('[data-k]'); if (b || e.target === el) { el.remove(); resolve(b ? +b.dataset.k : null); } };
      document.body.appendChild(el);
    });
    const k = ahead.length ? await choose() : -1;
    if (k === null) return;
    const dest = k >= 0 ? ahead[k] : null;
    const url = `${location.origin}/#/plan?bus=${encodeURIComponent(v.id)}${j ? `&trip=${encodeURIComponent(j.tripId)}` : ''}${dest ? `&dest=${encodeURIComponent(dest.key)}` : ''}`;
    const who = local.get('pseudo', '') || 'Je';
    const text = `${who === 'Je' ? 'Je suis' : `${who} est`} dans le bus ${line ? line.shortName : ''} vers ${titleCase(j ? j.headsign : v.headsign)}${dest ? `, arrivée prévue à ${dest.name} vers ${hm(dest.expected ?? dest.scheduled)}` : ''}. Suivez le trajet en direct sur Mobilya :`;
    try {
      if (navigator.share) await navigator.share({ title: 'Mon trajet en direct', text, url });
      else { await navigator.clipboard.writeText(`${text} ${url}`); toast('Lien copié : collez-le dans un message.'); }
    } catch (e) { /* partage annulé */ }
  }

  // ---------- Démarrage ----------
  applyTheme(themePref());
  const splash = $('#splash');
  let splashSeen = false;
  try { splashSeen = sessionStorage.getItem('mobilya-splash') === '1'; } catch (e) { /* */ }
  if (!splashSeen) {
    splash.hidden = false;
    if (window.Mesh) Mesh.attach(splash);
    const close = () => { splash.style.opacity = '0'; setTimeout(() => { splash.hidden = true; onboarding(); maybeAskAccount(); }, 400); try { sessionStorage.setItem('mobilya-splash', '1'); } catch (e) { /* */ } };
    $('#splash-go').onclick = close;
    if (local.get('welcomed', false)) setTimeout(close, 1100); else local.set('welcomed', true);
  }
  else { onboarding(); maybeAskAccount(); }
  // Inclinaison : automatique quand aucune autorisation n'est demandée (Android) ; sur iPhone, après accord
  if (typeof (window.DeviceOrientationEvent && DeviceOrientationEvent.requestPermission) !== 'function') { if (local.get('tilt', true)) enableTilt(false); }
  else if (local.get('tilt', false)) document.addEventListener('click', () => enableTilt(true), { once: true });
  route();
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' }).then((r) => r.update()).catch(() => {}));
})();
