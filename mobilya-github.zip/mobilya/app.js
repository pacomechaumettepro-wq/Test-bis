'use strict';
/* Mobilya — web-app (essai réseau Horizon, Châteauroux). Vanilla JS, sans build. */
(() => {
  // ---------- Outils ----------
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const view = $('#view');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const color = (c, d = '#3A3A40') => (/^#[0-9A-Fa-f]{6}$/.test(c || '') ? c : d);
  const titleCase = (s) => (!s || s !== s.toUpperCase() ? s || '' : s.toLowerCase().replace(/(^|[\s\-'’/(])(\p{L})/gu, (m, a, b) => a + b.toUpperCase()));
  const TZ = 'Europe/Paris';
  const hm = (ms) => new Date(ms).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', timeZone: TZ });
  const todayYmd = () => new Date().toLocaleDateString('en-CA', { timeZone: TZ }).replace(/-/g, '');
  const ago = (ms) => { const s = Math.max(0, Math.round((Date.now() - ms) / 1000)); return s < 60 ? `il y a ${s} s` : s < 3600 ? `il y a ${Math.round(s / 60)} min` : `à ${hm(ms)}`; };
  const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  function distM(aLat, aLon, bLat, bLon) {
    const R = 6371000, r = Math.PI / 180, dLat = (bLat - aLat) * r, dLon = (bLon - aLon) * r;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(aLat * r) * Math.cos(bLat * r) * Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(x));
  }

  const local = {
    get(k, d) { try { const v = localStorage.getItem('mobilya-' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('mobilya-' + k, JSON.stringify(v)); } catch (e) { /* stockage indisponible */ } },
  };
  let clientId = local.get('id', null);
  if (!clientId) { clientId = (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2)); local.set('id', clientId); }

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      body: opts.body ? JSON.stringify({ ...opts.body, clientId }) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch (e) { /* réponse vide */ }
    if (!res.ok) throw new Error((data && data.error) || `Erreur ${res.status}`);
    return data;
  }

  let toastTimer;
  function toast(msg) {
    let t = $('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg; t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
  }

  // ---------- Icônes ----------
  const svg = (d, w = 22) => `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  const I = {
    moon: svg('<path d="M20 14a8 8 0 1 1-10-10 6.5 6.5 0 0 0 10 10z"/>'),
    sun: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),
    search: svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>', 20),
    alert: svg('<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.01"/>'),
    bus: svg('<rect x="4" y="3" width="16" height="15" rx="3"/><path d="M4 11h16M8 21v-3M16 21v-3"/>', 24),
    flag: svg('<path d="M5 21V4h11l-1.5 4L16 12H5"/>', 24),
    chat: svg('<path d="M4 5h16v11H9l-5 4z"/>', 24),
    map: svg('<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/>', 24),
    pin: svg('<path d="M12 21s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>', 20),
    locate: svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>'),
    back: svg('<path d="M15 6l-6 6 6 6"/>'),
    star: svg('<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>'),
    starFill: `<svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/></svg>`,
    send: svg('<path d="M4 12l16-8-6 16-2-7z"/>', 20),
    shield: svg('<path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/><path d="M9 12l2 2 4-4"/>', 14),
    check: svg('<path d="M5 12l4 4 10-10"/>', 20),
    chevron: svg('<path d="M9 6l6 6-6 6"/>', 18),
    x: svg('<path d="M6 6l12 12M18 6L6 18"/>', 18),
  };

  const badge = (line, sm) => line
    ? `<span class="badge${sm ? ' sm' : ''}" style="background:${color(line.color)};color:${color(line.textColor, '#FFFFFF')}">${esc(line.shortName)}</span>`
    : `<span class="badge${sm ? ' sm' : ''}" style="background:var(--chip);color:#fff">?</span>`;

  // ---------- Préférences ----------
  function themePref() { try { return localStorage.getItem('mobilya-theme') || 'auto'; } catch (e) { return 'auto'; } }
  function applyTheme(pref) {
    try { localStorage.setItem('mobilya-theme', pref); } catch (e) { /* */ }
    const dark = pref === 'dark' || (pref === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    const tc = document.querySelector('meta[name="theme-color"]'); if (tc) tc.setAttribute('content', dark ? '#0C0D10' : '#F4F5F8');
    $$('[data-theme-icon]').forEach((b) => { b.innerHTML = dark ? I.sun : I.moon; });
    if (window.Mesh) Mesh.attach(document);
  }
  const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if (themePref() === 'auto') applyTheme('auto'); });

  const favs = () => local.get('favs', []);
  const isFav = (key) => favs().some((f) => f.key === key);
  function toggleFav(stop) {
    const list = favs();
    const i = list.findIndex((f) => f.key === stop.key);
    if (i >= 0) list.splice(i, 1); else list.unshift({ key: stop.key, name: stop.name });
    local.set('favs', list.slice(0, 8));
    return i < 0;
  }
  const rememberStop = (stop) => local.set('lastStop', { key: stop.key, name: stop.name });

  // ---------- Points ----------
  const LEVELS = [[0, 'Découverte'], [500, 'Habitué'], [1500, 'Ambassadeur'], [4000, 'Légende']];
  function points() { return local.get('points', { balance: 0, history: [], days: [], trips: [], credited: [] }); }
  function award(pts, label) {
    const p = points();
    p.balance += pts;
    p.history.unshift({ at: Date.now(), label, pts });
    p.history = p.history.slice(0, 50);
    local.set('points', p);
    toast(`+${pts} pts · ${label}`);
    return p;
  }
  function streak(p = points()) {
    const days = new Set(p.days);
    let n = 0; let d = todayYmd();
    const prev = (ymd) => { const t = new Date(Date.UTC(+ymd.slice(0, 4), +ymd.slice(4, 6) - 1, +ymd.slice(6, 8) - 1)); return t.toISOString().slice(0, 10).replace(/-/g, ''); };
    if (!days.has(d)) d = prev(d);
    while (days.has(d)) { n++; d = prev(d); }
    return n;
  }
  function level(balance) {
    let cur = LEVELS[0], next = null;
    for (let i = 0; i < LEVELS.length; i++) if (balance >= LEVELS[i][0]) { cur = LEVELS[i]; next = LEVELS[i + 1] || null; }
    return { name: cur[1], next: next && { name: next[1], at: next[0] }, from: cur[0] };
  }
  function creditTrip(veh) {
    const p = points();
    if (veh.tripId && p.trips.includes(veh.tripId)) return;
    p.trips = [veh.tripId || `v${veh.id}-${Date.now()}`, ...p.trips].slice(0, 100);
    const t = todayYmd();
    if (!p.days.includes(t)) p.days = [t, ...p.days].slice(0, 60);
    local.set('points', p);
    award(20, `Trajet ligne ${veh.line ? veh.line.shortName : ''}`.trim());
    const s = streak();
    if (s > 0 && s % 5 === 0 && !points().history.some((h) => h.label === `Série de ${s} jours` && todayYmd() === new Date(h.at).toLocaleDateString('en-CA', { timeZone: TZ }).replace(/-/g, ''))) award(50, `Série de ${s} jours`);
  }

  // Détection d'un trajet : la position du téléphone suit celle du bus pendant quelques minutes.
  const onboard = {
    veh: null, watch: null, timer: null, hits: 0, first: null, me: null, startedAt: 0,
    start(veh) {
      if (!navigator.geolocation) return toast('Localisation indisponible sur cet appareil.');
      this.stop(true);
      this.veh = veh; this.hits = 0; this.first = null; this.startedAt = Date.now();
      this.watch = navigator.geolocation.watchPosition((pos) => { this.me = pos.coords; }, () => { toast('Autorisez la localisation pour gagner des points.'); this.stop(true); }, { enableHighAccuracy: true, maximumAge: 10000 });
      this.timer = setInterval(() => this.check(), 15000);
      toast('Bon trajet ! Vos points arrivent dès que le trajet est confirmé.');
    },
    async check() {
      if (!this.veh) return;
      if (Date.now() - this.startedAt > 25 * 60 * 1000) { this.stop(true); return toast('Trajet non confirmé : le bus n’a pas été suivi assez longtemps.'); }
      if (!this.me) return;
      try {
        const { vehicles } = await api('/api/vehicles');
        const v = vehicles.find((x) => x.id === this.veh.id);
        if (!v) return;
        const d = distM(this.me.latitude, this.me.longitude, v.lat, v.lon);
        if (d < 200) { this.hits++; if (!this.first) this.first = [v.lat, v.lon]; }
        const moved = this.first ? distM(this.first[0], this.first[1], v.lat, v.lon) : 0;
        if (this.hits >= 3 && moved > 300) { creditTrip(v); this.stop(true); }
      } catch (e) { /* réseau : on réessaiera */ }
    },
    stop(silent) {
      if (this.watch != null) navigator.geolocation.clearWatch(this.watch);
      clearInterval(this.timer);
      this.watch = null; this.timer = null; this.veh = null;
      if (!silent) toast('Détection arrêtée.');
    },
  };

  // ---------- Données partagées ----------
  let linesCache = null;
  async function lines() { if (!linesCache) linesCache = (await api('/api/lines')).lines; return linesCache; }
  let stopsCache = null;
  async function allStops() { if (!stopsCache) stopsCache = (await api('/api/stops')).stops; return stopsCache; }
  const CATS = { retard: 'Retard', complet: 'Bus complet', arret: 'Arrêt inaccessible', incident: 'Incident', proprete: 'Propreté', autre: 'Autre' };

  function locate() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error('Localisation indisponible'));
      navigator.geolocation.getCurrentPosition((p) => { local.set('geoOk', true); resolve(p.coords); }, () => reject(new Error('Localisation refusée')), { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
    });
  }

  // ---------- Rendu des passages ----------
  function depRow(d, now, busId) {
    const t = d.expected ?? d.scheduled;
    const min = Math.round((t - now) / 60000);
    let big = min <= 0 ? 'À l’approche' : min < 60 ? `${min} min` : hm(t);
    let sub;
    if (d.status === 'supprime') { big = hm(d.scheduled); sub = '<span class="pill supprime">Supprimé</span>'; }
    else if (d.status === 'non-desservi') { big = hm(d.scheduled); sub = '<span class="pill non-desservi">Arrêt non desservi</span>'; }
    else if (d.status === 'retard') sub = `<span class="pill retard">+${Math.round(d.delay / 60)} min</span>`;
    else if (d.status === 'avance') sub = `<span class="pill avance">${Math.round(d.delay / 60)} min</span>`;
    else if (d.realtime) sub = '<span class="live"><span class="dot"></span>Temps réel</span>';
    else sub = `<span class="pill theorique">Prévu ${hm(d.scheduled)}</span>`;
    return `<div class="dep">${badge(d.line)}<div class="grow col"><span style="font-weight:600">${esc(d.headsign || d.line.longName)}</span>${d.realtime && d.status !== 'supprime' && d.status !== 'non-desservi' ? `<span class="xs muted">prévu ${hm(d.scheduled)}</span>` : ''}</div><div class="when"><span class="min ${d.status}">${esc(big)}</span>${sub}</div>${busId ? `<a class="seebus" href="#/plan?bus=${encodeURIComponent(busId)}" aria-label="Voir ce bus sur le plan">${I.map.replace('width="24" height="24"', 'width="18" height="18"')}</a>` : ''}</div>`;
  }

  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function greeting() { const h = +new Date().toLocaleString('fr-FR', { hour: 'numeric', hour12: false, timeZone: TZ }); return h >= 18 || h < 5 ? 'Bonsoir' : 'Bonjour'; }
  function countUp(root) {
    $$('[data-count]', root).forEach((el) => {
      const to = +el.dataset.count;
      if (reduceMotion || !to) return;
      const t0 = performance.now(), d = 1100;
      const step = (t) => { const k = Math.min(1, (t - t0) / d); el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))).toLocaleString('fr-FR'); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    });
  }
  function decorate() { if (window.Mesh) Mesh.attach(document); countUp(view); }

  // ---------- Routeur ----------
  let cleanup = [];
  const every = (fn, ms) => { const id = setInterval(fn, ms); cleanup.push(() => clearInterval(id)); };
  function parseHash() {
    const h = location.hash.replace(/^#/, '') || '/';
    const [path, qs] = h.split('?');
    const parts = path.split('/').filter(Boolean).map(decodeURIComponent);
    return { parts, q: new URLSearchParams(qs || '') };
  }
  function setTab(tab) {
    $$('nav.tabs a').forEach((a) => { if (a.dataset.tab === tab) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  }

  async function route() {
    cleanup.forEach((f) => f()); cleanup = [];
    view.classList.remove('full');
    const { parts, q } = parseHash();
    const [page, arg] = parts;
    window.scrollTo(0, 0);
    try {
      if (!page) { setTab('home'); await pageHome(); }
      else if (page === 'plan') { setTab('plan'); await pagePlan(q); }
      else if (page === 'horaires') { setTab('horaires'); await (arg ? pageStop(arg, q) : pageStopPicker()); }
      else if (page === 'trafic') { setTab('home'); await pageTraffic(); }
      else if (page === 'ligne') { setTab('home'); await pageLine(arg); }
      else if (page === 'communaute') { setTab('communaute'); await pageReports(q); }
      else if (page === 'chat') { setTab('communaute'); await pageChat(arg || 'general'); }
      else if (page === 'points') { setTab('points'); await pagePoints(); }
      else { location.hash = '#/'; }
      decorate();
    } catch (e) {
      view.innerHTML = `<div class="card empty"><p><strong>Impossible de charger les données.</strong></p><p class="small">${esc(e.message)}</p><button class="btn secondary" id="retry">Réessayer</button></div>`;
      $('#retry').onclick = route;
    }
  }
  window.addEventListener('hashchange', route);

  // ---------- Accueil ----------
  async function pageHome() {
    const p = points();
    const lv = level(p.balance);
    const pct = lv.next ? Math.min(100, Math.round(((p.balance - lv.from) / (lv.next.at - lv.from)) * 100)) : 100;
    view.innerHTML = `
      <section class="hero mesh-host sheen">
        <canvas data-mesh data-seed="1.3" data-glow="1.05" aria-hidden="true"></canvas>
        <div class="row between">
          <div class="row brand"><img src="/icon-192.png" alt="Logo Mobilya"><div class="col" style="gap:1px"><span class="name shine">Mobilya</span><span class="small sub">Réseau Horizon · Châteauroux</span></div></div>
          <button class="icon-btn" data-theme-icon aria-label="Basculer le mode sombre"></button>
        </div>
        <div class="row between" style="align-items:flex-end"><span style="font-family:Sora,sans-serif;font-size:20px;font-weight:600;letter-spacing:-.02em">${greeting()}</span><a href="#/plan" class="stat" id="livecount"><span class="dot"></span>Bus en direct</a></div>
      </section>
      <div style="position:relative">
        <label class="field">${I.search}<span class="sr">Rechercher un arrêt</span><input id="q" type="search" placeholder="Rechercher un arrêt" autocomplete="off"></label>
        <div id="results" class="card tight list" hidden style="position:absolute;left:0;right:0;top:58px;z-index:50;box-shadow:var(--shadow);max-height:320px;overflow:auto"></div>
      </div>
      <div id="banner"></div>
      <section class="card" id="next"><div class="skeleton"></div></section>
      <a href="#/points" class="ribbon mesh-host sheen">
        <canvas data-mesh data-seed="4.2" data-glow=".6" aria-hidden="true"></canvas>
        <span class="row between" style="align-items:baseline"><span class="display silver-ink" style="font-size:26px;font-weight:700"><span data-count="${p.balance}">${p.balance.toLocaleString('fr-FR')}</span> pts</span><span class="small muted">Niveau ${esc(lv.name)}</span></span>
        <span class="bar"><span style="width:${pct}%"></span></span>
        <span class="small muted">${lv.next ? `Encore ${(lv.next.at - p.balance).toLocaleString('fr-FR')} pts avant le niveau ${esc(lv.next.name)}` : 'Niveau maximum atteint'}</span>
      </a>
      <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
        ${[['#/trafic', I.bus, 'Info trafic'], ['#/communaute', I.flag, 'Signaler'], ['#/chat/general', I.chat, 'Discuter'], ['#/plan', I.map, 'Plan']]
          .map(([h, ic, t]) => `<a href="${h}" class="card col" style="align-items:center;gap:6px;padding:12px 4px;font-size:12px;font-weight:600;color:var(--ink);text-align:center">${ic}${t}</a>`).join('')}
      </div>
      <div id="favs"></div>`;
    applyTheme(themePref());
    $('[data-theme-icon]').onclick = () => applyTheme(isDark() ? 'light' : 'dark');

    // Recherche
    const results = $('#results');
    $('#q').addEventListener('input', debounce(async (e) => {
      const v = e.target.value.trim();
      if (v.length < 2) { results.hidden = true; return; }
      const { stops } = await api(`/api/stops/search?q=${encodeURIComponent(v)}`);
      results.innerHTML = stops.length ? stops.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}"><span class="grow">${esc(s.name)}</span><span class="row" style="gap:4px">${s.lines.slice(0, 4).map((l) => badge(l, true)).join('')}</span></a>`).join('') : '<div class="empty">Aucun arrêt trouvé</div>';
      results.hidden = false;
    }, 200));

    api('/api/vehicles').then(({ vehicles }) => {
      const el = $('#livecount');
      const n = vehicles.filter((v) => v.line).length;
      if (el) el.innerHTML = `<span class="dot"></span>${n ? `${n} bus en direct` : 'Voir le plan'}`;
    }).catch(() => {});

    // Bandeau : perturbation la plus récente
    Promise.all([api('/api/alerts').catch(() => ({ alerts: [] })), api('/api/reports').catch(() => ({ reports: [] }))]).then(([a, r]) => {
      const al = a.alerts[0];
      const rep = r.reports.find((x) => x.confirmations >= 2 || x.official);
      const el = $('#banner');
      if (!el) return;
      if (al) el.innerHTML = `<a href="#/trafic" class="banner amber">${I.alert}<span class="col" style="gap:2px"><strong>${al.lines.map((l) => `Ligne ${esc(l.shortName)}`).join(', ') || 'Info trafic'}</strong><span>${esc(al.header || al.description)}</span></span></a>`;
      else if (rep) el.innerHTML = `<a href="#/communaute" class="banner amber">${I.alert}<span class="col" style="gap:2px"><strong>${esc(CATS[rep.category])}${rep.stopName ? ` · ${esc(rep.stopName)}` : ''}</strong><span>${esc(rep.text || 'Signalé par des usagers')} · ${rep.confirmations} confirmation${rep.confirmations > 1 ? 's' : ''}</span></span></a>`;
    });

    // Prochains passages
    const target = favs()[0] || local.get('lastStop', null);
    const next = $('#next');
    async function loadNext(stop) {
      const data = await api(`/api/stops/${encodeURIComponent(stop.key)}?limit=4`);
      if (!$('#next')) return;
      next.innerHTML = `<div class="row between" style="margin-bottom:4px"><h2>Prochains passages · ${esc(data.stop.name)}</h2><a class="small" style="font-weight:600" href="#/horaires/${encodeURIComponent(stop.key)}">Tout voir</a></div>
        <div class="list">${data.departures.length ? data.departures.map((d) => depRow(d, data.now)).join('') : '<div class="empty">Plus de passage dans les 2 prochaines heures.</div>'}</div>`;
    }
    if (target) { await loadNext(target).catch(() => { next.innerHTML = '<div class="empty">Passages indisponibles pour le moment.</div>'; }); every(() => loadNext(target).catch(() => {}), 20000); }
    else {
      next.innerHTML = `<h2>Vos prochains passages</h2><p class="small muted" style="margin:6px 0 12px">Trouvez l’arrêt le plus proche ou cherchez-en un ci-dessus.</p><button class="btn block" id="near">${I.pin} Arrêt le plus proche</button>`;
      $('#near').onclick = async () => {
        try {
          const c = await locate();
          const { stops } = await api(`/api/stops/nearby?lat=${c.latitude}&lon=${c.longitude}&limit=1`);
          if (stops[0]) { rememberStop(stops[0]); route(); }
        } catch (e) { toast(e.message); }
      };
    }
    const f = favs();
    if (f.length > 1) $('#favs').innerHTML = `<p class="section-title">Arrêts favoris</p><div class="card tight list">${f.slice(1).map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.starFill}<span class="grow">${esc(s.name)}</span>${I.chevron}</a>`).join('')}</div>`;
  }

  // ---------- Horaires ----------
  async function pageStopPicker() {
    view.innerHTML = `<h1>Horaires</h1>
      <label class="field">${I.search}<span class="sr">Rechercher un arrêt</span><input id="q" type="search" placeholder="Nom de l’arrêt" autocomplete="off"></label>
      <button class="btn secondary" id="near">${I.pin} Arrêts autour de moi</button>
      <div id="list"></div>`;
    const list = $('#list');
    const renderStops = (stops, title) => {
      list.innerHTML = stops.length ? `<p class="section-title">${title}</p><div class="card tight list">${stops.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}"><span class="grow col" style="gap:2px"><span style="font-weight:600">${esc(s.name)}</span>${s.distance != null ? `<span class="xs muted">à ${s.distance} m</span>` : ''}</span><span class="row" style="gap:4px">${(s.lines || []).slice(0, 4).map((l) => badge(l, true)).join('')}</span></a>`).join('')}</div>` : '<div class="empty">Aucun arrêt trouvé</div>';
    };
    const f = favs();
    if (f.length) list.innerHTML = `<p class="section-title">Favoris</p><div class="card tight list">${f.map((s) => `<a class="item" href="#/horaires/${encodeURIComponent(s.key)}">${I.starFill}<span class="grow">${esc(s.name)}</span>${I.chevron}</a>`).join('')}</div>`;
    $('#q').addEventListener('input', debounce(async (e) => {
      const v = e.target.value.trim();
      if (v.length < 2) return;
      renderStops((await api(`/api/stops/search?q=${encodeURIComponent(v)}`)).stops, 'Résultats');
    }, 200));
    $('#near').onclick = async () => {
      try { const c = await locate(); renderStops((await api(`/api/stops/nearby?lat=${c.latitude}&lon=${c.longitude}&limit=8`)).stops, 'Autour de vous'); } catch (e) { toast(e.message); }
    };
    $('#q').focus();
  }

  async function pageStop(key, q) {
    const line = q.get('line') || '';
    view.innerHTML = '<div class="skeleton" style="height:64px"></div><div class="skeleton" style="height:240px"></div>';
    async function load() {
      const data = await api(`/api/stops/${encodeURIComponent(key)}?limit=10${line ? `&line=${encodeURIComponent(line)}` : ''}`);
      rememberStop(data.stop);
      return data;
    }
    let data = await load();
    const s = data.stop;
    view.innerHTML = `
      <h1>Horaires</h1>
      <div class="card row" style="padding:6px 6px 6px 14px">
        ${I.pin}<span class="grow col" style="gap:0"><span class="xs muted">Arrêt</span><span style="font-size:17px;font-weight:700">${esc(s.name)}</span></span>
        <button class="icon-btn" style="border:0;color:var(--amber)" id="fav" aria-label="Favori" aria-pressed="${isFav(s.key)}">${isFav(s.key) ? I.starFill : I.star}</button>
        <a class="btn secondary sm" href="#/horaires">Changer</a>
      </div>
      <div class="chips" role="group" aria-label="Filtrer par ligne">
        <a class="chip" aria-pressed="${!line}" href="#/horaires/${encodeURIComponent(key)}">Toutes</a>
        ${s.lines.map((l) => `<a class="chip line" aria-pressed="${line === l.id}" style="background:${color(l.color)};color:${color(l.textColor, '#FFFFFF')}" href="#/horaires/${encodeURIComponent(key)}?line=${encodeURIComponent(l.id)}">${esc(l.shortName)}</a>`).join('')}
      </div>
      <div id="lastmin"></div>
      <section class="card tight"><div class="list" id="deps"></div></section>
      <p class="xs muted" id="rtinfo" style="margin:-4px 2px 0"></p>
      <div id="grid"></div>`;
    $('#fav').onclick = (e) => { const on = toggleFav(s); e.currentTarget.innerHTML = on ? I.starFill : I.star; e.currentTarget.setAttribute('aria-pressed', on); toast(on ? 'Ajouté aux favoris' : 'Retiré des favoris'); };
    let busByTrip = new Map();
    const loadBuses = () => api('/api/vehicles').then(({ vehicles }) => { busByTrip = new Map(vehicles.filter((v) => v.tripId).map((v) => [v.tripId, v.id])); }).catch(() => {});
    await loadBuses();
    const render = (d) => {
      const deps = $('#deps');
      if (!deps) return;
      deps.innerHTML = d.departures.length ? d.departures.map((x) => depRow(x, d.now, busByTrip.get(x.tripId))).join('') : '<div class="empty">Aucun passage dans les 2 prochaines heures.</div>';
      const lm = d.departures.filter((x) => x.status === 'supprime' || x.status === 'non-desservi');
      $('#lastmin').innerHTML = lm.length ? `<div class="banner red" role="alert">${I.alert}<span class="col" style="gap:2px"><strong>Dernière minute</strong>${lm.map((x) => `<span>Ligne ${esc(x.line.shortName)} de ${hm(x.scheduled)} vers ${esc(x.headsign)} : ${x.status === 'supprime' ? 'course supprimée' : 'arrêt non desservi'}.</span>`).join('')}</span></div>` : '';
      $('#rtinfo').textContent = d.realtimeAt ? `Temps réel mis à jour ${ago(d.realtimeAt)}.` : 'Temps réel indisponible : horaires prévus affichés.';
    };
    render(data);
    if (data.grid && data.grid.length) {
      $('#grid').innerHTML = data.grid.map((g) => `<section class="card col" style="gap:8px"><h2 style="font-size:15px">Grille du jour · vers ${esc(g.headsign)}</h2><div class="grid-hours">${g.hours.map((h) => `<strong>${h.hour}h</strong><span>${h.minutes.map((m) => String(m).padStart(2, '0')).join(' · ')}</span>`).join('')}</div></section>`).join('');
    }
    every(async () => { try { await loadBuses(); data = await load(); render(data); } catch (e) { /* */ } }, 20000);
  }

  // ---------- Plan ----------
  async function pagePlan(q) {
    view.classList.add('full');
    const all = await lines();
    const selected = new Set(q.get('line') ? [q.get('line')] : []);
    let mode = 'map';
    view.innerHTML = `
      <div id="map" role="application" aria-label="Carte du réseau avec les bus en temps réel"></div>
      <div class="map-top">
        <div class="seg" role="group" aria-label="Type de plan"><button aria-pressed="true" data-mode="map">Interactif</button><button aria-pressed="false" data-mode="classic">Classique</button></div>
        <div class="chips" id="lchips">${all.map((l) => `<button class="chip line" aria-pressed="${selected.has(l.id)}" data-line="${esc(l.id)}" style="background:${color(l.color)};color:${color(l.textColor, '#FFFFFF')}">${esc(l.shortName)}</button>`).join('')}</div>
      </div>
      <button class="icon-btn map-fab" id="me" aria-label="Me localiser">${I.locate}</button>
      <div id="sheet"></div>
      <div class="classic" id="classic" hidden></div>`;
    if (!window.L) { $('#map').innerHTML = '<div class="empty" style="padding-top:140px">Carte indisponible hors connexion.</div>'; return; }
    const map = L.map('map', { zoomControl: false, attributionControl: true }).setView([46.8103, 1.6913], 13);
    cleanup.push(() => map.remove());
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
    map.attributionControl.setPrefix('');
    const mapEl = $('#map');
    const zoomCls = () => mapEl.classList.toggle('map-far', map.getZoom() < 15);
    map.on('zoomend', zoomCls); zoomCls();

    // Arrêts (visibles en zoomant)
    const stopLayer = L.layerGroup();
    allStops().then((stops) => {
      for (const s of stops) {
        L.circleMarker([s.lat, s.lon], { radius: 4.5, color: isDark() ? '#F2F2F4' : '#0B0B0C', weight: 2, fillColor: isDark() ? '#151517' : '#FFFFFF', fillOpacity: 1, bubblingMouseEvents: false })
          .bindPopup(`<strong>${esc(s.name)}</strong><br><a href="#/horaires/${encodeURIComponent(s.key)}">Prochains passages</a>`).addTo(stopLayer);
      }
      const upd = () => { if (map.getZoom() >= 15 && !openId) stopLayer.addTo(map); else stopLayer.remove(); };
      map.on('zoomend', upd); upd();
      stopLayer._upd = upd;
    }).catch(() => {});

    // Tracé des lignes choisies dans les filtres
    const pathLayer = L.layerGroup().addTo(map);
    async function drawPaths() {
      pathLayer.clearLayers();
      for (const id of selected) {
        try {
          const d = await api(`/api/lines/${encodeURIComponent(id)}`);
          for (const dir of d.directions) if (dir.path.length > 1) L.polyline(dir.path, { color: color(d.color), weight: 4, opacity: .7, interactive: false }).addTo(pathLayer);
        } catch (e) { /* */ }
      }
    }

    // ----- Bus en temps réel -----
    const markers = new Map();
    const journeyLayer = L.layerGroup().addTo(map);
    let vehicles = [];
    let openId = q.get('bus') || null;
    let openData = null;

    const busIcon = (v) => {
      const hlp = !v.line;
      const c = hlp ? '#8E8E96' : color(v.line.color), tc = hlp ? '#3A3D45' : color(v.line.textColor, '#FFFFFF');
      const dir = v.bearing != null ? `<i class="bus-dir" style="--b:${Math.round(v.bearing)}deg"></i>` : '';
      const stale = v.timestamp && Date.now() - v.timestamp > 5 * 60 * 1000;
      return L.divIcon({ className: '', iconSize: [30, 34], iconAnchor: [15, 9],
        html: `<div class="bus${v.id === openId ? ' sel' : ''}${stale ? ' stale' : ''}${hlp ? ' hlp' : ''}" style="--c:${c};--t:${tc}"><span class="bus-dot">${dir}</span><span class="bus-tag">${hlp ? 'HLP' : esc(v.line.shortName)}</span></div>` });
    };
    // Déplacement fluide d'un marqueur vers sa nouvelle position
    function glide(m, to) {
      const from = m.getLatLng();
      cancelAnimationFrame(m._anim);
      if (reduceMotion || from.distanceTo(to) > 3000) return m.setLatLng(to);
      const t0 = performance.now(), d = 1600;
      const step = (t) => {
        const k = Math.min(1, (t - t0) / d), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        m.setLatLng([from.lat + (to[0] - from.lat) * e, from.lng + (to[1] - from.lng) * e]);
        if (k < 1) m._anim = requestAnimationFrame(step);
      };
      m._anim = requestAnimationFrame(step);
    }
    async function loadVehicles() {
      try { vehicles = (await api('/api/vehicles')).vehicles; } catch (e) { return; }
      const seen = new Set();
      for (const v of vehicles) {
        if (selected.size && !(v.line && selected.has(v.line.id)) && v.id !== openId) continue;
        seen.add(v.id);
        let m = markers.get(v.id);
        if (!m) {
          m = L.marker([v.lat, v.lon], { icon: busIcon(v), keyboard: true, title: v.line ? `Ligne ${v.line.shortName} vers ${titleCase(v.headsign)}` : 'Bus HLP, en pause', zIndexOffset: 500 }).addTo(map);
          m.on('click', () => openBus(v.id, true));
          markers.set(v.id, m);
        } else { glide(m, [v.lat, v.lon]); m.setIcon(busIcon(v)); }
        m.setZIndexOffset(v.id === openId ? 2000 : 500);
      }
      for (const [id, m] of markers) if (!seen.has(id)) { m.remove(); markers.delete(id); }
    }
    const refreshIcons = () => { for (const v of vehicles) { const m = markers.get(v.id); if (m) { m.setIcon(busIcon(v)); m.setZIndexOffset(v.id === openId ? 2000 : 500); } } };

    // ----- Trajet du bus sélectionné -----
    function drawJourney(d, fit) {
      journeyLayer.clearLayers();
      const j = d.journey;
      const line = d.line || (d.vehicle && d.vehicle.line);
      const c = color(line && line.color), tc = color(line && line.textColor, '#FFFFFF');
      if (!j) { if (fit && d.vehicle) map.setView([d.vehicle.lat, d.vehicle.lon], 16); return; }
      // Partie déjà parcourue : discrète
      if (j.pathPassed.length > 1) L.polyline(j.pathPassed, { color: c, weight: 4, opacity: .22, interactive: false }).addTo(journeyLayer);
      // Partie restante : liseré blanc + couleur de la ligne
      L.polyline(j.pathAhead, { color: '#FFFFFF', weight: 9, opacity: .95, interactive: false }).addTo(journeyLayer);
      L.polyline(j.pathAhead, { color: c, weight: 5, interactive: false, className: fit ? 'route-draw' : '' }).addTo(journeyLayer);
      // Arrêts restants (les arrêts passés sont effacés)
      const ahead = j.stops.filter((s) => s.state !== 'passed' && s.lat != null);
      ahead.forEach((s, i) => {
        const isNext = s.state === 'next', last = i === ahead.length - 1;
        const mk = L.circleMarker([s.lat, s.lon], { radius: isNext ? 6 : 4.5, color: s.skipped ? '#B91C1C' : c, weight: 2.5, fillColor: s.skipped ? '#FEE2E2' : '#FFFFFF', fillOpacity: 1, bubblingMouseEvents: false }).addTo(journeyLayer);
        const minor = !(isNext || last || s.skipped);
        mk.bindTooltip(`<span class="stop-tag${isNext ? ' next' : ''}${s.skipped ? ' skip' : ''}" style="--c:${c};--t:${tc}">${esc(s.name)}</span>`, { permanent: true, direction: 'right', offset: [5, 0], className: `tag-tt${minor ? ' minor' : ''}` });
        if (s.key) mk.on('click', () => { location.hash = `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(j.routeId)}`; });
      });
      if (fit && j.pathAhead.length) {
        const sh = $('.bsheet');
        const bottom = sh ? window.innerHeight - sh.getBoundingClientRect().top + 16 : Math.round(window.innerHeight * .5);
        map.fitBounds(L.latLngBounds(j.pathAhead), { paddingTopLeft: [24, 124], paddingBottomRight: [110, bottom], maxZoom: 16 });
      }
    }

    const mins = (sec) => Math.max(1, Math.round(Math.abs(sec) / 60));
    let sheetExpanded = false;
    function renderSheet(d) {
      const el = $('#sheet');
      if (!el) return;
      const prevScroll = $('.bsheet .scroll') ? $('.bsheet .scroll').scrollTop : 0;
      const v = d.vehicle, j = d.journey;
      const line = d.line || (v && v.line);
      const hlp = !line && !j;
      const c = hlp ? '#8E8E96' : color(line && line.color), tc = hlp ? '#FFFFFF' : color(line && line.textColor, '#FFFFFF');
      const delay = j ? j.delay : v && v.delay;
      const now = Date.now();

      let chip;
      if (hlp) chip = '<span class="schip neutral">HLP · Pause</span>';
      else if (j && j.canceled) chip = '<span class="schip supprime">Course supprimée</span>';
      else if (delay == null) chip = '<span class="schip neutral">Horaire prévu</span>';
      else if (delay >= 60) chip = `<span class="schip retard">Retard ${mins(delay)} min</span>`;
      else if (delay <= -60) chip = `<span class="schip avance">Avance ${mins(delay)} min</span>`;
      else chip = '<span class="schip ok">À l’heure</span>';
      const live = j && j.realtime ? '<span class="schip neutral"><span class="dot"></span>Temps réel</span>' : '';
      const toggle = j ? `<button class="schip neutral" id="expand" style="border:0;margin-left:auto" aria-expanded="${sheetExpanded}">Trajet <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="transform:rotate(${sheetExpanded ? 180 : 0}deg);transition:transform .2s"><path d="M6 15l6-6 6 6"/></svg></button>` : '';

      // Prochain arrêt, en grand
      const ns = j && j.stops[j.nextIndex];
      const nsT = ns ? (ns.expected ?? ns.scheduled) : null;
      const nsMin = nsT ? Math.round((nsT - now) / 60000) : null;
      const stopLink = (s) => (s.key ? `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(j.routeId)}` : '#');
      let next = '';
      if (ns) next = `<a class="nextbox" style="color:inherit" href="${stopLink(ns)}"><span class="col" style="gap:2px;min-width:0"><span class="k">Prochain arrêt</span><span class="v">${esc(ns.name)}</span></span><span class="when"><span class="big">${ns.skipped ? '—' : nsMin <= 0 ? 'Arrive' : `${nsMin} min`}</span><br><span class="xs muted">${ns.skipped ? 'non desservi' : hm(nsT)}</span></span></a>`;
      else if (hlp) next = `<div class="why2"><span class="ic" style="background:var(--seg);color:var(--ink2)">${I.bus}</span><span><strong>Haut-le-pied ou pause</strong><br><span class="muted">Ce bus ne prend pas de voyageurs pour l’instant : il est en pause au terminus ou rejoint le départ de sa prochaine course.</span></span></div>`;
      else next = '<span class="small muted">Le détail du trajet n’est pas disponible pour ce bus.</span>';

      // Pourquoi ? Déviation ?
      let why = '';
      if (delay != null && delay >= 60) {
        const items = [
          ...d.alerts.map((a) => `<span><strong>Réseau :</strong> ${esc(a.header || a.description)}</span>`),
          ...d.causes.map((r) => `<span><strong>${esc(CATS[r.category])}</strong>${r.stopName ? ` à ${esc(r.stopName)}` : ''}${r.text ? ` : « ${esc(r.text)} »` : ''} <span class="muted">· ${r.confirmations} usager${r.confirmations > 1 ? 's' : ''}, ${ago(r.createdAt)}</span>${r.official ? `<br><strong>Réseau :</strong> ${esc(r.official)}` : ''}</span>`),
        ];
        why = `<div class="why2"><span class="ic">${I.alert}</span><span class="col" style="gap:4px"><strong>Pourquoi ce retard ?</strong>${items.length ? items.join('') : `<span class="muted">Aucune cause signalée pour l’instant.</span><a href="#/communaute${line ? `?line=${encodeURIComponent(line.id)}` : ''}">Vous savez pourquoi ? Signalez-le</a>`}</span></div>`;
      } else if (delay != null && delay <= -60) {
        why = `<div class="why2 adv"><span class="ic">${I.check}</span><span class="col" style="gap:2px"><strong>En avance sur l’horaire</strong><span class="muted">Le bus peut attendre à un arrêt pour reprendre son horaire.</span></span></div>`;
      }
      const dev = j && j.skipped.length
        ? `<div class="why2 dev"><span class="ic">${I.alert}</span><span class="col" style="gap:2px"><strong>Déviation</strong><span>Non desservi${j.skipped.length > 1 ? 's' : ''} : ${j.skipped.map(esc).join(', ')}.</span><span class="muted">Ces arrêts sont barrés sur la carte.</span></span></div>` : '';

      // Arrêts à venir
      const upcoming = j ? j.stops.filter((s) => s.state !== 'passed') : [];
      const tl = upcoming.length ? `<div class="scroll"><div class="timeline2">${upcoming.map((s) => {
        const t = s.expected ?? s.scheduled;
        const moved = s.expected && Math.abs(s.expected - s.scheduled) >= 60 * 1000;
        const m = Math.round((t - now) / 60000);
        const right = s.skipped ? '<span class="pill non-desservi">Non desservi</span>'
          : `<b>${hm(t)}</b>${moved ? `<s>${hm(s.scheduled)}</s>` : `<span class="in">${m <= 0 ? 'à l’approche' : `dans ${m} min`}</span>`}`;
        return `<a class="tl2 ${s.state}${s.skipped ? ' skip' : ''}" href="${stopLink(s)}"><span class="rail"><i></i></span><span class="nm">${esc(s.name)}</span><span class="tm">${right}</span></a>`;
      }).join('')}</div></div>` : '';

      const riding = onboard.veh && v && onboard.veh.id === v.id;
      el.innerHTML = `<div class="bsheet${sheetExpanded ? '' : ' collapsed'}" role="dialog" aria-label="Bus sélectionné" style="--c:${c}">
        <button class="grab" id="grab" aria-label="${sheetExpanded ? 'Réduire la fiche' : 'Afficher tout le trajet'}"></button>
        <div class="head">
          <span class="lbadge" style="background:${c};color:${tc};font-size:${hlp ? '13px' : '19px'}">${hlp ? 'HLP' : esc(line.shortName)}</span>
          <div class="grow col" style="gap:2px;min-width:0"><span class="dest">${hlp ? 'En pause' : `→ ${esc(titleCase((j && j.headsign) || (v && v.headsign)) || 'Bus en service')}`}</span><span class="meta">Véhicule ${esc(v ? v.id : '')}${v && v.timestamp ? ` · position ${ago(v.timestamp)}` : ''}</span></div>
          <button class="x" id="close" aria-label="Fermer">${I.x}</button>
        </div>
        <div class="chiprow">${chip}${live}${toggle}</div>
        ${next}
        <div class="more">${dev}${why}${tl}</div>
        ${hlp ? '' : `<div class="actions"><button class="btn" id="ride">${riding ? 'Détection…' : 'Je suis à bord'}</button><a class="btn outline" href="#/communaute${line ? `?line=${encodeURIComponent(line.id)}` : ''}">Signaler</a></div>`}
      </div>`;
      const sc = $('.bsheet .scroll'); if (sc) sc.scrollTop = prevScroll;
      const setExpanded = (x) => { sheetExpanded = x; renderSheet(d); };
      $('#close').onclick = closeBus;
      $('#grab').onclick = () => setExpanded(!sheetExpanded);
      if ($('#expand')) $('#expand').onclick = () => setExpanded(!sheetExpanded);
      if ($('#ride')) $('#ride').onclick = () => { if (!v) return; if (onboard.veh && onboard.veh.id === v.id) onboard.stop(); else onboard.start(v); renderSheet(d); };
      // Glisser vers le haut pour déplier, vers le bas pour replier puis fermer
      const box = $('.bsheet');
      let y0 = null;
      box.addEventListener('touchstart', (e) => { y0 = e.target.closest('.scroll') ? null : e.touches[0].clientY; }, { passive: true });
      box.addEventListener('touchend', (e) => {
        if (y0 == null) return;
        const dy = e.changedTouches[0].clientY - y0; y0 = null;
        if (dy < -40 && !sheetExpanded && j) setExpanded(true);
        else if (dy > 40) { if (sheetExpanded) setExpanded(false); else if (dy > 70) closeBus(); }
      });
    }

    async function openBus(id, fit) {
      if (openId !== id) sheetExpanded = false;
      openId = id;
      mapEl.classList.add('map-focus');
      pathLayer.remove();
      if (stopLayer._upd) stopLayer._upd();
      refreshIcons();
      let d;
      try { d = await api(`/api/vehicles/${encodeURIComponent(id)}`); } catch (e) { toast(e.message); return closeBus(); }
      if (openId !== id) return;
      openData = d;
      renderSheet(d);
      drawJourney(d, fit);
    }
    function closeBus() {
      openId = null; openData = null;
      journeyLayer.clearLayers();
      mapEl.classList.remove('map-focus');
      pathLayer.addTo(map);
      if (stopLayer._upd) stopLayer._upd();
      const el = $('#sheet'); if (el) el.innerHTML = '';
      refreshIcons();
    }
    map.on('click', () => { if (openId) closeBus(); });

    await loadVehicles();
    if (openId) openBus(openId, true);
    every(async () => { await loadVehicles(); if (openId) { try { const d = await api(`/api/vehicles/${encodeURIComponent(openId)}`); if (openId && d) { openData = d; drawJourney(d, false); renderSheet(d); } } catch (e) { /* bus perdu : on garde l'affichage */ } } }, 15000);
    drawPaths();

    // Position de l'usager
    let meMarker = null;
    $('#me').onclick = async () => {
      try {
        const c = await locate();
        const ll = [c.latitude, c.longitude];
        if (!meMarker) meMarker = L.marker(ll, { icon: L.divIcon({ className: '', iconSize: [18, 18], html: '<div class="me-dot"></div>' }) }).addTo(map); else meMarker.setLatLng(ll);
        map.setView(ll, 16);
      } catch (e) { toast(e.message); }
    };

    $('#lchips').onclick = (e) => {
      const b = e.target.closest('[data-line]');
      if (!b) return;
      const id = b.dataset.line;
      if (selected.has(id)) selected.delete(id); else selected.add(id);
      b.setAttribute('aria-pressed', selected.has(id));
      drawPaths(); loadVehicles();
      if (mode === 'classic') renderClassic();
    };
    $$('[data-mode]').forEach((b) => { b.onclick = () => { mode = b.dataset.mode; $$('[data-mode]').forEach((x) => x.setAttribute('aria-pressed', x === b)); $('#classic').hidden = mode !== 'classic'; $('#me').hidden = mode === 'classic'; $('#sheet').hidden = mode === 'classic'; if (mode === 'classic') renderClassic(); else map.invalidateSize(); }; });

    async function renderClassic() {
      const box = $('#classic');
      const ids = selected.size ? [...selected] : all.map((l) => l.id);
      box.innerHTML = '<div class="skeleton" style="height:200px"></div>';
      const details = await Promise.all(ids.map((id) => api(`/api/lines/${encodeURIComponent(id)}`).catch(() => null)));
      box.innerHTML = details.filter(Boolean).map((d) => {
        const dir = d.directions[0];
        if (!dir) return '';
        return `<section class="card col" style="gap:10px;margin-bottom:12px">
          <div class="row">${badge(d)}<a class="grow" style="font-weight:600;color:var(--ink)" href="#/ligne/${encodeURIComponent(d.id)}">${esc(d.longName || dir.headsign)}</a>${I.chevron}</div>
          <div class="schema" style="--c:${color(d.color)}">${dir.stops.map((s, i) => `<a class="${i === 0 || i === dir.stops.length - 1 ? 'term' : ''}" href="${s.key ? `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(d.id)}` : '#'}">${esc(s.name)}</a>`).join('')}</div>
        </section>`;
      }).join('') + '<p class="xs muted">Plan schématique : touchez un arrêt pour ses horaires. Le plan officiel au format PDF est disponible auprès du réseau Horizon.</p>';
    }
  }

  // ---------- Info trafic & lignes ----------
  async function pageTraffic() {
    view.innerHTML = '<div class="skeleton" style="height:180px"></div>';
    const [a, r, all, v] = await Promise.all([api('/api/alerts').catch(() => ({ alerts: [] })), api('/api/reports').catch(() => ({ reports: [] })), lines(), api('/api/vehicles').catch(() => ({ vehicles: [] }))]);
    const byLine = new Map();
    for (const x of v.vehicles) if (x.line) byLine.set(x.line.id, (byLine.get(x.line.id) || 0) + 1);
    const reps = r.reports.filter((x) => x.confirmations >= 2 || x.official);
    view.innerHTML = `
      <div class="row" style="margin-left:-10px"><a href="#/" class="icon-btn" style="border:0;background:transparent" aria-label="Retour">${I.back}</a><h1>Info trafic</h1></div>
      <p class="section-title">En cours</p>
      ${a.alerts.map((x) => `<article class="card col" style="gap:6px;border-left:0"><div class="row">${x.lines.map((l) => badge(l, true)).join('')}<strong>${esc(x.header || 'Perturbation')}</strong></div>${x.description ? `<p class="small" style="margin:0;color:var(--ink2)">${esc(x.description)}</p>` : ''}<span class="xs muted">Source : réseau Horizon</span></article>`).join('')}
      ${reps.map((x) => { const l = all.find((y) => y.id === x.routeId); return `<article class="card col" style="gap:6px"><div class="row">${l ? badge(l, true) : ''}<strong>${esc(CATS[x.category])}${x.stopName ? ` · ${esc(x.stopName)}` : ''}</strong></div>${x.text ? `<p class="small" style="margin:0;color:var(--ink2)">${esc(x.text)}</p>` : ''}<span class="xs muted">Signalé par les usagers · ${x.confirmations} confirmation${x.confirmations > 1 ? 's' : ''} · ${ago(x.createdAt)}</span>${x.official ? `<div class="banner info small">${I.shield}<span><strong>Réseau :</strong> ${esc(x.official)}</span></div>` : ''}</article>`; }).join('')}
      ${!a.alerts.length && !reps.length ? `<div class="banner green">${I.check}<span>Aucune perturbation signalée pour le moment.</span></div>` : ''}
      <p class="section-title">Infos lignes</p>
      <div class="card tight list">${all.map((l) => `<a class="item" href="#/ligne/${encodeURIComponent(l.id)}">${badge(l)}<span class="grow col" style="gap:2px"><span style="font-weight:500">${esc(l.termini.join(' ↔ ') || l.longName)}</span><span class="xs muted">${byLine.get(l.id) ? `${byLine.get(l.id)} bus en circulation` : 'Aucun bus localisé'}</span></span>${I.chevron}</a>`).join('')}</div>
      <div class="banner green small">${I.check}<span>Réseau gratuit : montez sans titre de transport.</span></div>`;
  }

  async function pageLine(id) {
    const d = await api(`/api/lines/${encodeURIComponent(id)}`);
    let dirIdx = 0;
    const render = () => {
      const dir = d.directions[dirIdx];
      view.innerHTML = `
        <div class="row" style="margin-left:-10px"><a href="#/trafic" class="icon-btn" style="border:0;background:transparent" aria-label="Retour">${I.back}</a>${badge(d)}<h1 style="font-size:19px">${esc(d.longName || `Ligne ${d.shortName}`)}</h1></div>
        ${d.directions.length > 1 ? `<div class="seg" role="group" aria-label="Direction">${d.directions.map((x, i) => `<button data-dir="${i}" aria-pressed="${i === dirIdx}">→ ${esc(x.headsign)}</button>`).join('')}</div>` : ''}
        <section class="card"><div class="schema" style="--c:${color(d.color)}">${dir.stops.map((s, i) => `<a class="${i === 0 || i === dir.stops.length - 1 ? 'term' : ''}" href="${s.key ? `#/horaires/${encodeURIComponent(s.key)}?line=${encodeURIComponent(d.id)}` : '#'}">${esc(s.name)}</a>`).join('')}</div></section>
        <div class="row"><a class="btn grow" href="#/plan?line=${encodeURIComponent(d.id)}">${I.map} Voir les bus</a><a class="btn secondary grow" href="#/chat/ligne-${encodeURIComponent(d.id.replace(/[^\w-]/g, '-'))}">${I.chat} Discussion</a></div>`;
      $$('[data-dir]').forEach((b) => { b.onclick = () => { dirIdx = +b.dataset.dir; render(); }; });
    };
    render();
  }

  // ---------- Communauté : signalements ----------
  async function pageReports(q) {
    const all = await lines();
    let lineId = q.get('line') || '';
    let cat = 'retard';
    view.innerHTML = `
      <h1>Communauté</h1>
      <div class="seg"><a href="#/communaute" aria-current="page">Signalements</a><a href="#/chat/general">Discussions</a></div>
      <section class="card col" style="gap:12px">
        <div class="row between"><h2>Signaler un problème</h2><span class="xs" style="font-weight:700;color:var(--pri)">+10 pts si confirmé</span></div>
        <div class="chips" id="rlines" role="group" aria-label="Ligne concernée">${all.map((l) => `<button class="chip line" data-line="${esc(l.id)}" aria-pressed="${l.id === lineId}" style="background:${color(l.color)};color:${color(l.textColor, '#FFFFFF')}">${esc(l.shortName)}</button>`).join('')}</div>
        <label class="field" style="height:48px"><span class="sr">Arrêt concerné</span><select id="rstop"><option value="">Arrêt (facultatif)</option></select></label>
        <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px" id="rcats">${Object.entries(CATS).map(([k, v]) => `<button class="chip" style="justify-content:center;height:44px;border-radius:10px;padding:0 6px" data-cat="${k}" aria-pressed="${k === cat}">${v}</button>`).join('')}</div>
        <label><span class="sr">Précisions</span><textarea class="input" id="rtext" maxlength="280" placeholder="Précisions (facultatif)"></textarea></label>
        <button class="btn block" id="rsend">${I.flag.replace('width="24" height="24"', 'width="18" height="18"')} Envoyer le signalement</button>
      </section>
      <p class="section-title">Derniers signalements</p>
      <div id="feed" class="col" style="gap:10px"><div class="skeleton"></div></div>`;

    async function fillStops() {
      const sel = $('#rstop');
      sel.innerHTML = '<option value="">Arrêt (facultatif)</option>';
      if (!lineId) return;
      try {
        const d = await api(`/api/lines/${encodeURIComponent(lineId)}`);
        const seen = new Set();
        for (const dir of d.directions) for (const s of dir.stops) if (s.key && !seen.has(s.key)) { seen.add(s.key); sel.insertAdjacentHTML('beforeend', `<option value="${esc(s.key)}">${esc(s.name)}</option>`); }
        const last = local.get('lastStop', null);
        if (last && seen.has(last.key)) sel.value = last.key;
      } catch (e) { /* */ }
    }
    fillStops();
    $('#rlines').onclick = (e) => { const b = e.target.closest('[data-line]'); if (!b) return; lineId = lineId === b.dataset.line ? '' : b.dataset.line; $$('#rlines [data-line]').forEach((x) => x.setAttribute('aria-pressed', x.dataset.line === lineId)); fillStops(); };
    $('#rcats').onclick = (e) => { const b = e.target.closest('[data-cat]'); if (!b) return; cat = b.dataset.cat; $$('#rcats [data-cat]').forEach((x) => x.setAttribute('aria-pressed', x === b)); };
    $('#rsend').onclick = async () => {
      if (!lineId) return toast('Choisissez la ligne concernée.');
      const btn = $('#rsend'); btn.disabled = true;
      try {
        const { report } = await api('/api/reports', { method: 'POST', body: { routeId: lineId, stopKey: $('#rstop').value, category: cat, text: $('#rtext').value, author: local.get('pseudo', '') } });
        local.set('myReports', [report.id, ...local.get('myReports', [])].slice(0, 50));
        local.set('voted', [report.id, ...local.get('voted', [])].slice(0, 300));
        $('#rtext').value = '';
        toast('Merci ! Vos 10 points arrivent quand d’autres usagers confirment.');
        loadFeed();
      } catch (e) { toast(e.message); }
      btn.disabled = false;
    };

    async function loadFeed() {
      const { reports } = await api('/api/reports');
      // Points pour mes signalements confirmés par au moins 2 autres usagers
      const mine = new Set(local.get('myReports', []));
      const p = points();
      for (const r of reports) if (mine.has(r.id) && r.confirmations >= 3 && !p.credited.includes(r.id)) { p.credited.push(r.id); local.set('points', p); award(10, 'Signalement confirmé'); }
      const voted = new Set(local.get('voted', []));
      const feed = $('#feed');
      if (!feed) return;
      feed.innerHTML = reports.length ? reports.map((r) => {
        const l = all.find((x) => x.id === r.routeId);
        return `<article class="card col" style="gap:8px">
          <div class="row" style="gap:8px;flex-wrap:wrap">${l ? badge(l, true) : ''}<strong>${esc(CATS[r.category])}</strong><span class="xs muted">${r.stopName ? `${esc(r.stopName)} · ` : ''}${ago(r.createdAt)}</span></div>
          ${r.text ? `<p style="margin:0;font-size:14px">${esc(r.text)}</p>` : ''}
          ${r.official ? `<div class="banner info small">${I.shield}<span><strong>Réseau :</strong> ${esc(r.official)}</span></div>` : ''}
          <div class="row">${voted.has(r.id) ? `<span class="small muted">${r.confirmations} confirmation${r.confirmations > 1 ? 's' : ''} · merci !</span>` : `<button class="btn secondary sm" data-vote="confirm" data-id="${esc(r.id)}">Je confirme · ${r.confirmations}</button><button class="btn ghost sm" data-vote="stale" data-id="${esc(r.id)}">Plus d’actualité</button>`}</div>
        </article>`;
      }).join('') : '<div class="card empty">Aucun signalement en cours. Tout roule !</div>';
    }
    $('#feed').onclick = async (e) => {
      const b = e.target.closest('[data-vote]');
      if (!b) return;
      try {
        await api(`/api/reports/${encodeURIComponent(b.dataset.id)}/${b.dataset.vote}`, { method: 'POST', body: {} });
        local.set('voted', [b.dataset.id, ...local.get('voted', [])].slice(0, 300));
        loadFeed();
      } catch (err) { toast(err.message); }
    };
    await loadFeed();
    every(() => loadFeed().catch(() => {}), 30000);
  }

  // ---------- Communauté : discussions ----------
  async function pageChat(room) {
    if (!/^[\w-]{1,40}$/.test(room)) room = 'general';
    const all = await lines().catch(() => []);
    const rooms = [['general', 'Général'], ...all.map((l) => [`ligne-${l.id.replace(/[^\w-]/g, '-')}`, `Ligne ${l.shortName}`]), ['equipe', 'Équipe réseau']];
    const mine = new Set(local.get('myMsgs', []));
    let since = 0;
    view.innerHTML = `
      <h1>Communauté</h1>
      <div class="seg"><a href="#/communaute">Signalements</a><a href="#/chat/general" aria-current="page">Discussions</a></div>
      <div class="chips">${rooms.map(([id, name]) => `<a class="chip" aria-pressed="${id === room}" href="#/chat/${id}">${esc(name)}</a>`).join('')}</div>
      ${room === 'equipe' ? `<div class="banner info small">${I.shield}<span>Écrivez ici à l’équipe du réseau. Ses réponses portent le badge « Équipe réseau ».</span></div>` : ''}
      <div class="msgs" id="msgs"><div class="skeleton"></div></div>
      <div style="height:70px"></div>
      <form class="composer" id="composer">
        <label class="field"><span class="sr">Votre message</span><input id="text" maxlength="500" autocomplete="off" placeholder="Votre message…"></label>
        <button class="btn" aria-label="Envoyer">${I.send}</button>
      </form>`;
    const box = $('#msgs');
    let first = true;
    async function load() {
      const { messages } = await api(`/api/chat/${room}?since=${since}`);
      if (first) { box.innerHTML = messages.length ? '' : '<div class="empty">Aucun message pour l’instant. Lancez la discussion !</div>'; first = false; }
      if (messages.length && box.querySelector('.empty')) box.innerHTML = '';
      for (const m of messages) {
        since = Math.max(since, m.at);
        const cls = m.official ? 'team' : mine.has(m.id) ? 'me' : '';
        box.insertAdjacentHTML('beforeend', `<div class="msg ${cls}"><span class="who">${m.official ? `${I.shield} Équipe réseau` : esc(mine.has(m.id) ? 'Vous' : m.author)} · ${hm(m.at)}</span><span class="bubble">${esc(m.text)}</span></div>`);
      }
      if (messages.length) window.scrollTo(0, document.body.scrollHeight);
    }
    await load();
    every(() => load().catch(() => {}), 5000);
    $('#composer').onsubmit = async (e) => {
      e.preventDefault();
      const input = $('#text');
      const text = input.value.trim();
      if (!text) return;
      if (!local.get('pseudo', '')) {
        const p = (window.prompt('Choisissez un pseudo pour la communauté') || '').trim().slice(0, 30);
        if (!p) return;
        local.set('pseudo', p);
      }
      try {
        const { message } = await api(`/api/chat/${room}`, { method: 'POST', body: { text, author: local.get('pseudo', '') } });
        mine.add(message.id); local.set('myMsgs', [message.id, ...mine].slice(0, 300));
        input.value = '';
        await load();
      } catch (err) { toast(err.message); }
    };
  }

  // ---------- Points & réglages ----------
  async function pagePoints() {
    const p = points();
    const lv = level(p.balance);
    const pct = lv.next ? Math.min(100, Math.round(((p.balance - lv.from) / (lv.next.at - lv.from)) * 100)) : 100;
    const pref = themePref();
    view.innerHTML = `
      <h1>Mes points</h1>
      <section class="ribbon mesh-host sheen">
        <canvas data-mesh data-seed="2.6" data-glow=".6" aria-hidden="true"></canvas>
        <div class="row between" style="align-items:flex-start">
          <div class="col" style="gap:2px"><span class="display silver-ink" style="font-size:34px;font-weight:700;line-height:1.05" data-count="${p.balance}">${p.balance.toLocaleString('fr-FR')}</span><span class="small muted">points · niveau ${esc(lv.name)}</span></div>
          <span class="small streak" style="border-radius:10px;padding:6px 10px;font-weight:600">Série : ${streak(p)} jour${streak(p) > 1 ? 's' : ''}</span>
        </div>
        <span class="bar"><span style="width:${pct}%"></span></span>
        <span class="small muted">${lv.next ? `${(lv.next.at - p.balance).toLocaleString('fr-FR')} pts avant le niveau ${esc(lv.next.name)}` : 'Niveau maximum atteint'}</span>
      </section>
      ${onboard.veh ? `<div class="banner info">${I.bus}<span class="grow">Détection du trajet en cours (ligne ${esc(onboard.veh.line ? onboard.veh.line.shortName : '')}).</span><button class="btn sm secondary" id="stopride">Arrêter</button></div>` : ''}
      <section class="card col" style="gap:12px">
        <h2>Gagner des points</h2>
        ${[[I.bus, 'Trajet confirmé', 'Sur le plan, touchez votre bus puis « Je suis à bord »', '+20'], [I.flag, 'Signalement confirmé', 'Validé par d’autres usagers', '+10'], [I.star, '5 jours de suite en bus', 'Bonus de série', '+50']]
          .map(([ic, t, s, v]) => `<div class="row"><span style="width:38px;height:38px;border-radius:10px;background:var(--priBg);color:var(--pri);display:flex;align-items:center;justify-content:center;flex-shrink:0">${ic}</span><span class="grow col" style="gap:0"><span style="font-weight:600">${t}</span><span class="xs muted">${s}</span></span><strong>${v}</strong></div>`).join('')}
      </section>
      <section class="card col" style="gap:6px"><h2>Récompenses</h2><p class="small muted" style="margin:0">Les récompenses des commerces partenaires arrivent bientôt. Vos points sont conservés sur ce téléphone.</p></section>
      <p class="section-title">Historique</p>
      <div class="card tight list">${p.history.length ? p.history.slice(0, 10).map((h) => `<div class="item"><span class="grow col" style="gap:0"><span>${esc(h.label)}</span><span class="xs muted">${new Date(h.at).toLocaleString('fr-FR', { timeZone: TZ, day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span></span><strong style="color:var(--green)">+${h.pts}</strong></div>`).join('') : '<div class="empty">Pas encore de points : prenez le bus !</div>'}</div>
      <p class="section-title">Réglages</p>
      <section class="card col" style="gap:14px">
        <div class="col"><span style="font-weight:600">Apparence</span><div class="seg" role="group" aria-label="Apparence">${[['auto', 'Auto'], ['light', 'Clair'], ['dark', 'Sombre']].map(([k, v]) => `<button data-theme-pref="${k}" aria-pressed="${pref === k}">${v}</button>`).join('')}</div></div>
        <label class="col"><span style="font-weight:600">Pseudo dans la communauté</span><span class="field" style="height:48px"><input id="pseudo" maxlength="30" value="${esc(local.get('pseudo', ''))}" placeholder="Votre pseudo"></span></label>
      </section>
      <p class="section-title">Données</p>
      <section class="card col small" id="sources" style="gap:6px"><div class="skeleton" style="height:40px"></div></section>`;
    $$('[data-theme-pref]').forEach((b) => { b.onclick = () => { applyTheme(b.dataset.themePref); $$('[data-theme-pref]').forEach((x) => x.setAttribute('aria-pressed', x === b)); }; });
    $('#pseudo').onchange = (e) => { local.set('pseudo', e.target.value.trim().slice(0, 30)); toast('Pseudo enregistré'); };
    if ($('#stopride')) $('#stopride').onclick = () => { onboard.stop(); route(); };
    try {
      const s = await api('/api/status');
      $('#sources').innerHTML = `
        <span>Temps réel : ${s.realtime.vehiclePositionsAt ? `${s.realtime.vehicles} bus localisés, mis à jour ${ago(s.realtime.vehiclePositionsAt)}` : 'indisponible'}</span>
        <span>Horaires : ${s.gtfs ? `${s.gtfs.lines} lignes, ${s.gtfs.stops} arrêts (valables jusqu’au ${s.gtfs.validTo.slice(6, 8)}/${s.gtfs.validTo.slice(4, 6)}/${s.gtfs.validTo.slice(0, 4)})` : 'en cours de chargement'}</span>
        ${s.sources.map((x) => `<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.name)}</a>`).join('')}
        <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">Fond de carte © contributeurs OpenStreetMap</a>
        <span class="xs muted">Mobilya ${esc(s.version || '')} · application indépendante, en version d’essai.</span>`;
    } catch (e) { $('#sources').textContent = 'Statut indisponible.'; }
  }

  // ---------- Démarrage ----------
  applyTheme(themePref());
  const splash = $('#splash');
  let splashSeen = false;
  try { splashSeen = sessionStorage.getItem('mobilya-splash') === '1'; } catch (e) { /* */ }
  if (!splashSeen) {
    splash.hidden = false;
    if (window.Mesh) Mesh.attach(splash);
    const close = () => { splash.style.opacity = '0'; setTimeout(() => { splash.hidden = true; }, 400); try { sessionStorage.setItem('mobilya-splash', '1'); } catch (e) { /* */ } };
    $('#splash-go').onclick = close;
    if (local.get('welcomed', false)) setTimeout(close, 1100); else local.set('welcomed', true);
  }
  route();
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' }).then((r) => r.update()).catch(() => {}));
})();
