'use strict';
// Gestion de l'heure locale du réseau (Europe/Paris) et des "jours de service" GTFS.
const TZ = process.env.TZ_NETWORK || 'Europe/Paris';

const fmt = new Intl.DateTimeFormat('en-CA', {
  timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23', weekday: 'short',
});
const WD = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };

function parts(ms) {
  const o = {};
  for (const p of fmt.formatToParts(new Date(ms))) o[p.type] = p.value;
  return {
    y: +o.year, m: +o.month, d: +o.day, hh: +o.hour, mm: +o.minute, ss: +o.second,
    weekday: WD[o.weekday], ymd: `${o.year}${o.month}${o.day}`,
    sec: +o.hour * 3600 + +o.minute * 60 + +o.second,
  };
}

// Décalage horaire local (ms) à l'instant ms
function offsetAt(ms) {
  const p = parts(ms);
  return Date.UTC(p.y, p.m - 1, p.d, p.hh, p.mm, p.ss) - Math.floor(ms / 1000) * 1000;
}

// Instant (ms) de référence d'un jour de service GTFS : "midi moins 12 h", heure locale.
function serviceBase(ymd) {
  const y = +ymd.slice(0, 4), m = +ymd.slice(4, 6), d = +ymd.slice(6, 8);
  const noonGuess = Date.UTC(y, m - 1, d, 12);
  const noon = noonGuess - offsetAt(noonGuess);
  return noon - 12 * 3600 * 1000;
}

function shiftYmd(ymd, days) {
  const y = +ymd.slice(0, 4), m = +ymd.slice(4, 6), d = +ymd.slice(6, 8);
  const t = new Date(Date.UTC(y, m - 1, d + days));
  return `${t.getUTCFullYear()}${String(t.getUTCMonth() + 1).padStart(2, '0')}${String(t.getUTCDate()).padStart(2, '0')}`;
}

function weekdayOf(ymd) {
  const y = +ymd.slice(0, 4), m = +ymd.slice(4, 6), d = +ymd.slice(6, 8);
  return (new Date(Date.UTC(y, m - 1, d)).getUTCDay() + 6) % 7; // lundi = 0
}

// "25:10:00" -> secondes
function hmsToSec(s) {
  if (!s) return null;
  const [h, m, sec] = s.split(':').map(Number);
  return h * 3600 + m * 60 + (sec || 0);
}

module.exports = { TZ, parts, serviceBase, shiftYmd, weekdayOf, hmsToSec };
